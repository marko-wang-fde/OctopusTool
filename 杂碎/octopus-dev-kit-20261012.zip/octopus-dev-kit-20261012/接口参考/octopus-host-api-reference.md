# 小章鱼 Host API 端点清单

> 自动生成自 octopus-cli api-coverage manifest
> 共 321 个已封装端点

---

## v1

| Method | Path | CLI Command |
|--------|------|------------|
| GET | `/api/v1/bootstrap/team-create/assistant` | `config bootstrap team-create assistant list` |
| GET | `/api/v1/bootstrap/team-create/config` | `config bootstrap team-create config list` |
| GET | `/api/v1/chrome-browser-connections/ws` | `browser chrome-connection ws list` |
| GET | `/api/v1/company-profile-options` | `config company-profile-options list` |
| POST | `/api/v1/conversations` | `conversation create` |
| GET | `/api/v1/conversations/recents` | `conversation recents list` |
| GET | `/api/v1/conversations/{id}/a2ui-surfaces` | `conversation a2ui-surfaces list` |
| POST | `/api/v1/conversations/{id}/a2ui-surfaces/{surfaceId}/actions` | `conversation a2ui-surfaces actions create` |
| POST | `/api/v1/conversations/{id}/attach-team` | `conversation attach-team create` |
| GET | `/api/v1/conversations/{id}/desktop/current` | `conversation desktop current list` |
| GET | `/api/v1/conversations/{id}/desktop/snapshots` | `conversation desktop snapshots list` |
| GET | `/api/v1/conversations/{id}/desktop/snapshots/{snapshotId}/asset` | `conversation desktop snapshots asset list` |
| GET | `/api/v1/conversations/{id}/file-grants` | `conversation file-grants list` |
| PUT | `/api/v1/conversations/{id}/file-grants` | `conversation file-grants set` |
| GET | `/api/v1/conversations/{id}/messages` | `conversation messages list` |
| POST | `/api/v1/conversations/{id}/share` | `conversation share create` |
| GET | `/api/v1/conversations/{id}/stream` | `conversation stream list` |
| POST | `/api/v1/conversations/{id}/stream-ticket` | `conversation stream-ticket create` |
| GET | `/api/v1/conversations/{id}/timeline` | `conversation timeline list` |
| POST | `/api/v1/conversations/{id}/turns/human` | `conversation turns human create` |
| GET | `/api/v1/conversations/{id}/turns/{turnId}/detail` | `conversation turns detail list` |
| GET | `/api/v1/conversations/{id}/turns/{turnId}/llm-trace` | `conversation turns llm-trace list` |
| GET | `/api/v1/conversations/{id}/turns/{turnId}/llm-trace/{traceCallId}` | `conversation turns llm-trace get` |
| POST | `/api/v1/conversations/{id}/turns/{turnId}/resume` | `conversation turns resume create` |
| POST | `/api/v1/conversations/{id}/turns/{turnId}/steer` | `conversation turns steer create` |
| GET | `/api/v1/endpoint-types` | `config endpoint-type list` |
| GET | `/api/v1/endpoint-types/{endpointType}/config-schema` | `config endpoint-type config-schema list` |
| POST | `/api/v1/group-sessions/{groupSessionId}/agentloops/{agentLoopId}/stop` | `group-session agentloops stop create` |
| GET | `/api/v1/group-sessions/{groupSessionId}/bootstrap` | `group-session bootstrap list` |
| GET | `/api/v1/group-sessions/{groupSessionId}/events` | `group-session events list` |
| POST | `/api/v1/group-sessions/{groupSessionId}/join` | `group-session join create` |
| GET | `/api/v1/group-sessions/{groupSessionId}/members` | `group-session members list` |
| POST | `/api/v1/group-sessions/{groupSessionId}/members/{memberId}/mute` | `group-session members mute create` |
| DELETE | `/api/v1/group-sessions/{groupSessionId}/members/{memberId}/mute` | `group-session members mute delete` |
| GET | `/api/v1/group-sessions/{groupSessionId}/messages` | `group-session messages list` |
| POST | `/api/v1/group-sessions/{groupSessionId}/messages` | `group-session messages create` |
| PUT | `/api/v1/group-sessions/{groupSessionId}/reply-targets` | `group-session reply-targets set` |
| GET | `/api/v1/group-sessions/{groupSessionId}/settings` | `group-session settings list` |
| PATCH | `/api/v1/group-sessions/{groupSessionId}/settings` | `group-session settings update` |
| GET | `/api/v1/healthz` | `config healthz list` |
| GET | `/api/v1/market/digiworkers` | `market digiworkers list` |
| GET | `/api/v1/me` | `me list` |
| PATCH | `/api/v1/me` | `me update` |
| GET | `/api/v1/office-preview-sessions/{sessionId}` | `office-preview session get` |
| GET | `/api/v1/portal-brand/resolve` | `config portal-brand resolve list` |
| GET | `/api/v1/shared/{shareId}` | `shared get` |
| GET | `/api/v1/site-config/public` | `config site-config public list` |
| POST | `/api/v1/stations/{stationId}/embed-access-tokens` | `app station embed-access-tokens create` |
| POST | `/api/v1/stations/{stationId}/web-sessions` | `app station web-sessions create` |
| GET | `/api/v1/teams` | `team list` |
| POST | `/api/v1/teams` | `team create` |
| GET | `/api/v1/teams/{teamId}` | `team get` |
| PATCH | `/api/v1/teams/{teamId}` | `team get patch` |
| GET | `/api/v1/teams/{teamId}/activation` | `team activation list` |
| GET | `/api/v1/teams/{teamId}/apps/web-url` | `app web-url list` |
| POST | `/api/v1/teams/{teamId}/apps/web-url` | `app web-url create` |
| DELETE | `/api/v1/teams/{teamId}/apps/web-url/{appId}` | `app web-url delete` |
| PATCH | `/api/v1/teams/{teamId}/apps/web-url/{appId}` | `app web-url update` |
| GET | `/api/v1/teams/{teamId}/arcubase` | `arcubase list` |
| GET | `/api/v1/teams/{teamId}/arcubase-codegen/apps/{appId}/schema` | `arcubase codegen apps schema list` |
| GET | `/api/v1/teams/{teamId}/arcubase/apps` | `arcubase apps list` |
| GET | `/api/v1/teams/{teamId}/arcubase/apps/{appId}/tables` | `arcubase apps tables list` |
| POST | `/api/v1/teams/{teamId}/arcubase/apps/{appId}/tables/{tableId}/rows/query` | `arcubase apps tables rows query create` |
| GET | `/api/v1/teams/{teamId}/arcubase/apps/{appId}/tables/{tableId}/rows/{rowId}` | `arcubase apps tables rows get` |
| POST | `/api/v1/teams/{teamId}/arcubase/departments` | `arcubase departments create` |
| POST | `/api/v1/teams/{teamId}/arcubase/departments/paths` | `arcubase departments paths create` |
| GET | `/api/v1/teams/{teamId}/arcubase/departments/tree` | `arcubase departments tree list` |
| DELETE | `/api/v1/teams/{teamId}/arcubase/departments/{departmentId}` | `arcubase departments delete` |
| PUT | `/api/v1/teams/{teamId}/arcubase/departments/{departmentId}/relocate` | `arcubase departments relocate set` |
| PUT | `/api/v1/teams/{teamId}/arcubase/departments/{departmentId}/rename` | `arcubase departments rename set` |
| GET | `/api/v1/teams/{teamId}/arcubase/organization/roles` | `arcubase organization roles list` |
| POST | `/api/v1/teams/{teamId}/arcubase/organization/roles` | `arcubase organization roles create` |
| DELETE | `/api/v1/teams/{teamId}/arcubase/organization/roles/{roleId}` | `arcubase organization roles delete` |
| PUT | `/api/v1/teams/{teamId}/arcubase/organization/roles/{roleId}/rename` | `arcubase organization roles rename set` |
| GET | `/api/v1/teams/{teamId}/artifacts` | `artifact list` |
| GET | `/api/v1/teams/{teamId}/artifacts/summary` | `artifact summary list` |
| GET | `/api/v1/teams/{teamId}/artifacts/{artifactId}` | `artifact get` |
| GET | `/api/v1/teams/{teamId}/assemblable-skills` | `skill assemblable list` |
| GET | `/api/v1/teams/{teamId}/browser-instances` | `browser list` |
| POST | `/api/v1/teams/{teamId}/browser-instances/cloud` | `browser cloud create` |
| DELETE | `/api/v1/teams/{teamId}/browser-instances/{browserInstanceId}` | `browser delete` |
| PATCH | `/api/v1/teams/{teamId}/browser-instances/{browserInstanceId}` | `browser update` |
| POST | `/api/v1/teams/{teamId}/browser-instances/{browserInstanceId}/client-info/refresh` | `browser client-info refresh create` |
| POST | `/api/v1/teams/{teamId}/browser-instances/{browserInstanceId}/live-login` | `browser live-login create` |
| POST | `/api/v1/teams/{teamId}/browser-instances/{browserInstanceId}/live-login/commit` | `browser live-login commit create` |
| GET | `/api/v1/teams/{teamId}/browser-instances/{browserInstanceId}/profile-sites` | `browser profile-sites list` |
| GET | `/api/v1/teams/{teamId}/calendar-sources` | `calendar source list` |
| POST | `/api/v1/teams/{teamId}/calendar-sources` | `calendar source create` |
| POST | `/api/v1/teams/{teamId}/calendar-sources/builtin` | `calendar source builtin create` |
| GET | `/api/v1/teams/{teamId}/calendar-sources/catalog` | `calendar source catalog list` |
| DELETE | `/api/v1/teams/{teamId}/calendar-sources/{sourceId}` | `calendar source delete` |
| PATCH | `/api/v1/teams/{teamId}/calendar-sources/{sourceId}` | `calendar source update` |
| GET | `/api/v1/teams/{teamId}/calendar-sources/{sourceId}/events` | `calendar source events list` |
| POST | `/api/v1/teams/{teamId}/calendar-sources/{sourceId}/sync` | `calendar source sync create` |
| POST | `/api/v1/teams/{teamId}/collaboration-platforms/feishu/binding-sessions` | `integration collaboration-platform feishu binding-sessions create` |
| GET | `/api/v1/teams/{teamId}/collaboration-platforms/feishu/binding-sessions/{bindingSessionId}` | `integration collaboration-platform feishu binding-sessions get` |
| GET | `/api/v1/teams/{teamId}/compute-images` | `team compute-images list` |
| GET | `/api/v1/teams/{teamId}/cron-triggers` | `schedule trigger list` |
| POST | `/api/v1/teams/{teamId}/cron-triggers` | `schedule trigger create` |
| GET | `/api/v1/teams/{teamId}/cron-triggers/{triggerId}` | `schedule trigger get` |
| PATCH | `/api/v1/teams/{teamId}/cron-triggers/{triggerId}` | `schedule trigger update` |
| POST | `/api/v1/teams/{teamId}/cron-triggers/{triggerId}/delete` | `schedule trigger delete create` |
| POST | `/api/v1/teams/{teamId}/cron-triggers/{triggerId}/disable` | `schedule trigger disable create` |
| POST | `/api/v1/teams/{teamId}/cron-triggers/{triggerId}/enable` | `schedule trigger enable create` |
| POST | `/api/v1/teams/{teamId}/cron-triggers/{triggerId}/run` | `schedule trigger run create` |
| GET | `/api/v1/teams/{teamId}/cron-triggers/{triggerId}/runs` | `schedule trigger runs list` |
| GET | `/api/v1/teams/{teamId}/devices` | `device list` |
| POST | `/api/v1/teams/{teamId}/devices/register` | `device register create` |
| GET | `/api/v1/teams/{teamId}/devices/{deviceId}` | `device get` |
| PATCH | `/api/v1/teams/{teamId}/devices/{deviceId}/visibility` | `device visibility update` |
| POST | `/api/v1/teams/{teamId}/digiemployees/hire` | `employee hire create` |
| GET | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}` | `employee get` |
| PATCH | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/access-policy` | `employee access-policy update` |
| GET | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/arcubase` | `employee arcubase list` |
| POST | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/arcubase/ensure` | `employee arcubase ensure create` |
| GET | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/conversation-activity-heatmap` | `employee conversation-activity-heatmap list` |
| POST | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/feishu-bot-binding-sessions` | `employee feishu-bot-binding-sessions create` |
| POST | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/fire` | `employee fire create` |
| POST | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/group-sessions` | `employee group-sessions create` |
| GET | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/kb-access` | `employee kb-access list` |
| PUT | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/kb-access` | `employee kb-access set` |
| PATCH | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/profile` | `employee profile update` |
| PUT | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/reporting-line` | `employee reporting-line set` |
| GET | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/reporting-neighbors` | `employee reporting-neighbors list` |
| GET | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/runtime-config` | `employee runtime-config list` |
| PUT | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/runtime-config` | `employee runtime-config set` |
| DELETE | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/runtime-config` | `employee runtime-config delete` |
| PATCH | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/skillsets` | `employee skillsets update` |
| GET | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/stations` | `employee stations list` |
| POST | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/stations` | `employee stations create` |
| GET | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/team-skills` | `employee team-skills list` |
| PUT | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/team-skills` | `employee team-skills set` |
| POST | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/wecom-aibot-binding-sessions` | `employee wecom-aibot-binding-sessions create` |
| POST | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/weixin-clawbot-binding-sessions` | `employee weixin-clawbot-binding-sessions create` |
| GET | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/workspace-access` | `employee workspace-access list` |
| PUT | `/api/v1/teams/{teamId}/digiemployees/{digiEmployeeId}/workspace-access` | `employee workspace-access set` |
| GET | `/api/v1/teams/{teamId}/email-ingress-addresses` | `integration email-ingress list` |
| POST | `/api/v1/teams/{teamId}/email-ingress-addresses` | `integration email-ingress create` |
| GET | `/api/v1/teams/{teamId}/email-ingress-addresses/{addressId}` | `integration email-ingress get` |
| DELETE | `/api/v1/teams/{teamId}/email-ingress-addresses/{addressId}` | `integration email-ingress delete` |
| PATCH | `/api/v1/teams/{teamId}/email-ingress-addresses/{addressId}` | `integration email-ingress update` |
| POST | `/api/v1/teams/{teamId}/email-ingress-addresses/{addressId}/disable` | `integration email-ingress disable create` |
| POST | `/api/v1/teams/{teamId}/email-ingress-addresses/{addressId}/enable` | `integration email-ingress enable create` |
| GET | `/api/v1/teams/{teamId}/external-user-tags` | `external-user tag list` |
| GET | `/api/v1/teams/{teamId}/external-user-verification-flows` | `external-user verification-flow list` |
| POST | `/api/v1/teams/{teamId}/external-user-verification-flows` | `external-user verification-flow create` |
| GET | `/api/v1/teams/{teamId}/external-user-verification-flows/{flowId}` | `external-user verification-flow get` |
| PUT | `/api/v1/teams/{teamId}/external-user-verification-flows/{flowId}` | `external-user verification-flow update` |
| DELETE | `/api/v1/teams/{teamId}/external-user-verification-flows/{flowId}` | `external-user verification-flow delete` |
| GET | `/api/v1/teams/{teamId}/external-users` | `external-user list` |
| GET | `/api/v1/teams/{teamId}/external-users/{externalUserId}` | `external-user get` |
| GET | `/api/v1/teams/{teamId}/external-users/{externalUserId}/conversations` | `external-user conversations list` |
| PATCH | `/api/v1/teams/{teamId}/external-users/{externalUserId}/human-member` | `external-user human-member update` |
| GET | `/api/v1/teams/{teamId}/feishu-bot-binding-sessions/{bindingSessionId}` | `integration feishu-bot-binding-session get` |
| POST | `/api/v1/teams/{teamId}/file-preview-sessions` | `file preview-session create` |
| POST | `/api/v1/teams/{teamId}/files/delete` | `file delete create` |
| GET | `/api/v1/teams/{teamId}/files/entries` | `file entries list` |
| GET | `/api/v1/teams/{teamId}/files/mounts` | `file mounts list` |
| POST | `/api/v1/teams/{teamId}/files/move` | `file move create` |
| GET | `/api/v1/teams/{teamId}/group-sessions/joined` | `group-session joined list` |
| POST | `/api/v1/teams/{teamId}/inbox/items/{itemId}/act` | `team inbox items act create` |
| GET | `/api/v1/teams/{teamId}/inbox/summary` | `team inbox summary list` |
| GET | `/api/v1/teams/{teamId}/integrations` | `integration list` |
| PUT | `/api/v1/teams/{teamId}/integrations/feishu` | `integration feishu set` |
| DELETE | `/api/v1/teams/{teamId}/integrations/feishu` | `integration feishu delete` |
| POST | `/api/v1/teams/{teamId}/integrations/feishu/verify` | `integration feishu verify create` |
| PUT | `/api/v1/teams/{teamId}/integrations/wecom` | `integration wecom set` |
| POST | `/api/v1/teams/{teamId}/integrations/wecom` | `integration wecom create` |
| DELETE | `/api/v1/teams/{teamId}/integrations/wecom` | `integration wecom delete` |
| GET | `/api/v1/teams/{teamId}/integrations/wecom/contacts` | `integration wecom contacts list` |
| POST | `/api/v1/teams/{teamId}/integrations/wecom/sync-contacts` | `integration wecom sync-contacts create` |
| POST | `/api/v1/teams/{teamId}/integrations/wecom/verify` | `integration wecom verify create` |
| GET | `/api/v1/teams/{teamId}/job-tags/selectable` | `market job-tag selectable list` |
| GET | `/api/v1/teams/{teamId}/kb/directories` | `kb directories list` |
| POST | `/api/v1/teams/{teamId}/kb/directories` | `kb directories create` |
| DELETE | `/api/v1/teams/{teamId}/kb/directories/{directoryId}` | `kb directories delete` |
| PATCH | `/api/v1/teams/{teamId}/kb/directories/{directoryId}` | `kb directories update` |
| GET | `/api/v1/teams/{teamId}/kb/sync-bindings` | `kb sync-bindings list` |
| POST | `/api/v1/teams/{teamId}/kb/sync-bindings` | `kb sync-bindings create` |
| POST | `/api/v1/teams/{teamId}/kb/sync-bindings/validate-target` | `kb sync-bindings validate-target create` |
| DELETE | `/api/v1/teams/{teamId}/kb/sync-bindings/{bindingId}` | `kb sync-bindings delete` |
| POST | `/api/v1/teams/{teamId}/kb/sync-bootstrap-access` | `kb sync-bootstrap-access create` |
| GET | `/api/v1/teams/{teamId}/kb/sync-jobs` | `kb sync-jobs list` |
| GET | `/api/v1/teams/{teamId}/market/job-tags` | `market job-tag list` |
| GET | `/api/v1/teams/{teamId}/market/landing` | `market landing list` |
| POST | `/api/v1/teams/{teamId}/market/orders/plan` | `market orders plan create` |
| POST | `/api/v1/teams/{teamId}/market/orders/worker` | `market orders worker create` |
| GET | `/api/v1/teams/{teamId}/market/plans` | `market plans list` |
| GET | `/api/v1/teams/{teamId}/market/plans/{planId}` | `market plans get` |
| GET | `/api/v1/teams/{teamId}/market/workers` | `market workers list` |
| GET | `/api/v1/teams/{teamId}/market/workers/{workerId}` | `market workers get` |
| GET | `/api/v1/teams/{teamId}/services` | `services list` |
| GET | `/api/v1/teams/{teamId}/services/catalog` | `services catalog list` |
| GET | `/api/v1/teams/{teamId}/services/catalog/{connectorId}` | `services catalog get` |
| GET | `/api/v1/teams/{teamId}/services/connections` | `services connections list` |
| GET | `/api/v1/teams/{teamId}/services/connections/{connectionId}` | `services connections get` |
| POST | `/api/v1/teams/{teamId}/services/connections` | `services connections create` |
| POST | `/api/v1/teams/{teamId}/services/connections/{connectionId}/credentials` | `services connections credentials create` |
| POST | `/api/v1/teams/{teamId}/services/connections/{connectionId}/disconnect` | `services connections disconnect` |
| POST | `/api/v1/teams/{teamId}/services/connections/{connectionId}/dynamic-options` | `services connections dynamic-options resolve` |
| POST | `/api/v1/teams/{teamId}/services/connections/{connectionId}/oauth/callback` | `services connections oauth callback` |
| POST | `/api/v1/teams/{teamId}/services/connections/{connectionId}/oauth/start` | `services connections oauth start` |
| POST | `/api/v1/teams/{teamId}/services/connections/{connectionId}/tools/{toolKey}/execute` | `services connections tools execute` |
| GET | `/api/v1/teams/{teamId}/services/credentials` | `services credentials list` |
| GET | `/api/v1/teams/{teamId}/services/credentials/{credentialId}` | `services credentials get` |
| POST | `/api/v1/teams/{teamId}/services/credentials/{credentialId}/oauth/reauth` | `services credentials oauth reauth` |
| POST | `/api/v1/teams/{teamId}/services/credentials/{credentialId}/oauth/refresh` | `services credentials oauth refresh` |
| POST | `/api/v1/teams/{teamId}/services/credentials/{credentialId}/validate` | `services credentials validate` |
| GET | `/api/v1/teams/{teamId}/services/executions` | `services executions list` |
| GET | `/api/v1/teams/{teamId}/services/executions/{executionId}` | `services executions get` |
| GET | `/api/v1/teams/{teamId}/services/servers` | `services servers list` |
| GET | `/api/v1/teams/{teamId}/services/servers/{serviceServerId}` | `services servers get` |
| GET | `/api/v1/teams/{teamId}/services/servers/{serviceServerId}/bindings` | `services servers bindings list` |
| GET | `/api/v1/teams/{teamId}/me/profile` | `team me profile list` |
| PATCH | `/api/v1/teams/{teamId}/me/profile` | `team me profile update` |
| GET | `/api/v1/teams/{teamId}/members` | `team members list` |
| GET | `/api/v1/teams/{teamId}/members/{userId}` | `team members get` |
| POST | `/api/v1/teams/{teamId}/members/{userId}/actions` | `team members actions create` |
| GET | `/api/v1/teams/{teamId}/members/{userId}/arcubase` | `team members arcubase list` |
| GET | `/api/v1/teams/{teamId}/members/{userId}/arcubase/departments` | `team members arcubase departments list` |
| PUT | `/api/v1/teams/{teamId}/members/{userId}/arcubase/departments` | `team members arcubase departments set` |
| GET | `/api/v1/teams/{teamId}/members/{userId}/arcubase/organization/roles` | `team members arcubase organization roles list` |
| PUT | `/api/v1/teams/{teamId}/members/{userId}/arcubase/organization/roles` | `team members arcubase organization roles set` |
| POST | `/api/v1/teams/{teamId}/members/{userId}/arcubase:activate` | `team members arcubase-activate create` |
| GET | `/api/v1/teams/{teamId}/members/{userId}/profile` | `team members profile list` |
| PATCH | `/api/v1/teams/{teamId}/members/{userId}/profile` | `team members profile update` |
| PATCH | `/api/v1/teams/{teamId}/members/{userId}/role` | `team members role update` |
| POST | `/api/v1/teams/{teamId}/members:invite` | `team members-invite create` |
| GET | `/api/v1/teams/{teamId}/my-apps` | `app my list` |
| POST | `/api/v1/teams/{teamId}/my-apps/{appId}/open` | `app my open create` |
| GET | `/api/v1/teams/{teamId}/octopus-edge/brokers` | `octopus-edge brokers list` |
| POST | `/api/v1/teams/{teamId}/octopus-edge/brokers` | `octopus-edge brokers create` |
| POST | `/api/v1/teams/{teamId}/octopus-edge/brokers/{brokerInstanceId}/revoke` | `octopus-edge brokers revoke` |
| GET | `/api/v1/teams/{teamId}/octopus-edge/services` | `octopus-edge services list` |
| POST | `/api/v1/teams/{teamId}/octopus-edge/services` | `octopus-edge services create` |
| POST | `/api/v1/teams/{teamId}/office-preview-sessions` | `office-preview session create` |
| POST | `/api/v1/teams/{teamId}/organization/members:search` | `team organization members-search create` |
| GET | `/api/v1/teams/{teamId}/pinned-digiemployees` | `employee pinned list` |
| PUT | `/api/v1/teams/{teamId}/pinned-digiemployees/{digiEmployeeId}` | `employee pinned update` |
| DELETE | `/api/v1/teams/{teamId}/pinned-digiemployees/{digiEmployeeId}` | `employee pinned delete` |
| GET | `/api/v1/teams/{teamId}/private-digiworker/config` | `team private-digiworker config list` |
| POST | `/api/v1/teams/{teamId}/private-digiworkers` | `team private-digiworkers create` |
| GET | `/api/v1/teams/{teamId}/private-digiworkers/{workerId}` | `team private-digiworkers get` |
| PATCH | `/api/v1/teams/{teamId}/private-digiworkers/{workerId}` | `team private-digiworkers update` |
| GET | `/api/v1/teams/{teamId}/secrets` | `team secrets list` |
| POST | `/api/v1/teams/{teamId}/secrets` | `team secrets create` |
| GET | `/api/v1/teams/{teamId}/secrets/catalog` | `team secrets catalog list` |
| GET | `/api/v1/teams/{teamId}/secrets/{secretId}` | `team secrets get` |
| DELETE | `/api/v1/teams/{teamId}/secrets/{secretId}` | `team secrets delete` |
| PATCH | `/api/v1/teams/{teamId}/secrets/{secretId}` | `team secrets update` |
| POST | `/api/v1/teams/{teamId}/secrets/{secretId}/rotate` | `team secrets rotate create` |
| GET | `/api/v1/teams/{teamId}/skills` | `skill list` |
| GET | `/api/v1/teams/{teamId}/skills/count` | `skill count list` |
| POST | `/api/v1/teams/{teamId}/skills/package-upload` | `skill package-upload create` |
| POST | `/api/v1/teams/{teamId}/skills/scan` | `skill scan create` |
| POST | `/api/v1/teams/{teamId}/skills/upload` | `skill upload create` |
| PATCH | `/api/v1/teams/{teamId}/skills/{id}` | `skill update` |
| POST | `/api/v1/teams/{teamId}/skills/{id}/disable-assembly` | `skill disable-assembly create` |
| POST | `/api/v1/teams/{teamId}/skills/{id}/enable-assembly` | `skill enable-assembly create` |
| GET | `/api/v1/teams/{teamId}/skillsets` | `skill set list` |
| POST | `/api/v1/teams/{teamId}/skillsets` | `skill set create` |
| DELETE | `/api/v1/teams/{teamId}/skillsets/{id}` | `skill set delete` |
| PATCH | `/api/v1/teams/{teamId}/skillsets/{id}` | `skill set update` |
| GET | `/api/v1/teams/{teamId}/stations/{stationId}` | `app station get` |
| PATCH | `/api/v1/teams/{teamId}/stations/{stationId}` | `app station update` |
| GET | `/api/v1/teams/{teamId}/stations/{stationId}/api-keys` | `app station api-keys list` |
| POST | `/api/v1/teams/{teamId}/stations/{stationId}/api-keys:rotate` | `app station api-keys-rotate create` |
| PUT | `/api/v1/teams/{teamId}/stations/{stationId}/channel-config` | `app station channel-config set` |
| POST | `/api/v1/teams/{teamId}/stations/{stationId}/delete` | `app station delete create` |
| POST | `/api/v1/teams/{teamId}/stations/{stationId}/disable` | `app station disable create` |
| POST | `/api/v1/teams/{teamId}/stations/{stationId}/enable` | `app station enable create` |
| POST | `/api/v1/teams/{teamId}/subject-profiles` | `team subject-profiles create` |
| GET | `/api/v1/teams/{teamId}/subscribe/summary` | `billing subscribe summary list` |
| GET | `/api/v1/teams/{teamId}/ticket-integration` | `billing ticket-integration list` |
| POST | `/api/v1/teams/{teamId}/ticket-redemptions` | `billing ticket-redemptions create` |
| GET | `/api/v1/teams/{teamId}/usage-points-rollups` | `billing usage-points-rollups list` |
| GET | `/api/v1/teams/{teamId}/usage-rollups` | `billing usage-rollups list` |
| GET | `/api/v1/teams/{teamId}/vibe-coding/projects` | `coding projects list` |
| POST | `/api/v1/teams/{teamId}/vibe-coding/projects` | `coding projects create` |
| GET | `/api/v1/teams/{teamId}/vibe-coding/projects/{projectId}` | `coding projects show` |
| DELETE | `/api/v1/teams/{teamId}/vibe-coding/projects/{projectId}` | `coding projects archive` |
| POST | `/api/v1/teams/{teamId}/vibe-coding/projects/{projectId}/publish` | `coding projects publish` |
| GET | `/api/v1/teams/{teamId}/vibe-coding/projects/{projectId}/secret-bindings` | `coding projects secret-bindings list` |
| PUT | `/api/v1/teams/{teamId}/vibe-coding/projects/{projectId}/secret-bindings` | `coding projects secret-bindings set` |
| GET | `/api/v1/teams/{teamId}/vibe-coding/projects/{projectId}/workbench-domain` | `coding projects workbench-domain show` |
| PATCH | `/api/v1/teams/{teamId}/vibe-coding/projects/{projectId}/workbench-domain` | `coding projects workbench-domain set` |
| GET | `/api/v1/teams/{teamId}/vibe-coding/publish-tasks/{taskId}` | `coding projects watch` |
| GET | `/api/v1/teams/{teamId}/vibe-coding/templates` | `coding templates list` |
| GET | `/api/v1/teams/{teamId}/web-skills` | `team web-skills list` |
| POST | `/api/v1/teams/{teamId}/web-skills/search` | `team web-skills search create` |
| POST | `/api/v1/teams/{teamId}/web-skills/upload` | `team web-skills upload create` |
| PATCH | `/api/v1/teams/{teamId}/web-skills/{webSkillId}` | `team web-skills update` |
| GET | `/api/v1/teams/{teamId}/web-skills/{webSkillId}/bundle` | `team web-skills bundle list` |
| POST | `/api/v1/teams/{teamId}/web-skills/{webSkillId}/clone` | `team web-skills clone create` |
| GET | `/api/v1/teams/{teamId}/web-skills/{webSkillId}/detail` | `team web-skills detail list` |
| POST | `/api/v1/teams/{teamId}/web-skills/{webSkillId}/files/read` | `team web-skills files read create` |
| GET | `/api/v1/teams/{teamId}/webhook-endpoints` | `integration webhook list` |
| POST | `/api/v1/teams/{teamId}/webhook-endpoints` | `integration webhook create` |
| GET | `/api/v1/teams/{teamId}/webhook-endpoints/{endpointId}` | `integration webhook get` |
| DELETE | `/api/v1/teams/{teamId}/webhook-endpoints/{endpointId}` | `integration webhook delete` |
| PATCH | `/api/v1/teams/{teamId}/webhook-endpoints/{endpointId}` | `integration webhook update` |
| POST | `/api/v1/teams/{teamId}/webhook-endpoints/{endpointId}/disable` | `integration webhook disable create` |
| POST | `/api/v1/teams/{teamId}/webhook-endpoints/{endpointId}/enable` | `integration webhook enable create` |
| GET | `/api/v1/teams/{teamId}/webhook-endpoints/{endpointId}/events` | `integration webhook events list` |
| POST | `/api/v1/teams/{teamId}/webhook-endpoints/{endpointId}/rotate-signature-secret` | `integration webhook rotate-signature-secret create` |
| POST | `/api/v1/teams/{teamId}/webhook-endpoints/{endpointId}/rotate-url-token` | `integration webhook rotate-url-token create` |
| GET | `/api/v1/teams/{teamId}/webhook-endpoints/{endpointId}/runs` | `integration webhook runs list` |
| GET | `/api/v1/teams/{teamId}/wecom-aibot-binding-sessions/{bindingSessionId}` | `integration wecom-aibot-binding-session get` |
| GET | `/api/v1/teams/{teamId}/weixin-clawbot-binding-sessions/{bindingSessionId}` | `integration weixin-clawbot-binding-session get` |
| POST | `/api/v1/teams/{teamId}/weixin-clawbot-binding-sessions/{bindingSessionId}/verify-code` | `integration weixin-clawbot-binding-session verify-code create` |
| GET | `/api/v1/teams/{teamId}/workspaces` | `workspace list` |
| POST | `/api/v1/teams/{teamId}/workspaces` | `workspace create` |
| GET | `/api/v1/teams/{teamId}/workspaces/{workspaceId}` | `workspace get` |
| PATCH | `/api/v1/teams/{teamId}/workspaces/{workspaceId}` | `workspace update` |
| POST | `/api/v1/teams/{teamId}/workspaces/{workspaceId}/archive` | `workspace archive create` |
| POST | `/api/v1/teams/{teamId}/workspaces/{workspaceId}/delete` | `workspace delete create` |
| POST | `/api/v1/teams/{teamId}/workspaces/{workspaceId}/restore` | `workspace restore create` |
| POST | `/api/v1/web-sessions/{webSessionId}/close` | `web-session close create` |
| GET | `/api/v1/web-sessions/{webSessionId}/events` | `web-session events list` |
| POST | `/api/v1/web-sessions/{webSessionId}/messages` | `web-session messages create` |
| POST | `/api/v1/web-sessions/{webSessionId}/tool-results` | `web-session tool-results create` |

