# Octopus 通用开发资料包

整理日期：2026-10-12

本资料包用于 Octopus 通用开发与 Workbench / Arcubase 集成，不包含韦达招聘项目的业务代码、业务数据、线上配置或备份。

## 目录

- `开发文档/OctopusDoc/`：Octopus 开发手册，涵盖通用参考、Vibe Coding 与 Workbench、案例模式等内容。
- `SDK/`：官方 `@syngy/octopus-client` SDK 压缩包及补充 SDK 文档包。
- `工具/`：Octopus Helper（Windows）和 Meta Skill 工具包。
- `接口参考/`：Octopus Host API 的参考文档、清单和归档包。
- `示例与复盘/`：Workbench 示例设计包与开发问题复盘材料。

## 建议阅读顺序

1. `开发文档/OctopusDoc/目录说明.md`
2. `开发文档/OctopusDoc/README.md`
3. `开发文档/OctopusDoc/guide/vibe-coding-and-workbench/README.md`
4. `SDK/octopus-sdk-docs.zip`
5. `接口参考/octopus-host-api-reference.md`
6. `示例与复盘/工作台开发问题复盘与技术交流.txt`

## 使用提醒

- 登录、团队身份和权限以 Octopus / Workbench 平台为唯一权威来源。
- Arcubase 访问控制必须使用正式 access rule；前端隐藏按钮不能替代后端权限。
- 生成 SDK 后应执行 TypeScript 检查和生产构建。
- 发布、权限修改、数据写入等线上操作前，应再次核对团队与目标资源。
