import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import { workbenchDevtools } from '@syngy/workbench-devtools'

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, __dirname, '')
  const requiredTeamId = env.WORKBENCH_REQUIRED_TEAM_ID ?? ''
  return {
    plugins: [workbenchDevtools({ requiredTeamId }), react()],
  }
})
