import { useCallback, useEffect, useMemo, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Tabs } from '../components/ui/tabs'
import { STAGE_ORDER } from '../lib/labels'
import { queryAll, readEpoch, selectLabel, table } from '../lib/tables'
import type { ArcubaseRow } from '../arcubase/runtime'
import type { DevOperatorFullAccess5Fields } from '../arcubase/ingresses/devOperatorFullAccess5'
import type { DevOperatorFullAccess4Fields } from '../arcubase/ingresses/devOperatorFullAccess4'
import type { DevOperatorFullAccess2Fields } from '../arcubase/ingresses/devOperatorFullAccess2'
import type { DevOperatorFullAccess13Fields } from '../arcubase/ingresses/devOperatorFullAccess13'
import type { DevOperatorFullAccess14Fields } from '../arcubase/ingresses/devOperatorFullAccess14'
import type { PageCtx } from './DemandsPage'

type PipelineRow = ArcubaseRow<DevOperatorFullAccess5Fields>
type ResumeRow = ArcubaseRow<DevOperatorFullAccess4Fields>
type DemandRow = ArcubaseRow<DevOperatorFullAccess2Fields>
type OfferRow = ArcubaseRow<DevOperatorFullAccess13Fields>
type CheckRow = ArcubaseRow<DevOperatorFullAccess14Fields>

const FUNNEL_COLORS = ['bg-blue-700', 'bg-blue-600', 'bg-blue-500', 'bg-blue-400', 'bg-blue-300', 'bg-blue-200', 'bg-blue-100']

function monthKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
}

function EmptyHint() {
  return <div className="py-10 text-center text-sm text-slate-400">暂无数据</div>
}

export function DashboardPage(_ctx: PageCtx) {
  const [mode, setMode] = useState<'month' | 'week'>('month')
  const [pipelines, setPipelines] = useState<PipelineRow[]>([])
  const [resumes, setResumes] = useState<ResumeRow[]>([])
  const [demands, setDemands] = useState<DemandRow[]>([])
  const [offers, setOffers] = useState<OfferRow[]>([])
  const [checks, setChecks] = useState<CheckRow[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const [p, r, d, o, c] = await Promise.all([
        queryAll(table('pipelines')),
        queryAll(table('resumes')),
        queryAll(table('demands')),
        queryAll(table('offers')),
        queryAll(table('onboardChecks')),
      ])
      setPipelines(p as PipelineRow[])
      setResumes(r as ResumeRow[])
      setDemands(d as DemandRow[])
      setOffers(o as OfferRow[])
      setChecks(c as CheckRow[])
    } catch (err) {
      setError(err instanceof Error ? err.message : '加载失败')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { void load() }, [load])

  const range = useMemo((): [number, number] => {
    const now = new Date()
    if (mode === 'month') {
      const start = new Date(now.getFullYear(), now.getMonth(), 1)
      const end = new Date(now.getFullYear(), now.getMonth() + 1, 1)
      return [Math.floor(start.getTime() / 1000), Math.floor(end.getTime() / 1000)]
    }
    const end = now
    const start = new Date(now.getTime() - 7 * 86400 * 1000)
    return [Math.floor(start.getTime() / 1000), Math.floor(end.getTime() / 1000)]
  }, [mode])

  const stats = useMemo(() => {
    const [from, to] = range
    const inRange = (epoch: number | null) => epoch !== null && epoch >= from && epoch < to

    const arrivedChecks = checks.filter((c) => selectLabel(c.fields.result) === '已到岗' && inRange(readEpoch(c.fields.checkedAt)))
    const actual = arrivedChecks.length

    const currentMonth = monthKey(new Date())
    const planned = demands
      .filter((d) => selectLabel(d.fields.status) === '通过' && d.fields.expectedMonth === currentMonth)
      .reduce((sum, d) => sum + (Number(d.fields.headcount) || 0), 0)

    const pipelineStart = new Map<string, number>()
    for (const p of pipelines) {
      const s = readEpoch(p.fields.startedAt)
      if (s !== null) pipelineStart.set(String(p.id), s)
    }
    const cycles: number[] = []
    for (const c of arrivedChecks) {
      const checkedAt = readEpoch(c.fields.checkedAt)
      const startedAt = pipelineStart.get(String(c.fields.pipelineId))
      if (checkedAt !== null && startedAt !== undefined && checkedAt >= startedAt) {
        cycles.push((checkedAt - startedAt) / 86400)
      }
    }
    const avgCycle = cycles.length > 0 ? cycles.reduce((a, b) => a + b, 0) / cycles.length : null

    const periodOffers = offers.filter((o) => inRange(readEpoch(o.fields.markedAt)))
    const accepted = periodOffers.filter((o) => selectLabel(o.fields.status) === '接受').length
    const offerRate = periodOffers.length > 0 ? accepted / periodOffers.length : null

    return { actual, planned, avgCycle, offerRate }
  }, [range, checks, demands, pipelines, offers])

  const channelDist = useMemo(() => {
    const counts = new Map<string, number>()
    for (const r of resumes) {
      const ch = r.fields.channel ? selectLabel(r.fields.channel) : '其他'
      counts.set(ch, (counts.get(ch) ?? 0) + 1)
    }
    const items = Array.from(counts.entries()).map(([label, count]) => ({ label, count }))
    items.sort((a, b) => b.count - a.count)
    const max = items.length > 0 ? items[0].count : 0
    return { items, max }
  }, [resumes])

  const funnel = useMemo(() => {
    const counts = STAGE_ORDER.map(
      (stage) => pipelines.filter((p) => selectLabel(p.fields.currentStage) === stage).length,
    )
    const max = Math.max(...counts, 0)
    return STAGE_ORDER.map((stage, i) => ({ stage, count: counts[i] })).map((x, i) => ({ ...x, max, color: FUNNEL_COLORS[i] }))
  }, [pipelines])

  const trend = useMemo(() => {
    const now = new Date()
    const months: Array<{ key: string; planned: number; arrived: number }> = []
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const key = monthKey(d)
      const planned = demands
        .filter((x) => selectLabel(x.fields.status) === '通过' && x.fields.expectedMonth === key)
        .reduce((sum, x) => sum + (Number(x.fields.headcount) || 0), 0)
      const next = new Date(d.getFullYear(), d.getMonth() + 1, 1)
      const from = Math.floor(d.getTime() / 1000)
      const to = Math.floor(next.getTime() / 1000)
      const arrived = checks.filter((c) => {
        if (selectLabel(c.fields.result) !== '已到岗') return false
        const e = readEpoch(c.fields.checkedAt)
        return e !== null && e >= from && e < to
      }).length
      months.push({ key, planned, arrived })
    }
    const max = Math.max(...months.flatMap((m) => [m.planned, m.arrived]), 0)
    return { months, max }
  }, [demands, checks])

  const metrics = [
    {
      label: '招聘完成率',
      value: stats.planned > 0 ? `${((stats.actual / stats.planned) * 100).toFixed(1)}%` : '—',
      desc: `实际到岗 ${stats.actual} / 计划 ${stats.planned}`,
    },
    { label: '实际到岗人数', value: String(stats.actual), desc: mode === 'month' ? '本月已到岗' : '近 7 天已到岗' },
    {
      label: '平均招聘周期',
      value: stats.avgCycle !== null ? `${stats.avgCycle.toFixed(1)} 天` : '—',
      desc: '到岗核验时间 − 流程启动时间',
    },
    {
      label: 'Offer 接受率',
      value: stats.offerRate !== null ? `${(stats.offerRate * 100).toFixed(1)}%` : '—',
      desc: '按标记时间统计',
    },
  ]

  return (
    <div className="space-y-4">
      {error ? <div className="rounded-md bg-red-50 px-4 py-3 text-sm text-red-600">{error}</div> : null}

      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-semibold">招聘驾驶舱</h1>
          <p className="text-sm text-slate-500">核心指标与趋势一览，支持按月 / 近 7 天切换。</p>
        </div>
        <Tabs
          value={mode}
          onValueChange={(v) => setMode(v as 'month' | 'week')}
          items={[{ value: 'month', label: '月' }, { value: 'week', label: '周' }]}
        />
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {metrics.map((m) => (
          <Card key={m.label}>
            <CardContent className="py-4">
              <div className="text-sm text-slate-500">{m.label}</div>
              <div className="mt-1 text-3xl font-semibold">{loading ? '…' : m.value}</div>
              <div className="mt-1 text-xs text-slate-400">{m.desc}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>简历来源分布</CardTitle>
            <CardDescription>按渠道统计简历数量。</CardDescription>
          </CardHeader>
          <CardContent>
            {channelDist.items.length === 0 ? <EmptyHint /> : (
              <div className="space-y-3">
                {channelDist.items.map((item) => (
                  <div key={item.label} className="flex items-center gap-3">
                    <div className="w-20 shrink-0 text-sm text-slate-600">{item.label}</div>
                    <div className="h-4 flex-1 overflow-hidden rounded bg-slate-100">
                      <div
                        className="h-full rounded bg-blue-500"
                        style={{ width: `${channelDist.max > 0 ? (item.count / channelDist.max) * 100 : 0}%` }}
                      />
                    </div>
                    <div className="w-10 shrink-0 text-right text-sm font-medium">{item.count}</div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>招聘漏斗</CardTitle>
            <CardDescription>各阶段在办流程数量。</CardDescription>
          </CardHeader>
          <CardContent>
            {funnel.every((f) => f.count === 0) ? <EmptyHint /> : (
              <div className="space-y-2">
                {funnel.map((f) => (
                  <div key={f.stage} className="flex flex-col items-center gap-1">
                    <div
                      className={`flex h-7 items-center justify-center rounded text-xs font-medium text-white ${f.color}`}
                      style={{ width: `${f.max > 0 ? Math.max((f.count / f.max) * 100, 12) : 12}%` }}
                    >
                      {f.count}
                    </div>
                    <div className="text-xs text-slate-500">{f.stage}</div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>计划与到岗趋势</CardTitle>
          <CardDescription>近 6 个月计划到岗人数与实际到岗人数对比。</CardDescription>
        </CardHeader>
        <CardContent>
          {trend.max === 0 ? <EmptyHint /> : (
            <div>
              <div className="flex items-end gap-4">
                {trend.months.map((m) => (
                  <div key={m.key} className="flex flex-1 flex-col items-center gap-2">
                    <div className="flex h-32 items-end gap-1">
                      <div
                        className="w-5 rounded-t bg-slate-300"
                        style={{ height: `${trend.max > 0 ? (m.planned / trend.max) * 128 : 0}px` }}
                        title={`计划 ${m.planned}`}
                      />
                      <div
                        className="w-5 rounded-t bg-blue-500"
                        style={{ height: `${trend.max > 0 ? (m.arrived / trend.max) * 128 : 0}px` }}
                        title={`到岗 ${m.arrived}`}
                      />
                    </div>
                    <div className="text-xs text-slate-500">{m.key}</div>
                    <div className="text-xs text-slate-400">{m.planned} / {m.arrived}</div>
                  </div>
                ))}
              </div>
              <div className="mt-3 flex items-center gap-4 text-xs text-slate-500">
                <span className="flex items-center gap-1"><span className="inline-block h-2.5 w-2.5 rounded-sm bg-slate-300" />计划</span>
                <span className="flex items-center gap-1"><span className="inline-block h-2.5 w-2.5 rounded-sm bg-blue-500" />到岗</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
