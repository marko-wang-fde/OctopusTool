import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Badge } from '../components/ui/badge'
import { Button } from '../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Input } from '../components/ui/input'
import { Label } from '../components/ui/label'
import { Select } from '../components/ui/select'
import { Sheet } from '../components/ui/sheet'
import { Table, TBody, TD, TH, THead, TR, EmptyRow } from '../components/ui/table'
import { CHANNELS, statusTone } from '../lib/labels'
import { getKbFileDownloadUrl, sha256File, uploadKbFile } from '../lib/files'
import { parseResumeWithDigiEmployee } from '../lib/conversation'
import { dt, fmtDateTime, memberLabel, queryAll, selectLabel, table, toEpochSeconds } from '../lib/tables'
import { listDepartments, type DepartmentNode } from '../lib/syngy'
import type { PageCtx } from './DemandsPage'
import type { ArcubaseRow } from '../arcubase/runtime'
import type { DevOperatorFullAccess2Fields } from '../arcubase/ingresses/devOperatorFullAccess2'
import type { DevOperatorFullAccess4Fields } from '../arcubase/ingresses/devOperatorFullAccess4'
import type { DevOperatorFullAccess5Fields } from '../arcubase/ingresses/devOperatorFullAccess5'
import type { DevOperatorFullAccess6Fields } from '../arcubase/ingresses/devOperatorFullAccess6'
import type { DevOperatorFullAccess16Fields } from '../arcubase/ingresses/devOperatorFullAccess16'

type DemandRow = ArcubaseRow<DevOperatorFullAccess2Fields>
type ResumeRow = ArcubaseRow<DevOperatorFullAccess4Fields>
type PipelineRow = ArcubaseRow<DevOperatorFullAccess5Fields>
type MatchRow = ArcubaseRow<DevOperatorFullAccess6Fields>
type MaterialRow = ArcubaseRow<DevOperatorFullAccess16Fields>

/** 统一列表行：每个候选人一行，matches 罗列所有命中的岗位 */
type UnifiedRow = { resume: ResumeRow; matches: MatchRow[] }

/** 自动初筛：简历文本（文件名）与需求岗位关键词重叠度，返回得分与命中词 */
export function autoScore(resumeText: string, demandText: string): { score: number; hits: string[] } {
  const tokens = demandText.split(/[\s,，、/（）()\-·]+/).filter((t) => t.length >= 2)
  const uniq = [...new Set(tokens)]
  const hits = uniq.filter((t) => resumeText.includes(t))
  const score = uniq.length ? Math.round((hits.length / uniq.length) * 100) : 0
  return { score, hits }
}

export function MatchingPage({ viewer }: PageCtx) {
  const [resumes, setResumes] = useState<ResumeRow[]>([])
  const [demands, setDemands] = useState<DemandRow[]>([])
  const [pipelines, setPipelines] = useState<PipelineRow[]>([])
  const [matches, setMatches] = useState<MatchRow[]>([])
  const [materials, setMaterials] = useState<MaterialRow[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const [uploadOpen, setUploadOpen] = useState(false)
  const [uploadChannel, setUploadChannel] = useState('')
  const [uploadFiles, setUploadFiles] = useState<File[]>([])
  const [uploading, setUploading] = useState(false)
  const [dragOver, setDragOver] = useState(false)
  const [uploadSummary, setUploadSummary] = useState<string | null>(null)
  const [uploadConfirmed, setUploadConfirmed] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  /** 匹配详情抽屉 */
  const [detail, setDetail] = useState<UnifiedRow | null>(null)
  /** 推荐进行中（按匹配行 id） */
  const [recommendingId, setRecommendingId] = useState<number | null>(null)
  /** 解析入库进行中（按材料行 id） */
  const [parsingId, setParsingId] = useState<number | null>(null)
  /** 打开原简历 PDF 进行中（按 resume id） */
  const [openingResumeId, setOpeningResumeId] = useState<number | string | null>(null)
  /** 转入储备库进行中（按 resume id） */
  const [poolingId, setPoolingId] = useState<number | null>(null)
  /** 部门树 */
  const [departments, setDepartments] = useState<DepartmentNode[]>([])
  /** 部门推荐抽屉 */
  const [recommendOpen, setRecommendOpen] = useState(false)
  const [recommendResume, setRecommendResume] = useState<ResumeRow | null>(null)
  const [selectedDeptId, setSelectedDeptId] = useState('')
  const [selectedDemandId, setSelectedDemandId] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const [r, d, p, m, mat] = await Promise.all([
        queryAll(table('resumes')),
        queryAll(table('demands')),
        queryAll(table('pipelines')),
        queryAll(table('matches')),
        queryAll(table('resumeMaterials')),
      ])
      setResumes(r as ResumeRow[])
      setDemands(d as DemandRow[])
      setPipelines(p as PipelineRow[])
      setMatches(m as MatchRow[])
      setMaterials(mat as MaterialRow[])
    } catch (err) {
      setError(err instanceof Error ? err.message : '加载失败')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { void load() }, [load])

  useEffect(() => {
    listDepartments().then(setDepartments).catch(() => { /* 部门加载失败不阻塞主流程 */ })
  }, [])

  const demandById = useMemo(() => {
    const map = new Map<string, DemandRow>()
    demands.forEach((d) => map.set(String(d.id), d))
    return map
  }, [demands])

  const pipelineById = useMemo(() => {
    const map = new Map<string, PipelineRow>()
    pipelines.forEach((p) => map.set(String(p.id), p))
    return map
  }, [pipelines])

  /** 统一列表：以候选人为单位，每个简历一行，matches 罗列所有命中的岗位（按得分降序） */
  const unifiedRows = useMemo<UnifiedRow[]>(() => {
    const matchesByResumeId = new Map<string, MatchRow[]>()
    for (const m of matches) {
      const p = pipelineById.get(String(m.fields.pipelineId))
      if (!p) continue
      const rid = String(p.fields.resumeId)
      const arr = matchesByResumeId.get(rid) ?? []
      arr.push(m)
      matchesByResumeId.set(rid, arr)
    }
    const targetResumes = resumes.filter((r) =>
      selectLabel(r.fields.source) === '上传'
      && selectLabel(r.fields.library) === '应聘简历库',
    )
    return targetResumes.map((resume) => ({
      resume,
      matches: (matchesByResumeId.get(String(resume.id)) ?? []).sort((a, b) =>
        Number(b.fields.score ?? 0) - Number(a.fields.score ?? 0),
      ),
    }))
  }, [resumes, matches, pipelineById])

  /** 选中部门下"通过"状态的需求列表 */
  const demandsForSelectedDept = useMemo(() => {
    if (!selectedDeptId) return []
    const dept = departments.find((d) => d.id === selectedDeptId)
    if (!dept) return []
    // 含子部门：部门 path 前缀匹配
    const prefix = dept.path || dept.id
    return demands.filter((d) => {
      if (selectLabel(d.fields.status) !== '通过') return false
      const dpt = String(d.fields.department ?? '')
      if (!dpt) return false
      return dpt === dept.name || dpt === dept.id || dpt.startsWith(prefix)
    })
  }, [demands, departments, selectedDeptId])

  async function submitUpload() {
    if (uploadFiles.length === 0) return
    setUploading(true)
    setError(null)
    setUploadSummary(null)
    let okCount = 0
    const fails: string[] = []
    const batchId = `batch-${Date.now()}`
    try {
      for (const file of uploadFiles) {
        try {
          // 校验格式：支持 PDF / DOCX
          const lower = file.name.toLowerCase()
          const isPdf = file.type === 'application/pdf' || lower.endsWith('.pdf')
          const isDocx = lower.endsWith('.docx')
          if (!isPdf && !isDocx) {
            fails.push(`${file.name}: 仅支持 PDF / DOCX 格式`)
            continue
          }
          if (file.size > 10 * 1024 * 1024) {
            fails.push(`${file.name}: 文件超过 10MB`)
            continue
          }
          // 1. 上传到知识库
          const result = await uploadKbFile(file, batchId)
          // 2. 计算 SHA-256
          const sha256 = await sha256File(file)
          // 3. 写入 T16 简历材料表（不直接建 T3 简历，等 HR 解析入库）
          await table('resumeMaterials').create({
            fileName: result.fileName,
            logicalPath: result.logicalPath,
            sizeBytes: result.sizeBytes,
            sha256,
            batchId,
            contentType: result.contentType || 'application/pdf',
            status: '待解析',
            uploadedBy: viewer.id as any,
            uploadedAt: dt(toEpochSeconds(new Date())),
          })
          okCount += 1
        } catch (err) {
          fails.push(`${file.name}: ${err instanceof Error ? err.message : '失败'}`)
        }
      }
      setUploadSummary(
        `成功上传 ${okCount} 份到知识库` +
        (fails.length ? `；失败 ${fails.length} 份（${fails.join('；')}）` : '') +
        '，请在"待解析材料"中确认入库。',
      )
      setUploadFiles([])
      if (fileInputRef.current) fileInputRef.current.value = ''
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : '上传失败')
    } finally {
      setUploading(false)
    }
  }

  function addFiles(incoming: FileList | File[] | null) {
    if (!incoming) return
    const arr = Array.from(incoming)
    if (!arr.length) return
    setUploadFiles((prev) => [...prev, ...arr])
    setUploadSummary(null)
  }

  function removeFile(idx: number) {
    setUploadFiles((prev) => prev.filter((_, i) => i !== idx))
  }

  /** 解析入库：下载简历文件 → 解析提取内容 → 创建 T3 简历（含字段）→ 自动匹配审批通过的需求 */
  async function parseMaterial(mat: MaterialRow) {
    setParsingId(mat.id)
    setError(null)
    try {
      // 1. 从知识库下载简历文件
      const downloadUrl = await getKbFileDownloadUrl(mat.fields.logicalPath)
      const resp = await fetch(downloadUrl)
      if (!resp.ok) throw new Error(`下载简历失败: ${resp.status}`)
      const blob = await resp.blob()
      const file = new File([blob], mat.fields.fileName, { type: mat.fields.contentType || 'application/pdf' })

      // 2. 调用数字员工解析简历（失败直接标记解析失败，不再回退正则）
      console.log('[parseMaterial] 调用数字员工解析简历...')
      const result = await parseResumeWithDigiEmployee(file)
      const resumeText = result.text
      const fields = result.fields
      console.log('[parseMaterial] 数字员工解析完成:', fields)
      if (!fields.name || !fields.phone) {
        throw new Error(`数字员工未提取到姓名或手机号（name=${fields.name ?? '空'}, phone=${fields.phone ?? '空'}）`)
      }

      // 3. 姓名：直接使用数字员工提取值
      const candidateName = fields.name

      // 4. 查重：手机号或姓名已存在则跳过
      let dup: ResumeRow | undefined
      if (fields.phone) {
        dup = resumes.find((r) => String(r.fields.phone ?? '') === fields.phone)
      }
      if (!dup) {
        dup = resumes.find((r) => String(r.fields.name ?? '') === candidateName && r.fields.phone === (fields.phone ?? ''))
      }
      if (dup) {
        await table('resumeMaterials').update(mat.id, { status: '解析失败', parseError: `同名或同手机号简历已存在（ID ${dup.id}）`, resumeId: String(dup.id) })
        await load()
        return
      }

      // 5. 创建 T3 简历，填入解析提取的字段
      const resumeId = await table('resumes').create({
        name: candidateName,
        phone: fields.phone ?? '',
        gender: fields.gender as any,
        age: fields.age as any,
        education: fields.education as any,
        school: fields.school ?? '',
        workYears: fields.workYears as any,
        skills: fields.skills ?? '',
        expectedSalary: fields.expectedSalary ?? '',
        channel: uploadChannel || '其他',
        library: '应聘简历库',
        pipelineStatus: '未进流程',
        parseStatus: '已解析',
        source: '上传',
        ethnicity: fields.ethnicity ?? '',
        currentCity: fields.currentCity ?? '',
        email: fields.email ?? '',
        expectedPosition: fields.expectedPosition ?? '',
        expectedCity: fields.expectedCity ?? '',
        educationDetail: fields.educationDetail ?? '',
        workExperience: fields.workExperience ?? '',
      })

      // 6. 更新 T16 状态为已解析
      await table('resumeMaterials').update(mat.id, { status: '已解析', resumeId: String(resumeId) })

      // 7. 自动匹配审批通过的需求（用提取的简历文本做关键词匹配）
      const approved = demands.filter((d) => selectLabel(d.fields.status) === '通过')
      const matchTextBase = `${candidateName} ${fields.skills ?? ''} ${fields.school ?? ''} ${fields.education ?? ''} ${resumeText}`
      for (const demand of approved) {
        const demandText = `${demand.fields.jobTitle ?? ''} ${demand.fields.department ?? ''} ${demand.fields.remark ?? ''}`
        const { score, hits } = autoScore(matchTextBase, demandText)
        // 只为"合适"或"待定"的岗位创建 match 行（不合适的不再占行）
        if (score < 30) continue
        const tier = score >= 60 ? '合适' : '待定'
        const now = dt(toEpochSeconds(new Date()))
        const pipelineId = await table('pipelines').create({
          resumeId: String(resumeId),
          demandId: String(demand.id),
          currentStage: '匹配',
          stageTs: now,
          startedAt: now,
        })
        await table('matches').create({
          pipelineId: String(pipelineId),
          tier,
          score,
          details: hits.length ? `命中关键词：${hits.join('、')}` : '未命中岗位关键词',
          source: '自动',
          matchedAt: now,
        })
      }
      await load()
    } catch (err) {
      await table('resumeMaterials').update(mat.id, { status: '解析失败', parseError: err instanceof Error ? err.message : '解析失败' }).catch(() => {})
      setError(err instanceof Error ? err.message : '解析失败')
    } finally {
      setParsingId(null)
    }
  }

  /** 待解析材料 */
  const pendingMaterials = useMemo(() => materials.filter((m) => selectLabel(m.fields.status) === '待解析'), [materials])

  /** 按 resumeId 查关联的简历材料（T16） */
  function materialForResume(resumeId: string | number): MaterialRow | undefined {
    return materials.find((m) => String(m.fields.resumeId) === String(resumeId))
  }

  /** 打开原简历 PDF：通过 T16 关联材料走 KB presign-get，新窗口打开 */
  async function openResumePdf(resumeId: string | number) {
    const mat = materialForResume(resumeId)
    if (!mat?.fields.logicalPath) {
      setError('未找到关联的简历材料，无法查看原简历')
      return
    }
    setOpeningResumeId(resumeId)
    setError(null)
    try {
      const url = await getKbFileDownloadUrl(mat.fields.logicalPath)
      window.open(url, '_blank', 'noopener,noreferrer')
    } catch (err) {
      setError(err instanceof Error ? err.message : '获取简历链接失败')
    } finally {
      setOpeningResumeId(null)
    }
  }

  /** 转入储备人才库：将 T3 简历库标记改为"储备人才库"（不入任何 match 行） */
  async function transferToTalentPool(resume: ResumeRow) {
    setPoolingId(resume.id)
    setError(null)
    try {
      await table('resumes').update(resume.id, { library: '储备人才库' })
      setDetail(null)
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : '转入储备人才库失败')
    } finally {
      setPoolingId(null)
    }
  }

  /** 部门推荐：HR 选定部门下审批通过的需求，创建 pipeline + 推荐记录 */
  async function recommendOrphan() {
    if (!recommendResume || !selectedDemandId) return
    const demand = demandById.get(selectedDemandId)
    if (!demand) {
      setError('请选择有效的岗位需求')
      return
    }
    setRecommendingId(recommendResume.id)
    setError(null)
    try {
      const receiver = demand.fields.departmentOwner || demand.fields.proposer
      const now = dt(toEpochSeconds(new Date()))
      const pipelineId = await table('pipelines').create({
        resumeId: String(recommendResume.id),
        demandId: String(demand.id),
        currentStage: '待推荐',
        stageTs: now,
        startedAt: now,
      })
      await table('recommendations').create({
        pipelineId: String(pipelineId),
        recommender: viewer.id,
        receiver: receiver as any,
        aiSummary: `人事专员手动推荐 ${recommendResume.fields.name} 至「${demand.fields.jobTitle}」岗位。`,
        deptFeedback: '未反馈',
        feedbackChannel: '工作台',
      })
      await table('resumes').update(recommendResume.id, { pipelineStatus: '待推荐' })
      setRecommendOpen(false)
      setRecommendResume(null)
      setSelectedDeptId('')
      setSelectedDemandId('')
      setDetail(null)
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : '推荐失败')
    } finally {
      setRecommendingId(null)
    }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex-row items-center justify-between gap-3">
          <div>
            <CardTitle>简历匹配</CardTitle>
            <CardDescription>上传 PDF 简历到知识库，HR 在"待解析材料"中确认入库后自动匹配。</CardDescription>
          </div>
          <Button type="button" onClick={() => { setUploadOpen(true); setUploadSummary(null); setUploadConfirmed(false) }}>上传简历</Button>
        </CardHeader>
        {uploadSummary ? (
          <CardContent>
            <div className="rounded border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-700">
              {uploadSummary}
            </div>
          </CardContent>
        ) : null}
      </Card>

      {/* 待解析材料 */}
      <Card>
        <CardHeader className="flex-row items-center justify-between gap-3">
          <div>
            <CardTitle>待解析材料</CardTitle>
            <CardDescription>上传的简历先存知识库，HR 确认后才入库并自动匹配。</CardDescription>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <THead>
              <TR>
                <TH>文件名</TH><TH>大小</TH><TH>SHA-256</TH><TH>批次号</TH><TH>上传人</TH><TH>上传时间</TH><TH>操作</TH>
              </TR>
            </THead>
            <TBody>
              {!loading && pendingMaterials.length === 0 ? <EmptyRow colSpan={7} text="暂无待解析材料" /> : null}
              {pendingMaterials.map((m) => (
                <TR key={m.id}>
                  <TD className="max-w-[240px] truncate" title={m.fields.fileName}>{m.fields.fileName}</TD>
                  <TD>{m.fields.sizeBytes ? `${(m.fields.sizeBytes / 1024).toFixed(1)} KB` : '—'}</TD>
                  <TD className="max-w-[140px] truncate font-mono text-xs" title={m.fields.sha256}>{m.fields.sha256 ? m.fields.sha256.slice(0, 12) + '…' : '—'}</TD>
                  <TD className="text-xs text-slate-500">{m.fields.batchId ?? '—'}</TD>
                  <TD>{memberLabel(m.fields.uploadedBy)}</TD>
                  <TD>{fmtDateTime(m.fields.uploadedAt)}</TD>
                  <TD>
                    <Button size="sm" onClick={() => parseMaterial(m)} disabled={parsingId === m.id}>
                      {parsingId === m.id ? 'AI 解析中…' : '解析入库'}
                    </Button>
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex-row items-center justify-between gap-3">
          <div>
            <CardTitle>匹配结果</CardTitle>
            <CardDescription>每个候选人一行，岗位栏罗列所有匹配岗位；未命中则岗位空着。点击详情可部门推荐或转入储备库。</CardDescription>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {error ? <div className="px-4 py-3 text-sm text-red-600">{error}</div> : null}
          <Table>
            <THead>
              <TR>
                <TH>候选人</TH><TH>岗位</TH><TH>匹配度</TH><TH>得分</TH><TH>评估说明</TH><TH>来源</TH><TH>匹配时间</TH><TH>操作</TH>
              </TR>
            </THead>
            <TBody>
              {loading ? <EmptyRow colSpan={8} text="加载中…" /> : null}
              {!loading && unifiedRows.length === 0 ? <EmptyRow colSpan={8} /> : null}
              {unifiedRows.map((row) => {
                const { resume, matches: ms } = row
                const jobTitles = ms.map((m) => {
                  const p = pipelineById.get(String(m.fields.pipelineId))
                  const d = p ? demandById.get(String(p.fields.demandId)) : undefined
                  return d?.fields.jobTitle ?? '—'
                })
                const bestTier = ms.length ? selectLabel(ms[0].fields.tier) : ''
                const bestScore = ms.length ? Math.max(...ms.map((m) => Number(m.fields.score ?? 0))) : null
                const topDetails = ms.length ? (ms[0].fields.details || '—') : '未命中任何岗位'
                const lastMatch = ms.length ? ms[ms.length - 1] : null
                return (
                  <TR key={resume.id}>
                    <TD className="font-medium">{resume.fields.name ?? '—'}</TD>
                    <TD className="max-w-48">{ms.length ? jobTitles.join('、') : <span className="text-slate-400">—</span>}</TD>
                    <TD>{bestTier ? <Badge tone={statusTone(bestTier)}>{bestTier}</Badge> : <Badge tone="slate">无</Badge>}</TD>
                    <TD>{bestScore !== null ? `${bestScore}%` : '—'}</TD>
                    <TD className="max-w-64 truncate" title={topDetails}>{topDetails}</TD>
                    <TD>{selectLabel(resume.fields.source)}</TD>
                    <TD>{lastMatch ? fmtDateTime(lastMatch.fields.matchedAt) : '—'}</TD>
                    <TD>
                      <Button type="button" size="sm" variant="outline" onClick={() => setDetail(row)}>详情</Button>
                    </TD>
                  </TR>
                )
              })}
            </TBody>
          </Table>
        </CardContent>
      </Card>

      {/* 匹配详情抽屉 */}
      <Sheet
        open={detail !== null}
        onOpenChange={(open) => { if (!open) setDetail(null) }}
        title="匹配详情"
        footer={<Button type="button" variant="outline" onClick={() => setDetail(null)}>关闭</Button>}
      >
        {detail ? (() => {
          const { resume, matches: ms } = detail
          const mat = materialForResume(resume.id)
          const hasAny = resume.fields.gender || resume.fields.age || resume.fields.education || resume.fields.workYears || resume.fields.expectedSalary || resume.fields.skills || resume.fields.school
          return (
            <div className="space-y-5">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="text-xs text-slate-500">候选人</div>
                  <div className="text-base font-medium">{resume.fields.name ?? '—'}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">渠道</div>
                  <div className="mt-0.5 text-sm">{selectLabel(resume.fields.channel) || '—'}</div>
                </div>
              </div>

              {/* 匹配岗位列表 */}
              <div>
                <div className="mb-1 text-xs text-slate-500">匹配岗位（{ms.length}）</div>
                {ms.length === 0 ? (
                  <div className="rounded bg-amber-50 px-3 py-2 text-sm text-amber-800">
                    该简历未命中任何岗位，可选择「部门推荐」人工推送给部门领导，或「转入储备人才库」归档。
                  </div>
                ) : (
                  <div className="space-y-2">
                    {ms.map((m) => {
                      const p = pipelineById.get(String(m.fields.pipelineId))
                      const d = p ? demandById.get(String(p.fields.demandId)) : undefined
                      const tier = selectLabel(m.fields.tier)
                      return (
                        <div key={m.id} className="rounded border border-slate-200 p-2 text-sm">
                          <div className="flex items-center justify-between">
                            <span className="font-medium">{d?.fields.jobTitle ?? '—'}</span>
                            <Badge tone={statusTone(tier)}>{tier}</Badge>
                          </div>
                          <div className="mt-1 flex justify-between text-xs text-slate-500">
                            <span>得分 {m.fields.score ?? 0}%</span>
                            <span>{selectLabel(m.fields.source)} · {fmtDateTime(m.fields.matchedAt)}</span>
                          </div>
                          <div className="mt-1 text-xs">{m.fields.details || '—'}</div>
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>

              {/* 人才信息 */}
              <div className="rounded border border-slate-200 p-3">
                <div className="mb-2 flex items-center justify-between">
                  <div className="text-sm font-medium text-slate-700">人才信息</div>
                  {mat?.fields.logicalPath ? (
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      disabled={openingResumeId === resume.id}
                      onClick={() => void openResumePdf(resume.id)}
                    >
                      {openingResumeId === resume.id ? '获取中…' : '查看原简历'}
                    </Button>
                  ) : null}
                </div>
                {!hasAny ? (
                  <div className="mb-2 rounded bg-amber-50 px-2 py-1 text-xs text-amber-800">
                    候选人档案字段未填写，请点击"查看原简历"查看 PDF 内容，或在人才库中编辑补充。
                  </div>
                ) : null}
                <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                  <div><span className="text-xs text-slate-500">姓名</span> {resume.fields.name ?? '—'}</div>
                  <div><span className="text-xs text-slate-500">性别</span> {selectLabel(resume.fields.gender) || '—'}</div>
                  <div><span className="text-xs text-slate-500">年龄</span> {resume.fields.age != null ? `${resume.fields.age}岁` : '—'}</div>
                  <div><span className="text-xs text-slate-500">民族</span> {resume.fields.ethnicity || '—'}</div>
                  <div><span className="text-xs text-slate-500">现居地</span> {resume.fields.currentCity || '—'}</div>
                  <div><span className="text-xs text-slate-500">工作经验</span> {resume.fields.workYears != null ? `${resume.fields.workYears}年` : '—'}</div>
                  <div><span className="text-xs text-slate-500">到岗时间</span> {fmtDateTime(resume.fields.availableDate)}</div>
                  <div><span className="text-xs text-slate-500">电话</span> {resume.fields.phone || '—'}</div>
                  <div><span className="text-xs text-slate-500">邮箱</span> {resume.fields.email || '—'}</div>
                  <div><span className="text-xs text-slate-500">应聘职位</span> {resume.fields.expectedPosition || '—'}</div>
                  <div><span className="text-xs text-slate-500">期望薪资</span> {resume.fields.expectedSalary || '—'}</div>
                  <div><span className="text-xs text-slate-500">期望城市</span> {resume.fields.expectedCity || '—'}</div>
                </div>
                <div className="mt-3 border-t border-slate-100 pt-3">
                  <div className="mb-1 text-xs font-medium text-slate-500">教育背景</div>
                  <div className="whitespace-pre-wrap text-sm leading-[150%] text-slate-700">{resume.fields.educationDetail || resume.fields.school || '—'}</div>
                </div>
                <div className="mt-3 border-t border-slate-100 pt-3">
                  <div className="mb-1 text-xs font-medium text-slate-500">工作经历</div>
                  <div className="whitespace-pre-wrap text-sm leading-[150%] text-slate-700">{resume.fields.workExperience || '—'}</div>
                </div>
                <div className="mt-3 border-t border-slate-100 pt-3">
                  <div className="mb-1 text-xs font-medium text-slate-500">技能</div>
                  <div className="text-sm leading-[150%] text-slate-700">{resume.fields.skills || '—'}</div>
                </div>
              </div>

              {/* 底部操作 */}
              <div className="flex gap-2 border-t border-slate-200 pt-3">
                <Button type="button" size="sm" onClick={() => { setRecommendResume(resume); setRecommendOpen(true) }}>部门推荐</Button>
                <Button type="button" size="sm" variant="outline" disabled={poolingId === resume.id} onClick={() => void transferToTalentPool(resume)}>
                  {poolingId === resume.id ? '转入中…' : '转入储备人才库'}
                </Button>
              </div>
            </div>
          )
        })() : null}
      </Sheet>

      <Sheet
        open={uploadOpen}
        onOpenChange={setUploadOpen}
        title="上传简历"
        description="PDF 简历上传到知识库，HR 确认后入库。"
        footer={
          <>
            <Button type="button" variant="outline" onClick={() => setUploadOpen(false)}>关闭</Button>
            <Button
              type="button"
              disabled={uploading || uploadFiles.length === 0 || !uploadConfirmed}
              onClick={() => void submitUpload().then(() => setUploadOpen(false))}
            >
              {uploading ? '上传中…' : `上传 ${uploadFiles.length} 份`}
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label>简历渠道 *</Label>
            <Select value={uploadChannel} onChange={(e) => setUploadChannel(e.target.value)}>
              <option value="">请选择</option>
              {CHANNELS.map((c) => <option key={c} value={c}>{c}</option>)}
            </Select>
          </div>

          <div
            onDragOver={(e) => { e.preventDefault(); setDragOver(true) }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault()
              setDragOver(false)
              addFiles(e.dataTransfer.files)
            }}
            onClick={() => fileInputRef.current?.click()}
            className={`cursor-pointer rounded-lg border-2 border-dashed px-4 py-10 text-center transition-colors ${
              dragOver ? 'border-blue-400 bg-blue-50' : 'border-slate-200 bg-slate-50 hover:border-slate-300'
            }`}
          >
            <div className="text-sm text-slate-600">
              拖入简历文件，或点击选择
            </div>
            <div className="mt-1 text-xs text-slate-400">支持 PDF / DOCX 格式，单文件 ≤ 10MB，可多选</div>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".pdf,.docx"
              className="hidden"
              onChange={(e) => addFiles(e.target.files)}
            />
          </div>

          {uploadFiles.length > 0 ? (
            <div className="space-y-1.5">
              <Label>待上传（{uploadFiles.length}）</Label>
              <div className="max-h-48 space-y-1 overflow-y-auto rounded border border-slate-200 bg-white p-2">
                {uploadFiles.map((f, i) => (
                  <div key={`${f.name}-${i}`} className="flex items-center justify-between gap-2 rounded px-2 py-1 text-sm hover:bg-slate-50">
                    <div className="min-w-0 flex-1 truncate">{f.name}</div>
                    <div className="shrink-0 text-xs text-slate-400">{(f.size / 1024).toFixed(0)} KB</div>
                    <Button type="button" variant="outline" size="sm" onClick={() => removeFile(i)}>移除</Button>
                  </div>
                ))}
              </div>
            </div>
          ) : null}

          <label className="flex items-start gap-2 rounded bg-amber-50 px-3 py-2 text-xs text-amber-800">
            <input
              type="checkbox"
              checked={uploadConfirmed}
              onChange={(e) => setUploadConfirmed(e.target.checked)}
              className="mt-0.5"
            />
            <span>本人确认上述简历不含身份证、银行卡等私密原件，且同意团队内（人事专员/人事经理）可查看。</span>
          </label>

          <div className="rounded bg-slate-50 px-3 py-2 text-xs text-slate-500">
            上传后：① 文件存入知识库 ② 写入简历材料表，状态=待解析 ③ HR 点"解析入库"后自动提取简历信息并匹配岗位
          </div>
        </div>
      </Sheet>

      {/* 部门推荐抽屉 */}
      <Sheet
        open={recommendOpen}
        onOpenChange={(open) => {
          if (!open) {
            setRecommendOpen(false)
            setRecommendResume(null)
            setSelectedDeptId('')
            setSelectedDemandId('')
          }
        }}
        title="部门推荐"
        description="选择部门及审批通过的岗位需求，将简历推送给部门领导（默认）或需求提出人。"
        footer={
          <>
            <Button type="button" variant="outline" onClick={() => setRecommendOpen(false)}>取消</Button>
            <Button
              type="button"
              disabled={!recommendResume || !selectedDemandId || (recommendResume ? recommendingId === recommendResume.id : false)}
              onClick={() => void recommendOrphan()}
            >
              {recommendResume && recommendingId === recommendResume.id ? '推荐中…' : '确认推荐'}
            </Button>
          </>
        }
      >
        {recommendResume ? (
          <div className="space-y-4">
            <div>
              <div className="text-xs text-slate-500">候选人</div>
              <div className="text-base font-medium">{recommendResume.fields.name ?? '—'}</div>
            </div>

            <div className="space-y-1.5">
              <Label>部门 *</Label>
              <Select
                value={selectedDeptId}
                onChange={(e) => { setSelectedDeptId(e.target.value); setSelectedDemandId('') }}
              >
                <option value="">请选择部门</option>
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label>岗位需求 *</Label>
              <Select value={selectedDemandId} onChange={(e) => setSelectedDemandId(e.target.value)}>
                <option value="">{selectedDeptId ? '请选择岗位' : '请先选择部门'}</option>
                {demandsForSelectedDept.map((d) => (
                  <option key={d.id} value={String(d.id)}>
                    {d.fields.jobTitle ?? '—'}（{d.fields.department ?? '—'}，{selectLabel(d.fields.status)}）
                  </option>
                ))}
              </Select>
              {selectedDeptId && demandsForSelectedDept.length === 0 ? (
                <div className="rounded bg-amber-50 px-2 py-1 text-xs text-amber-800">
                  该部门下暂无"通过"状态的用人需求，请先到用人需求管理审批后再推荐。
                </div>
              ) : null}
            </div>

            <div className="rounded bg-slate-50 px-3 py-2 text-xs text-slate-500">
              提交后：① 创建招聘流程实例 ② 创建推荐记录，接收人=部门负责人（或需求提出人） ③ 简历状态变为"待推荐"，进入「人才推荐」页待部门反馈。
            </div>
          </div>
        ) : null}
      </Sheet>
    </div>
  )
}
