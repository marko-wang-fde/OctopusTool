import { useCallback, useEffect, useMemo, useState } from 'react'
import { Badge } from '../components/ui/badge'
import { Button } from '../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Dialog } from '../components/ui/dialog'
import { Label } from '../components/ui/label'
import { Table, TBody, TD, TH, THead, TR, EmptyRow } from '../components/ui/table'
import { Textarea } from '../components/ui/textarea'
import { ONBOARD_RESULTS, statusTone } from '../lib/labels'
import { dt, fmtDateTime, memberLabel, queryAll, selectLabel, table, toEpochSeconds } from '../lib/tables'
import type { PageCtx } from './DemandsPage'
import type { ArcubaseRow } from '../arcubase/runtime'
import type { DevOperatorFullAccess2Fields } from '../arcubase/ingresses/devOperatorFullAccess2'
import type { DevOperatorFullAccess4Fields } from '../arcubase/ingresses/devOperatorFullAccess4'
import type { DevOperatorFullAccess5Fields } from '../arcubase/ingresses/devOperatorFullAccess5'
import type { DevOperatorFullAccess13Fields } from '../arcubase/ingresses/devOperatorFullAccess13'
import type { DevOperatorFullAccess14Fields } from '../arcubase/ingresses/devOperatorFullAccess14'

type PipelineRow = ArcubaseRow<DevOperatorFullAccess5Fields>
type ResumeRow = ArcubaseRow<DevOperatorFullAccess4Fields>
type DemandRow = ArcubaseRow<DevOperatorFullAccess2Fields>
type OfferRow = ArcubaseRow<DevOperatorFullAccess13Fields>
type CheckRow = ArcubaseRow<DevOperatorFullAccess14Fields>

type OnboardResult = (typeof ONBOARD_RESULTS)[number]

const RESULT_LIBRARY: Record<OnboardResult, string> = {
  已到岗: '在职员工库',
  提前说明不来: '储备人才库',
  无故未到: '风险受控',
}

export function OnboardPage({ viewer }: PageCtx) {
  const [pipelines, setPipelines] = useState<PipelineRow[]>([])
  const [resumes, setResumes] = useState<ResumeRow[]>([])
  const [demands, setDemands] = useState<DemandRow[]>([])
  const [offers, setOffers] = useState<OfferRow[]>([])
  const [checks, setChecks] = useState<CheckRow[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const [checkTarget, setCheckTarget] = useState<{ pipeline: PipelineRow; result: OnboardResult } | null>(null)
  const [remark, setRemark] = useState('')
  const [saving, setSaving] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const [p, r, d, o, c] = await Promise.all([
        queryAll(table('pipelines')),
        queryAll(table('resumes')),
        queryAll(table('demands')),
        queryAll(table('offers')),
        queryAll(table('onboardChecks')),
      ])
      setPipelines(p as PipelineRow[])
      setResumes(r as ResumeRow[])
      setDemands(d as DemandRow[])
      setOffers(o as OfferRow[])
      setChecks(c as CheckRow[])
    } catch (err) {
      setError(err instanceof Error ? err.message : '加载失败')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { void load() }, [load])

  const resumeById = useMemo(() => new Map(resumes.map((r) => [String(r.id), r])), [resumes])
  const demandById = useMemo(() => new Map(demands.map((d) => [String(d.id), d])), [demands])
  const pipelineById = useMemo(() => new Map(pipelines.map((p) => [String(p.id), p])), [pipelines])

  const acceptedOfferByPipeline = useMemo(() => {
    const map = new Map<string, OfferRow>()
    for (const o of offers) {
      if (selectLabel(o.fields.status) === '接受') map.set(String(o.fields.pipelineId ?? ''), o)
    }
    return map
  }, [offers])

  const checkablePipelines = useMemo(
    () => pipelines.filter(
      (p) => selectLabel(p.fields.currentStage) === '核验' && acceptedOfferByPipeline.has(String(p.id)),
    ),
    [pipelines, acceptedOfferByPipeline],
  )

  function candidateName(p: PipelineRow): string {
    return resumeById.get(String(p.fields.resumeId))?.fields.name ?? String(p.fields.resumeId)
  }
  function jobTitleOf(p: PipelineRow): string {
    return demandById.get(String(p.fields.demandId))?.fields.jobTitle ?? String(p.fields.demandId)
  }

  async function submitCheck() {
    if (!checkTarget) return
    const { pipeline, result } = checkTarget
    setSaving(true)
    setError(null)
    try {
      const now = dt(toEpochSeconds(new Date()))
      await table('onboardChecks').create({
        pipelineId: String(pipeline.id),
        result,
        checkedBy: viewer.id,
        checkedAt: now,
        remark: remark.trim() || undefined,
      })
      await table('resumes').update(pipeline.fields.resumeId, {
        library: RESULT_LIBRARY[result],
        pipelineStatus: '结束',
      })
      await table('pipelines').update(pipeline.id, { currentStage: '结束', stageTs: now })
      setCheckTarget(null)
      setRemark('')
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : '核验失败')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>到岗核验</CardTitle>
          <CardDescription>仅 Offer 已被接受的候选人可核验；核验后流程结束，简历按结果自动归档。</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {error ? <div className="px-4 py-3 text-sm text-red-600">{error}</div> : null}
          <Table>
            <THead>
              <TR>
                <TH>候选人</TH><TH>岗位</TH><TH>Offer 接受时间</TH><TH>操作</TH>
              </TR>
            </THead>
            <TBody>
              {loading ? <EmptyRow colSpan={4} text="加载中…" /> : null}
              {!loading && checkablePipelines.length === 0 ? <EmptyRow colSpan={4} /> : null}
              {checkablePipelines.map((p) => {
                const offer = acceptedOfferByPipeline.get(String(p.id))
                return (
                  <TR key={p.id}>
                    <TD className="font-medium">{candidateName(p)}</TD>
                    <TD>{jobTitleOf(p)}</TD>
                    <TD>{offer?.fields.markedAt ? fmtDateTime(offer.fields.markedAt) : '—'}</TD>
                    <TD>
                      <div className="flex gap-1">
                        {ONBOARD_RESULTS.map((r) => (
                          <Button
                            key={r}
                            type="button"
                            variant={r === '已到岗' ? 'default' : 'outline'}
                            className="h-8 px-2 text-xs"
                            onClick={() => { setCheckTarget({ pipeline: p, result: r }); setRemark('') }}
                          >
                            {r}
                          </Button>
                        ))}
                      </div>
                    </TD>
                  </TR>
                )
              })}
            </TBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>核验历史</CardTitle>
          <CardDescription>全部到岗核验记录。</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <THead>
              <TR>
                <TH>候选人</TH><TH>结果</TH><TH>核验人</TH><TH>核验时间</TH><TH>备注</TH>
              </TR>
            </THead>
            <TBody>
              {loading ? <EmptyRow colSpan={5} text="加载中…" /> : null}
              {!loading && checks.length === 0 ? <EmptyRow colSpan={5} /> : null}
              {checks.map((c) => {
                const p = pipelineById.get(String(c.fields.pipelineId))
                const result = selectLabel(c.fields.result)
                return (
                  <TR key={c.id}>
                    <TD className="font-medium">{p ? candidateName(p) : String(c.fields.pipelineId)}</TD>
                    <TD><Badge tone={statusTone(result)}>{result}</Badge></TD>
                    <TD>{memberLabel(c.fields.checkedBy)}</TD>
                    <TD>{c.fields.checkedAt ? fmtDateTime(c.fields.checkedAt) : '—'}</TD>
                    <TD>{c.fields.remark || '—'}</TD>
                  </TR>
                )
              })}
            </TBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog
        open={checkTarget !== null}
        onOpenChange={(open) => !open && setCheckTarget(null)}
        title={checkTarget ? `到岗核验：${checkTarget.result}` : ''}
        description={checkTarget ? `候选人：${candidateName(checkTarget.pipeline)}；核验后流程结束，简历将归入「${RESULT_LIBRARY[checkTarget.result]}」。` : undefined}
        footer={
          <>
            <Button type="button" variant="outline" onClick={() => setCheckTarget(null)}>取消</Button>
            <Button type="button" disabled={saving} onClick={() => void submitCheck()}>
              {saving ? '提交中…' : '确认'}
            </Button>
          </>
        }
      >
        <div className="space-y-1.5">
          <Label>备注（可选）</Label>
          <Textarea value={remark} onChange={(e) => setRemark(e.target.value)} />
        </div>
      </Dialog>
    </div>
  )
}
