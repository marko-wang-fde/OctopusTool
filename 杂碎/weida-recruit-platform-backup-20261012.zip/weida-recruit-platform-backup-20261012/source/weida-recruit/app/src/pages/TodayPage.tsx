import { useCallback, useEffect, useMemo, useState } from 'react'
import { navigate } from '../App'
import { Badge } from '../components/ui/badge'
import { Button } from '../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Table, TBody, TD, TH, THead, TR, EmptyRow } from '../components/ui/table'
import { statusTone } from '../lib/labels'
import { fmtDateTime, memberLabel, queryAll, readEpoch, selectLabel, table } from '../lib/tables'
import type { ArcubaseRow } from '../arcubase/runtime'
import type { DevOperatorFullAccess15Fields } from '../arcubase/ingresses/devOperatorFullAccess15'
import type { DevOperatorFullAccess2Fields } from '../arcubase/ingresses/devOperatorFullAccess2'
import type { DevOperatorFullAccess12Fields } from '../arcubase/ingresses/devOperatorFullAccess12'
import type { DevOperatorFullAccess7Fields } from '../arcubase/ingresses/devOperatorFullAccess7'
import type { PageCtx } from './DemandsPage'

type ReminderRow = ArcubaseRow<DevOperatorFullAccess15Fields>
type DemandRow = ArcubaseRow<DevOperatorFullAccess2Fields>
type SalaryRow = ArcubaseRow<DevOperatorFullAccess12Fields>
type RecommendationRow = ArcubaseRow<DevOperatorFullAccess7Fields>

function startOfToday(): number {
  const d = new Date()
  d.setHours(0, 0, 0, 0)
  return Math.floor(d.getTime() / 1000)
}

export function TodayPage(_ctx: PageCtx) {
  const [reminders, setReminders] = useState<ReminderRow[]>([])
  const [demands, setDemands] = useState<DemandRow[]>([])
  const [salaries, setSalaries] = useState<SalaryRow[]>([])
  const [recommendations, setRecommendations] = useState<RecommendationRow[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const [r, d, s, rec] = await Promise.all([
        queryAll(table('reminders')),
        queryAll(table('demands')),
        queryAll(table('salaries')),
        queryAll(table('recommendations')),
      ])
      setReminders(r as ReminderRow[])
      setDemands(d as DemandRow[])
      setSalaries(s as SalaryRow[])
      setRecommendations(rec as RecommendationRow[])
    } catch (err) {
      setError(err instanceof Error ? err.message : '加载失败')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { void load() }, [load])

  const activeReminders = useMemo(() => {
    const todayStart = startOfToday()
    return reminders.filter((r) => {
      const status = selectLabel(r.fields.status)
      if (status === '待发') return true
      if (status === '已发') {
        const planned = readEpoch(r.fields.plannedAt)
        return planned !== null && planned < todayStart
      }
      return false
    })
  }, [reminders])

  const pendingDemands = useMemo(
    () => demands.filter((d) => selectLabel(d.fields.status) === '待审批'),
    [demands],
  )
  const pendingSalaries = useMemo(
    () => salaries.filter((s) => selectLabel(s.fields.status) === '待审批'),
    [salaries],
  )
  const unfedRecommendations = useMemo(
    () => recommendations.filter((r) => selectLabel(r.fields.deptFeedback) === '未反馈'),
    [recommendations],
  )

  const stats = [
    { label: '待发提醒', value: activeReminders.length },
    { label: '待审批需求', value: pendingDemands.length },
    { label: '待审批拟薪', value: pendingSalaries.length },
    { label: '未反馈推荐', value: unfedRecommendations.length },
  ]

  return (
    <div className="space-y-4">
      {error ? <div className="rounded-md bg-red-50 px-4 py-3 text-sm text-red-600">{error}</div> : null}

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label}>
            <CardContent className="py-4">
              <div className="text-sm text-slate-500">{s.label}</div>
              <div className="mt-1 text-2xl font-semibold">{loading ? '…' : s.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>提醒任务</CardTitle>
          <CardDescription>待发或已发但计划时间已过的提醒。</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <THead>
              <TR>
                <TH>类型</TH><TH>关联</TH><TH>对象</TH><TH>渠道</TH><TH>计划时间</TH><TH>已重发</TH>
              </TR>
            </THead>
            <TBody>
              {loading ? <EmptyRow colSpan={6} text="加载中…" /> : null}
              {!loading && activeReminders.length === 0 ? <EmptyRow colSpan={6} /> : null}
              {activeReminders.map((row) => {
                const f = row.fields
                const type = selectLabel(f.type)
                return (
                  <TR key={row.id}>
                    <TD><Badge tone={statusTone(type)}>{type}</Badge></TD>
                    <TD>{f.refType ? `${selectLabel(f.refType)} #${f.refId ?? '—'}` : '—'}</TD>
                    <TD>{memberLabel(f.target)}</TD>
                    <TD>{f.channel ? selectLabel(f.channel) : '—'}</TD>
                    <TD>{f.plannedAt ? fmtDateTime(f.plannedAt) : '—'}</TD>
                    <TD>{f.resendCount ?? 0}</TD>
                  </TR>
                )
              })}
            </TBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>待审批需求</CardTitle>
          <CardDescription>用人需求单等待人事经理审批。</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <THead>
              <TR>
                <TH>岗位</TH><TH>部门</TH><TH>人数</TH><TH>期望到岗月</TH><TH>提出人</TH><TH>操作</TH>
              </TR>
            </THead>
            <TBody>
              {loading ? <EmptyRow colSpan={6} text="加载中…" /> : null}
              {!loading && pendingDemands.length === 0 ? <EmptyRow colSpan={6} /> : null}
              {pendingDemands.map((row) => {
                const f = row.fields
                return (
                  <TR key={row.id}>
                    <TD className="font-medium">{f.jobTitle}</TD>
                    <TD>{f.department || '—'}</TD>
                    <TD>{f.headcount}</TD>
                    <TD>{f.expectedMonth || '—'}</TD>
                    <TD>{memberLabel(f.proposer)}</TD>
                    <TD>
                      <Button type="button" size="sm" variant="outline" onClick={() => navigate('/demands')}>
                        前往审批
                      </Button>
                    </TD>
                  </TR>
                )
              })}
            </TBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>待审批拟薪</CardTitle>
          <CardDescription>拟薪单待审批，金额在背调与拟薪页处理。</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <THead>
              <TR>
                <TH>流程编号</TH><TH>状态</TH><TH>操作</TH>
              </TR>
            </THead>
            <TBody>
              {loading ? <EmptyRow colSpan={3} text="加载中…" /> : null}
              {!loading && pendingSalaries.length === 0 ? <EmptyRow colSpan={3} /> : null}
              {pendingSalaries.map((row) => (
                <TR key={row.id}>
                  <TD className="font-medium">{row.fields.pipelineId}</TD>
                  <TD><Badge tone={statusTone(selectLabel(row.fields.status))}>{selectLabel(row.fields.status)}</Badge></TD>
                  <TD>
                    <Button type="button" size="sm" variant="outline" onClick={() => navigate('/recruit/screening')}>
                      前往背调与拟薪处理
                    </Button>
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>未反馈推荐</CardTitle>
          <CardDescription>部门尚未反馈的推荐记录。</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <THead>
              <TR>
                <TH>流程编号</TH><TH>推荐人</TH><TH>接收人</TH>
              </TR>
            </THead>
            <TBody>
              {loading ? <EmptyRow colSpan={3} text="加载中…" /> : null}
              {!loading && unfedRecommendations.length === 0 ? <EmptyRow colSpan={3} /> : null}
              {unfedRecommendations.map((row) => (
                <TR key={row.id}>
                  <TD className="font-medium">{row.fields.pipelineId}</TD>
                  <TD>{memberLabel(row.fields.recommender)}</TD>
                  <TD>{memberLabel(row.fields.receiver)}</TD>
                </TR>
              ))}
            </TBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
