import { useCallback, useEffect, useMemo, useState } from 'react'
import { Badge } from '../components/ui/badge'
import { Button } from '../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Input } from '../components/ui/input'
import { Label } from '../components/ui/label'
import { Select } from '../components/ui/select'
import { Sheet } from '../components/ui/sheet'
import { Table, TBody, TD, TH, THead, TR, EmptyRow } from '../components/ui/table'
import { Textarea } from '../components/ui/textarea'
import { DEMAND_STATUS, PROPOSER_ROLES, statusTone } from '../lib/labels'
import type { BusinessRole } from '../lib/roles'
import { listAllTeamMembers, listDepartments, type DepartmentNode, type TeamMember, type WorkbenchViewer } from '../lib/syngy'
import { memberDepartmentNames } from '../lib/syngy'
import { dt, fmtDate, fmtDateTime, memberLabel, queryAll, selectLabel, table, toEpochSeconds } from '../lib/tables'
import { autoScore } from './MatchingPage'
import type { ArcubaseRow } from '../arcubase/runtime'
import type { DevOperatorFullAccess2Fields } from '../arcubase/ingresses/devOperatorFullAccess2'
import type { DevOperatorFullAccess3Fields } from '../arcubase/ingresses/devOperatorFullAccess3'
import type { DevOperatorFullAccess4Fields } from '../arcubase/ingresses/devOperatorFullAccess4'
import type { DevOperatorFullAccess5Fields } from '../arcubase/ingresses/devOperatorFullAccess5'

export type PageCtx = { viewer: WorkbenchViewer; role: BusinessRole; roles: BusinessRole[]; roleNames?: string[] }

type DemandRow = ArcubaseRow<DevOperatorFullAccess2Fields>
type JobRow = ArcubaseRow<DevOperatorFullAccess3Fields>

type FormState = {
  jobId: string
  department: string
  headcount: string
  expectedMonth: string
  isKeyPosition: boolean
  departmentOwner: string
  remark: string
}

const emptyForm: FormState = { jobId: '', department: '', headcount: '1', expectedMonth: '', isKeyPosition: false, departmentOwner: '', remark: '' }

export function DemandsPage({ viewer, role, roles }: PageCtx) {
  const [rows, setRows] = useState<DemandRow[]>([])
  const [jobs, setJobs] = useState<JobRow[]>([])
  const [departments, setDepartments] = useState<DepartmentNode[]>([])
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [sheetOpen, setSheetOpen] = useState(false)
  const [detail, setDetail] = useState<DemandRow | null>(null)
  const [form, setForm] = useState<FormState>(emptyForm)
  const [saving, setSaving] = useState(false)
  const [statusFilter, setStatusFilter] = useState('')
  /** 编辑中的需求（驳回后修改重提）；null = 新建 */
  const [editing, setEditing] = useState<DemandRow | null>(null)
  /** 驳回确认抽屉 */
  const [rejectTarget, setRejectTarget] = useState<DemandRow | null>(null)
  const [rejectComment, setRejectComment] = useState('')
  const [rejecting, setRejecting] = useState(false)
  /** 匹配进行中（按需求行 id） */
  const [matchingId, setMatchingId] = useState<number | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const [demandRows, jobRows, deptNodes, members] = await Promise.all([
        queryAll(table('demands')),
        queryAll(table('jobs')).catch(() => [] as JobRow[]),
        listDepartments().catch(() => [] as DepartmentNode[]),
        listAllTeamMembers().catch(() => [] as TeamMember[]),
      ])
      setRows(demandRows)
      setJobs(jobRows.filter((j) => selectLabel(j.fields.status) === '启用'))
      setDepartments(deptNodes)
      setTeamMembers(members)
    } catch (err) {
      setError(err instanceof Error ? err.message : '加载失败')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { void load() }, [load])

  const filtered = useMemo(
    () => rows.filter((r) => !statusFilter || selectLabel(r.fields.status) === statusFilter),
    [rows, statusFilter],
  )

  /** 部门负责人候选：岗位所属部门（含其子部门）下的 active 成员 */
  const ownerOptions = useMemo(() => {
    if (!form.department) return [] as TeamMember[]
    const dept = departments.find((d) => d.name === form.department)
    if (!dept) return teamMembers.filter((m) => m.status === 'active')
    const deptIds = new Set(
      departments
        .filter((d) => d.id === dept.id || d.path.split('/').includes(dept.id))
        .map((d) => d.id),
    )
    return teamMembers.filter(
      (m) => m.status === 'active' && m.departmentIds.some((id) => deptIds.has(id)),
    )
  }, [form.department, departments, teamMembers])

  /** 纯部门领导（不同时是人事角色）：新建需求时岗位下拉仅本部门 */
  const isOnlyDeptLeader = roles.includes('部门领导') && !roles.includes('人事专员') && !roles.includes('人事经理')
  const canApprove = roles.includes('人事经理')

  /** 当前用户（部门领导）所在部门名列表 */
  const myDepartmentNames = useMemo(() => {
    if (!isOnlyDeptLeader) return [] as string[]
    const me = teamMembers.find((m) => m.userId === viewer.id)
    if (!me) return [] as string[]
    return memberDepartmentNames(me, departments)
  }, [isOnlyDeptLeader, teamMembers, viewer.id, departments])

  /** 岗位下拉：纯部门领导仅本部门岗位，其他角色全部启用岗位 */
  const visibleJobs = useMemo(() => {
    if (!isOnlyDeptLeader) return jobs
    if (myDepartmentNames.length === 0) return jobs
    const mySet = new Set(myDepartmentNames)
    return jobs.filter((j) => {
      const dept = j.fields.department ?? ''
      return dept && mySet.has(dept)
    })
  }, [isOnlyDeptLeader, jobs, myDepartmentNames])

  function onJobChange(jobId: string) {
    const job = jobs.find((j) => String(j.id) === jobId) ?? null
    setForm({
      ...form,
      jobId,
      department: job?.fields.department ?? '',
      departmentOwner: '',
    })
  }

  /** 打开编辑抽屉（驳回后修改重提）：回显字段并清空审批痕迹 */
  function openEdit(row: DemandRow) {
    const job = jobs.find((j) => j.fields.name === row.fields.jobTitle)
    setEditing(row)
    setForm({
      jobId: job ? String(job.id) : '',
      department: row.fields.department ?? '',
      headcount: String(row.fields.headcount ?? 1),
      expectedMonth: row.fields.expectedMonth ?? '',
      isKeyPosition: Boolean(row.fields.isKeyPosition),
      departmentOwner: row.fields.departmentOwner ? String(row.fields.departmentOwner) : '',
      remark: row.fields.remark ?? '',
    })
    setDetail(null)
    setSheetOpen(true)
  }

  function openNew() {
    setEditing(null)
    setForm(emptyForm)
    setSheetOpen(true)
  }

  async function submitNew() {
    if (!form.jobId || !form.headcount.trim()) return
    const job = jobs.find((j) => String(j.id) === form.jobId)
    if (!job) return
    setSaving(true)
    try {
      const base = {
        // member 字段存数字 arcubaseUserId；留空则不写（部门领导行级隔离锚点）
        ...(form.departmentOwner.trim() ? { departmentOwner: Number(form.departmentOwner.trim()) || form.departmentOwner.trim() } : {}),
        proposerRole: role === '部门领导' ? '部门领导' : '人事专员',
        department: form.department.trim() || undefined,
        jobTitle: job.fields.name,
        headcount: Number(form.headcount) || 1,
        expectedMonth: form.expectedMonth || undefined,
        isKeyPosition: form.isKeyPosition,
        status: '待审批' as const,
        remark: form.remark.trim() || undefined,
      }
      if (editing) {
        // 修改重提：清空审批痕迹，状态回到待审批
        await table('demands').update(editing.id, {
          ...base,
          proposer: viewer.id,
          approvalComment: '',
        })
      } else {
        await table('demands').create({ ...base, proposer: viewer.id })
      }
      setSheetOpen(false)
      setEditing(null)
      setForm(emptyForm)
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : '保存失败')
    } finally {
      setSaving(false)
    }
  }

  async function approve(row: DemandRow, pass: boolean) {
    try {
      await table('demands').update(row.id, {
        status: pass ? '通过' : '驳回',
        approver: viewer.id,
        approvedAt: dt(toEpochSeconds(new Date())),
      })
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : '操作失败')
    }
  }

  /** 按需求匹配人才库：对全部简历跑初筛，去重（已有该简历+该需求的流程则跳过），结果进匹配页 */
  async function runMatch(row: DemandRow) {
    setMatchingId(row.id)
    setError(null)
    try {
      const [resumes, pipelines] = await Promise.all([
        queryAll(table('resumes')),
        queryAll(table('pipelines')),
      ])
      const demandText = `${row.fields.jobTitle ?? ''} ${row.fields.department ?? ''} ${row.fields.remark ?? ''}`
      // 已存在该需求流程的简历，跳过
      const usedResumeIds = new Set(
        pipelines
          .filter((p) => String(p.fields.demandId) === String(row.id))
          .map((p) => String(p.fields.resumeId)),
      )
      const now = dt(toEpochSeconds(new Date()))
      let created = 0
      for (const resume of resumes) {
        if (usedResumeIds.has(String(resume.id))) continue
        const resumeText = `${resume.fields.name ?? ''} ${resume.fields.skills ?? ''} ${resume.fields.education ?? ''} ${resume.fields.school ?? ''}`
        const { score, hits } = autoScore(resumeText, demandText)
        const tier = score >= 60 ? '合适' : score >= 30 ? '待定' : '不合适'
        const pipelineId = await table('pipelines').create({
          resumeId: String(resume.id),
          demandId: String(row.id),
          currentStage: '匹配',
          stageTs: now,
          startedAt: now,
        })
        await table('matches').create({
          pipelineId: String(pipelineId),
          tier,
          score,
          details: hits.length ? `命中关键词：${hits.join('、')}` : '未命中岗位关键词',
          source: '手动',
          matchedAt: now,
        })
        created += 1
      }
      window.alert(`匹配完成：新增 ${created} 条匹配结果，请到「简历匹配」页查看。`)
    } catch (err) {
      setError(err instanceof Error ? err.message : '匹配失败')
    } finally {
      setMatchingId(null)
    }
  }

  /** 驳回：必须填审批意见 */
  async function confirmReject() {
    if (!rejectTarget || !rejectComment.trim()) return
    setRejecting(true)
    try {
      await table('demands').update(rejectTarget.id, {
        status: '驳回',
        approver: viewer.id,
        approvedAt: dt(toEpochSeconds(new Date())),
        approvalComment: rejectComment.trim(),
      })
      setRejectTarget(null)
      setRejectComment('')
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : '操作失败')
    } finally {
      setRejecting(false)
    }
  }

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between gap-3">
        <div>
          <CardTitle>用人需求单</CardTitle>
          <CardDescription>部门领导或人事专员提出，人事经理审批后生效。</CardDescription>
        </div>
        <div className="flex items-center gap-2">
          <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="w-32">
            <option value="">全部状态</option>
            {DEMAND_STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
          </Select>
          <Button type="button" onClick={openNew}>新建需求</Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {error ? <div className="px-4 py-3 text-sm text-red-600">{error}</div> : null}
        <Table>
          <THead>
            <TR>
              <TH>岗位</TH><TH>部门</TH><TH>人数</TH><TH>期望到岗月</TH><TH>关键岗位</TH>
              <TH>提出人</TH><TH>状态</TH><TH>审批人</TH><TH>审批时间</TH><TH>操作</TH>
            </TR>
          </THead>
          <TBody>
            {loading ? <EmptyRow colSpan={10} text="加载中…" /> : null}
            {!loading && filtered.length === 0 ? <EmptyRow colSpan={10} /> : null}
            {filtered.map((row) => {
              const f = row.fields
              const status = selectLabel(f.status)
              return (
                <TR key={row.id}>
                  <TD className="font-medium">{f.jobTitle}</TD>
                  <TD>{f.department || '—'}</TD>
                  <TD>{f.headcount}</TD>
                  <TD>{f.expectedMonth || '—'}</TD>
                  <TD>{f.isKeyPosition ? '是' : '否'}</TD>
                  <TD>{memberLabel(f.proposer)}（{selectLabel(f.proposerRole)}）</TD>
                  <TD><Badge tone={statusTone(status)}>{status}</Badge></TD>
                  <TD>{memberLabel(f.approver)}</TD>
                  <TD>{f.approvedAt && memberLabel(f.approver) !== '—' ? fmtDateTime(f.approvedAt) : '—'}</TD>
                  <TD>
                    <div className="flex gap-1">
                      <Button type="button" size="sm" variant="outline" onClick={() => setDetail(row)}>详情</Button>
                      <Button type="button" size="sm" variant="outline" disabled={matchingId === row.id} onClick={() => void runMatch(row)}>
                        {matchingId === row.id ? '匹配中…' : '匹配'}
                      </Button>
                      {status === '待审批' && canApprove ? (
                        <>
                          <Button type="button" size="sm" onClick={() => void approve(row, true)}>通过</Button>
                          <Button type="button" size="sm" variant="outline" onClick={() => { setRejectTarget(row); setRejectComment('') }}>驳回</Button>
                        </>
                      ) : null}
                      {status === '驳回' && roles.includes('部门领导') ? (
                        <Button type="button" size="sm" onClick={() => openEdit(row)}>修改重提</Button>
                      ) : null}
                    </div>
                  </TD>
                </TR>
              )
            })}
          </TBody>
        </Table>
      </CardContent>

      <Sheet
        open={sheetOpen}
        onOpenChange={setSheetOpen}
        title={editing ? '修改并重新提交' : '新建用人需求'}
        description={editing ? '修改后将重新进入待审批，由人事经理审批。' : '提交后进入待审批，由人事经理审批。'}
        footer={
          <>
            <Button type="button" variant="outline" onClick={() => setSheetOpen(false)}>取消</Button>
            <Button type="button" disabled={saving || !form.jobId} onClick={() => void submitNew()}>
              {saving ? '提交中…' : editing ? '重新提交' : '提交'}
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label>岗位 *（从岗位库选择）</Label>
            <Select value={form.jobId} onChange={(e) => onJobChange(e.target.value)}>
              <option value="">请选择岗位</option>
              {visibleJobs.map((j) => (
                <option key={j.id} value={String(j.id)}>
                  {j.fields.name}{j.fields.department ? `（${j.fields.department}）` : ''}
                </option>
              ))}
            </Select>
            {isOnlyDeptLeader && visibleJobs.length < jobs.length ? (
              <p className="text-xs text-slate-500">仅显示你所在部门（{myDepartmentNames.join('、') || '—'}）的岗位</p>
            ) : null}
          </div>
          <div className="space-y-1.5">
            <Label>部门（随岗位自动带出）</Label>
            <Input disabled value={form.department || '请选择岗位后自动带出'} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>招聘人数 *</Label>
              <Input type="number" min={1} value={form.headcount} onChange={(e) => setForm({ ...form, headcount: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>期望到岗月</Label>
              <Input type="month" value={form.expectedMonth} onChange={(e) => setForm({ ...form, expectedMonth: e.target.value })} />
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={form.isKeyPosition} onChange={(e) => setForm({ ...form, isKeyPosition: e.target.checked })} />
            关键岗位
          </label>
          <div className="space-y-1.5">
            <Label>提出人角色</Label>
            <Select disabled value={role === '部门领导' ? '部门领导' : '人事专员'}>
              {PROPOSER_ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>部门负责人（该部门下成员）</Label>
            <Select
              value={form.departmentOwner}
              onChange={(e) => setForm({ ...form, departmentOwner: e.target.value })}
              disabled={!form.department}
            >
              <option value="">
                {form.department ? '请选择部门负责人' : '请先选择岗位'}
              </option>
              {ownerOptions.map((m) => (
                <option key={m.arcubaseUserId} value={m.arcubaseUserId}>{m.displayName}</option>
              ))}
            </Select>
            {form.department && ownerOptions.length === 0 ? (
              <div className="text-xs text-amber-600">该部门下暂无成员，请到组织架构维护。</div>
            ) : null}
          </div>
          <div className="space-y-1.5">
            <Label>备注</Label>
            <Textarea value={form.remark} onChange={(e) => setForm({ ...form, remark: e.target.value })} />
          </div>
        </div>
      </Sheet>

      <Sheet
        open={detail !== null}
        onOpenChange={(open) => !open && setDetail(null)}
        title="需求详情"
        description={`单号 #${detail?.id ?? '—'}`}
        footer={
          detail && selectLabel(detail.fields.status) === '待审批' && canApprove ? (
            <>
              <Button type="button" variant="outline" onClick={() => setDetail(null)}>取消</Button>
              <Button type="button" variant="outline" onClick={() => { setRejectTarget(detail); setRejectComment('') }}>驳回</Button>
              <Button type="button" onClick={() => void approve(detail, true)}>通过</Button>
            </>
          ) : detail && selectLabel(detail.fields.status) === '驳回' && roles.includes('部门领导') ? (
            <>
              <Button type="button" variant="outline" onClick={() => setDetail(null)}>关闭</Button>
              <Button type="button" onClick={() => openEdit(detail)}>修改重提</Button>
            </>
          ) : (
            <Button type="button" variant="outline" onClick={() => setDetail(null)}>关闭</Button>
          )
        }
      >
        {detail ? (
          <div className="space-y-6">
            {/* 基础信息 */}
            <section>
              <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400">基础信息</h3>
              <dl className="grid grid-cols-2 gap-3 text-sm">
                <div className="col-span-2 rounded-md border border-slate-200 bg-slate-50 px-3 py-2">
                  <dt className="text-slate-500">岗位</dt>
                  <dd className="mt-0.5 font-medium">{detail.fields.jobTitle}</dd>
                </div>
                <div>
                  <dt className="text-slate-500">部门</dt>
                  <dd className="mt-0.5">{detail.fields.department || '—'}</dd>
                </div>
                <div>
                  <dt className="text-slate-500">招聘人数</dt>
                  <dd className="mt-0.5">{detail.fields.headcount}</dd>
                </div>
                <div>
                  <dt className="text-slate-500">期望到岗月</dt>
                  <dd className="mt-0.5">{detail.fields.expectedMonth || '—'}</dd>
                </div>
                <div>
                  <dt className="text-slate-500">关键岗位</dt>
                  <dd className="mt-0.5">{detail.fields.isKeyPosition ? '是' : '否'}</dd>
                </div>
              </dl>
            </section>

            {/* 状态与审批 */}
            <section>
              <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400">状态与审批</h3>
              <dl className="space-y-3 text-sm">
                <div>
                  <dt className="text-slate-500">当前状态</dt>
                  <dd className="mt-0.5"><Badge tone={statusTone(selectLabel(detail.fields.status))}>{selectLabel(detail.fields.status)}</Badge></dd>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <dt className="text-slate-500">提出人</dt>
                    <dd className="mt-0.5">{memberLabel(detail.fields.proposer)}</dd>
                  </div>
                  <div>
                    <dt className="text-slate-500">提出人角色</dt>
                    <dd className="mt-0.5">{selectLabel(detail.fields.proposerRole)}</dd>
                  </div>
                  <div>
                    <dt className="text-slate-500">审批人</dt>
                    <dd className="mt-0.5">{memberLabel(detail.fields.approver)}</dd>
                  </div>
                  <div>
                    <dt className="text-slate-500">审批时间</dt>
                    <dd className="mt-0.5">{detail.fields.approvedAt ? fmtDateTime(detail.fields.approvedAt) : '—'}</dd>
                  </div>
                </div>
                <div>
                  <dt className="text-slate-500">审批意见</dt>
                  <dd className="mt-0.5 rounded-md border border-slate-200 bg-slate-50 px-3 py-2 text-slate-700">
                    {detail.fields.approvalComment || '—'}
                  </dd>
                </div>
              </dl>
            </section>

            {/* 备注 */}
            <section>
              <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400">备注</h3>
              <div className="rounded-md border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700">
                {detail.fields.remark || '—'}
              </div>
            </section>
          </div>
        ) : null}
      </Sheet>

      {/* 驳回抽屉：必须填写审批意见 */}
      <Sheet
        open={rejectTarget !== null}
        onOpenChange={(open) => { if (!open) { setRejectTarget(null); setRejectComment('') } }}
        title="驳回需求"
        description={rejectTarget ? `驳回「${rejectTarget.fields.jobTitle}」的用人需求` : undefined}
        footer={
          <>
            <Button type="button" variant="outline" onClick={() => { setRejectTarget(null); setRejectComment('') }}>取消</Button>
            <Button type="button" disabled={rejecting || !rejectComment.trim()} onClick={() => void confirmReject()}>
              {rejecting ? '提交中…' : '确认驳回'}
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label>审批意见 *</Label>
            <Textarea
              value={rejectComment}
              onChange={(e) => setRejectComment(e.target.value)}
              placeholder="请填写驳回原因，便于提出人修改后重新提交"
              rows={5}
            />
            {rejectComment.trim() === '' ? (
              <p className="text-xs text-amber-600">驳回时必须填写审批意见。</p>
            ) : null}
          </div>
        </div>
      </Sheet>
    </Card>
  )
}
