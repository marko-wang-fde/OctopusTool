import { useCallback, useEffect, useState } from 'react'
import { Badge } from '../components/ui/badge'
import { Button } from '../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Input } from '../components/ui/input'
import { Label } from '../components/ui/label'
import { Select } from '../components/ui/select'
import { Sheet } from '../components/ui/sheet'
import { Table, TBody, TD, TH, THead, TR, EmptyRow } from '../components/ui/table'
import { Textarea } from '../components/ui/textarea'
import { JOB_STATUS } from '../lib/labels'
import { listDepartments, type DepartmentNode } from '../lib/syngy'
import { memberLabel, queryAll, selectLabel, table } from '../lib/tables'
import type { ArcubaseRow } from '../arcubase/runtime'
import type { DevOperatorFullAccess3Fields } from '../arcubase/ingresses/devOperatorFullAccess3'
import type { PageCtx } from './DemandsPage'

type JobRow = ArcubaseRow<DevOperatorFullAccess3Fields>

type FormState = {
  name: string
  department: string
  jd: string
  hardRequirements: string
  pendingRule: string
  status: string
}

const emptyForm: FormState = { name: '', department: '', jd: '', hardRequirements: '', pendingRule: '', status: '启用' }

/** 按 depth 生成层级前缀，让下拉能看出父子关系 */
function deptLabel(node: DepartmentNode): string {
  return `${'　'.repeat(Math.max(0, node.depth - 1))}${node.name}`
}

export function JobsPage({ viewer, roles }: PageCtx) {
  const readOnly = roles.includes('部门领导') && !roles.includes('人事专员') && !roles.includes('人事经理')
  const [rows, setRows] = useState<JobRow[]>([])
  const [departments, setDepartments] = useState<DepartmentNode[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [sheetOpen, setSheetOpen] = useState(false)
  const [editing, setEditing] = useState<JobRow | null>(null)
  const [form, setForm] = useState<FormState>(emptyForm)
  const [saving, setSaving] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const [jobRows, deptNodes] = await Promise.all([
        queryAll(table('jobs')),
        listDepartments().catch(() => [] as DepartmentNode[]),
      ])
      setRows(jobRows)
      // 跳过根节点（depth=0，公司主体），只留一级及以下部门
      setDepartments(deptNodes.filter((n) => n.depth >= 1))
    } catch (err) {
      setError(err instanceof Error ? err.message : '加载失败')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { void load() }, [load])

  function openCreate() {
    setEditing(null)
    setForm(emptyForm)
    setSheetOpen(true)
  }

  function openEdit(row: JobRow) {
    setEditing(row)
    setForm({
      name: row.fields.name ?? '',
      department: row.fields.department ?? '',
      jd: row.fields.jd ?? '',
      hardRequirements: row.fields.hardRequirements ?? '',
      pendingRule: row.fields.pendingRule ?? '',
      status: selectLabel(row.fields.status) === '—' ? '启用' : selectLabel(row.fields.status),
    })
    setSheetOpen(true)
  }

  async function submit() {
    if (!form.name.trim()) return
    setSaving(true)
    try {
      const fields = {
        name: form.name.trim(),
        department: form.department.trim() || undefined,
        jd: form.jd.trim() || undefined,
        hardRequirements: form.hardRequirements.trim() || undefined,
        pendingRule: form.pendingRule.trim() || undefined,
        status: form.status,
      }
      if (editing) {
        await table('jobs').update(editing.id, fields)
      } else {
        await table('jobs').create({ ...fields, owner: viewer.id })
      }
      setSheetOpen(false)
      setEditing(null)
      setForm(emptyForm)
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : '保存失败')
    } finally {
      setSaving(false)
    }
  }

  async function toggleStatus(row: JobRow) {
    const next = selectLabel(row.fields.status) === '启用' ? '停用' : '启用'
    try {
      await table('jobs').update(row.id, { status: next })
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : '操作失败')
    }
  }

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between gap-3">
        <div>
          <CardTitle>岗位管理</CardTitle>
          <CardDescription>维护招聘岗位的 JD、硬性要求与待定规则，供匹配与流程使用。</CardDescription>
        </div>
        {!readOnly ? <Button type="button" onClick={openCreate}>新建岗位</Button> : null}
      </CardHeader>
      <CardContent className="p-0">
        {error ? <div className="px-4 py-3 text-sm text-red-600">{error}</div> : null}
        {readOnly ? (
          <div className="px-4 py-2 text-xs text-slate-500 bg-slate-50 border-b">只读视图 · 你可查看岗位信息，编辑请联系人事专员。</div>
        ) : null}
        <Table>
          <THead>
            <TR>
              <TH>名称</TH><TH>部门</TH><TH>负责人</TH><TH>状态</TH>{!readOnly ? <TH>操作</TH> : null}
            </TR>
          </THead>
          <TBody>
            {loading ? <EmptyRow colSpan={readOnly ? 4 : 5} text="加载中…" /> : null}
            {!loading && rows.length === 0 ? <EmptyRow colSpan={readOnly ? 4 : 5} /> : null}
            {rows.map((row) => {
              const status = selectLabel(row.fields.status)
              return (
                <TR key={row.id}>
                  <TD className="font-medium">{row.fields.name}</TD>
                  <TD>{row.fields.department || '—'}</TD>
                  <TD>{memberLabel(row.fields.owner)}</TD>
                  <TD><Badge tone={status === '启用' ? 'green' : 'slate'}>{status}</Badge></TD>
                  {!readOnly ? (
                    <TD>
                      <div className="flex gap-1">
                        <Button type="button" variant="outline" onClick={() => openEdit(row)}>编辑</Button>
                        <Button type="button" variant="outline" onClick={() => void toggleStatus(row)}>
                          {status === '启用' ? '停用' : '启用'}
                        </Button>
                      </div>
                    </TD>
                  ) : null}
                </TR>
              )
            })}
          </TBody>
        </Table>
      </CardContent>

      <Sheet
        open={sheetOpen}
        onOpenChange={setSheetOpen}
        title={editing ? '编辑岗位' : '新建岗位'}
        description={editing ? `修改「${editing.fields.name}」的信息。` : '创建后默认为启用状态，可在流程中引用。'}
        footer={
          <>
            <Button type="button" variant="outline" onClick={() => setSheetOpen(false)}>取消</Button>
            <Button type="button" disabled={saving || !form.name.trim()} onClick={() => void submit()}>
              {saving ? '保存中…' : '保存'}
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label>岗位名称 *</Label>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="如：高级前端工程师" />
          </div>
          <div className="space-y-1.5">
            <Label>部门</Label>
            <Select
              value={form.department}
              onChange={(e) => setForm({ ...form, department: e.target.value })}
            >
              <option value="">（未指定）</option>
              {departments.map((d) => (
                <option key={d.id} value={d.name}>{deptLabel(d)}</option>
              ))}
              {form.department && !departments.some((d) => d.name === form.department) ? (
                <option value={form.department}>{form.department}（历史值）</option>
              ) : null}
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>岗位描述（JD）</Label>
            <Textarea value={form.jd} onChange={(e) => setForm({ ...form, jd: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label>硬性要求</Label>
            <Textarea value={form.hardRequirements} onChange={(e) => setForm({ ...form, hardRequirements: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label>待定规则</Label>
            <Textarea value={form.pendingRule} onChange={(e) => setForm({ ...form, pendingRule: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label>状态</Label>
            <Select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
              {JOB_STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
            </Select>
          </div>
        </div>
      </Sheet>
    </Card>
  )
}
