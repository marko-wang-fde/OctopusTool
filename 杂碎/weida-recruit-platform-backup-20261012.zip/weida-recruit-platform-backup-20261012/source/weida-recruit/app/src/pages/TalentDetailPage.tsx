import { useCallback, useEffect, useMemo, useState } from 'react'
import { Badge } from '../components/ui/badge'
import { Button } from '../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { fileValueName } from '../lib/files'
import { statusTone } from '../lib/labels'
import { fmtDate, fmtDateTime, queryAll, selectLabel, table } from '../lib/tables'
import { navigate } from '../App'
import type { ArcubaseRow } from '../arcubase/runtime'
import type { DevOperatorFullAccess2Fields } from '../arcubase/ingresses/devOperatorFullAccess2'
import type { DevOperatorFullAccess4Fields } from '../arcubase/ingresses/devOperatorFullAccess4'
import type { DevOperatorFullAccess5Fields } from '../arcubase/ingresses/devOperatorFullAccess5'
import type { PageCtx } from './DemandsPage'

type ResumeRow = ArcubaseRow<DevOperatorFullAccess4Fields>
type PipelineRow = ArcubaseRow<DevOperatorFullAccess5Fields>
type DemandRow = ArcubaseRow<DevOperatorFullAccess2Fields>

export function TalentDetailPage(_ctx: PageCtx & { id: string }) {
  const { id } = _ctx
  const [resume, setResume] = useState<ResumeRow | null>(null)
  const [pipelines, setPipelines] = useState<PipelineRow[]>([])
  const [demands, setDemands] = useState<DemandRow[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const [resumeRow, pipelineRows, demandRows] = await Promise.all([
        table('resumes').get(id),
        queryAll(table('pipelines')),
        queryAll(table('demands')),
      ])
      setResume(resumeRow)
      setPipelines(pipelineRows.filter((p) => p.fields.resumeId === id))
      setDemands(demandRows)
    } catch (err) {
      setError(err instanceof Error ? err.message : '加载失败')
    } finally {
      setLoading(false)
    }
  }, [id])

  useEffect(() => { void load() }, [load])

  const demandMap = useMemo(() => {
    const map = new Map<string, string>()
    for (const d of demands) {
      map.set(String(d.id), d.fields.jobTitle)
    }
    return map
  }, [demands])

  if (loading) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-sm text-slate-500">加载中…</CardContent>
      </Card>
    )
  }

  if (error || !resume) {
    return (
      <Card>
        <CardContent className="space-y-4 py-12 text-center">
          <div className="text-sm text-red-600">{error ?? '未找到该简历'}</div>
          <Button type="button" variant="outline" onClick={() => navigate('/talents')}>
            返回人才库
          </Button>
        </CardContent>
      </Card>
    )
  }

  const f = resume.fields
  const library = selectLabel(f.library)
  const pipelineStatus = selectLabel(f.pipelineStatus)

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Button type="button" variant="outline" size="sm" onClick={() => navigate('/talents')}>
              返回
            </Button>
            <div>
              <CardTitle>{f.name}</CardTitle>
              <CardDescription>简历详情</CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge tone="default">{library}</Badge>
            <Badge tone={statusTone(pipelineStatus)}>{pipelineStatus}</Badge>
          </div>
        </CardHeader>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>基本信息</CardTitle>
        </CardHeader>
        <CardContent>
          <dl className="grid grid-cols-1 gap-4 text-sm md:grid-cols-2">
            <div><dt className="text-slate-500">姓名</dt><dd className="font-medium">{f.name}</dd></div>
            <div><dt className="text-slate-500">性别</dt><dd>{selectLabel(f.gender)}</dd></div>
            <div><dt className="text-slate-500">年龄</dt><dd>{f.age !== undefined ? `${f.age}岁` : '—'}</dd></div>
            <div><dt className="text-slate-500">民族</dt><dd>{f.ethnicity || '—'}</dd></div>
            <div><dt className="text-slate-500">现居地</dt><dd>{f.currentCity || '—'}</dd></div>
            <div><dt className="text-slate-500">工作经验</dt><dd>{f.workYears !== undefined ? `${f.workYears}年` : '—'}</dd></div>
            <div><dt className="text-slate-500">到岗时间</dt><dd>{fmtDate(f.availableDate)}</dd></div>
            <div><dt className="text-slate-500">电话</dt><dd className="font-medium">{f.phone}</dd></div>
            <div><dt className="text-slate-500">邮箱</dt><dd>{f.email || '—'}</dd></div>
            <div><dt className="text-slate-500">应聘职位</dt><dd>{f.expectedPosition || '—'}</dd></div>
            <div><dt className="text-slate-500">期望薪资</dt><dd>{f.expectedSalary || '—'}</dd></div>
            <div><dt className="text-slate-500">期望城市</dt><dd>{f.expectedCity || '—'}</dd></div>
            <div><dt className="text-slate-500">渠道</dt><dd>{selectLabel(f.channel)}</dd></div>
            <div><dt className="text-slate-500">来源</dt><dd>{selectLabel(f.source)}</dd></div>
            <div><dt className="text-slate-500">解析状态</dt><dd>{selectLabel(f.parseStatus)}</dd></div>
            <div><dt className="text-slate-500">原始附件</dt><dd>{fileValueName(f.originFile) || '—'}</dd></div>
          </dl>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>教育背景</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="whitespace-pre-wrap text-sm leading-[150%] text-slate-700">{f.educationDetail || f.school || '—'}</div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>工作经历</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="whitespace-pre-wrap text-sm leading-[150%] text-slate-700">{f.workExperience || '—'}</div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>技能</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-sm leading-[150%] text-slate-700">{f.skills || '—'}</div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>历史流程</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {pipelines.length === 0 ? (
            <div className="px-4 py-8 text-center text-sm text-slate-500">暂无流程记录</div>
          ) : (
            <div className="divide-y divide-slate-100">
              {pipelines.map((p) => {
                const jobTitle = demandMap.get(String(p.fields.demandId)) ?? p.fields.demandId
                const stage = selectLabel(p.fields.currentStage)
                return (
                  <div key={p.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 text-sm">
                    <div className="font-medium">{jobTitle}</div>
                    <div className="flex items-center gap-3">
                      <Badge tone={statusTone(stage)}>{stage}</Badge>
                      <span className="text-slate-500">启动：{fmtDateTime(p.fields.startedAt)}</span>
                      <span className="text-slate-500">更新：{fmtDateTime(p.fields.stageTs)}</span>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
