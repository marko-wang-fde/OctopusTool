import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { navigate } from '../App'
import type { PageCtx } from './DemandsPage'

export function SettingsPage(_ctx: PageCtx) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>设置</CardTitle>
        <CardDescription>管理岗位信息与系统配置项。</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 sm:grid-cols-2">
          <button
            type="button"
            className="rounded-lg border border-slate-200 bg-white p-5 text-left shadow-sm transition-colors hover:bg-slate-50"
            onClick={() => navigate('/settings/jobs')}
          >
            <div className="text-base font-semibold">岗位管理</div>
            <div className="mt-1 text-sm text-slate-500">维护招聘岗位的 JD、硬性要求与待定规则。</div>
          </button>
          <button
            type="button"
            className="rounded-lg border border-slate-200 bg-white p-5 text-left shadow-sm transition-colors hover:bg-slate-50"
            onClick={() => navigate('/settings/config')}
          >
            <div className="text-base font-semibold">系统配置</div>
            <div className="mt-1 text-sm text-slate-500">配置流程巡检阈值、邮件模板等系统参数。</div>
          </button>
        </div>
      </CardContent>
    </Card>
  )
}
