import { useCallback, useEffect, useMemo, useState } from 'react'
import { Badge } from '../components/ui/badge'
import { Button } from '../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Dialog } from '../components/ui/dialog'
import { Input } from '../components/ui/input'
import { Label } from '../components/ui/label'
import { Select } from '../components/ui/select'
import { Table, TBody, TD, TH, THead, TR, EmptyRow } from '../components/ui/table'
import { Textarea } from '../components/ui/textarea'
import { MATERIAL_TYPES, statusTone } from '../lib/labels'
import { canSeeSalaryAmount } from '../lib/roles'
import { fileValueName, getKbFileDownloadUrl, uploadKbFile } from '../lib/files'
import { dt, fmtDateTime, memberLabel, queryAll, selectLabel, table, toEpochSeconds } from '../lib/tables'
import type { PageCtx } from './DemandsPage'
import type { ArcubaseRow } from '../arcubase/runtime'
import type { DevOperatorFullAccess2Fields } from '../arcubase/ingresses/devOperatorFullAccess2'
import type { DevOperatorFullAccess4Fields } from '../arcubase/ingresses/devOperatorFullAccess4'
import type { DevOperatorFullAccess5Fields } from '../arcubase/ingresses/devOperatorFullAccess5'
import type { DevOperatorFullAccess11Fields } from '../arcubase/ingresses/devOperatorFullAccess11'
import type { DevOperatorFullAccess12Fields } from '../arcubase/ingresses/devOperatorFullAccess12'
import type { DevOperatorFullAccess16Fields } from '../arcubase/ingresses/devOperatorFullAccess16'

type PipelineRow = ArcubaseRow<DevOperatorFullAccess5Fields>
type ResumeRow = ArcubaseRow<DevOperatorFullAccess4Fields>
type DemandRow = ArcubaseRow<DevOperatorFullAccess2Fields>
type MaterialRow = ArcubaseRow<DevOperatorFullAccess11Fields>
type SalaryRow = ArcubaseRow<DevOperatorFullAccess12Fields>
type KbMaterialRow = ArcubaseRow<DevOperatorFullAccess16Fields>

type ApproveAction = '通过' | '修改后通过' | '驳回'

export function ScreeningPage({ viewer, roles }: PageCtx) {
  const [pipelines, setPipelines] = useState<PipelineRow[]>([])
  const [resumes, setResumes] = useState<ResumeRow[]>([])
  const [demands, setDemands] = useState<DemandRow[]>([])
  const [materials, setMaterials] = useState<MaterialRow[]>([])
  const [kbMaterials, setKbMaterials] = useState<KbMaterialRow[]>([])
  const [salaries, setSalaries] = useState<SalaryRow[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const [uploadTarget, setUploadTarget] = useState<PipelineRow | null>(null)
  const [mtype, setMtype] = useState<string>(MATERIAL_TYPES[0])
  const [file, setFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)

  const [salaryTarget, setSalaryTarget] = useState<PipelineRow | null>(null)
  const [amountText, setAmountText] = useState('')
  const [salaryNote, setSalaryNote] = useState('')
  const [savingSalary, setSavingSalary] = useState(false)

  const [approveTarget, setApproveTarget] = useState<{ row: SalaryRow; action: ApproveAction } | null>(null)
  const [finalAmountText, setFinalAmountText] = useState('')
  const [approvalComment, setApprovalComment] = useState('')
  const [approving, setApproving] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const [p, r, d, m, s, k] = await Promise.all([
        queryAll(table('pipelines')),
        queryAll(table('resumes')),
        queryAll(table('demands')),
        queryAll(table('bgMaterials')),
        queryAll(table('salaries')),
        queryAll(table('resumeMaterials')),
      ])
      setPipelines(p as PipelineRow[])
      setResumes(r as ResumeRow[])
      setDemands(d as DemandRow[])
      setMaterials(m as MaterialRow[])
      setSalaries(s as SalaryRow[])
      setKbMaterials(k as KbMaterialRow[])
    } catch (err) {
      setError(err instanceof Error ? err.message : '加载失败')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { void load() }, [load])

  const resumeById = useMemo(() => new Map(resumes.map((r) => [String(r.id), r])), [resumes])
  const demandById = useMemo(() => new Map(demands.map((d) => [String(d.id), d])), [demands])

  const materialsByPipeline = useMemo(() => {
    const map = new Map<string, MaterialRow[]>()
    for (const m of materials) {
      const key = String(m.fields.pipelineId ?? '')
      const list = map.get(key) ?? []
      list.push(m)
      map.set(key, list)
    }
    return map
  }, [materials])

  const screeningPipelines = useMemo(
    () => pipelines.filter((p) => selectLabel(p.fields.currentStage) === '背调'),
    [pipelines],
  )

  function candidateName(p: PipelineRow): string {
    return resumeById.get(String(p.fields.resumeId))?.fields.name ?? String(p.fields.resumeId)
  }
  function jobTitleOf(p: PipelineRow): string {
    return demandById.get(String(p.fields.demandId))?.fields.jobTitle ?? String(p.fields.demandId)
  }

  /** 材料行对应的知识库文件（T16 以 batchId=bg-material-{T11行id} 关联） */
  function kbFileOf(m: MaterialRow): KbMaterialRow | undefined {
    return kbMaterials.find((k) => k.fields.batchId === `bg-material-${m.id}`)
  }

  async function downloadKbFile(k: KbMaterialRow) {
    try {
      const url = await getKbFileDownloadUrl(k.fields.logicalPath)
      window.open(url, '_blank')
    } catch {
      setError('获取附件下载地址失败')
    }
  }

  async function submitUpload() {
    if (!uploadTarget || !file) return
    setUploading(true)
    setError(null)
    try {
      // 附件存知识库；KB 指针写 T16（T11 的 attachment 是 file 类型字段，只认平台 OSS upload 产物，无法存 KB 指针）
      const kb = await uploadKbFile(file, 'bg-materials')
      const bgId = await table('bgMaterials').create({
        pipelineId: String(uploadTarget.id),
        mtype,
        attachment: [] as any,
        uploadedBy: viewer.id,
        uploadedAt: dt(toEpochSeconds(new Date())),
      })
      await table('resumeMaterials').create({
        fileName: kb.fileName,
        logicalPath: kb.logicalPath,
        sizeBytes: kb.sizeBytes,
        contentType: kb.contentType || 'application/octet-stream',
        batchId: `bg-material-${bgId}`,
        status: '背调材料',
        uploadedBy: viewer.id as any,
        uploadedAt: dt(toEpochSeconds(new Date())),
      })
      setUploadTarget(null)
      setFile(null)
      setMtype(MATERIAL_TYPES[0])
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : '上传失败')
    } finally {
      setUploading(false)
    }
  }

  async function submitSalary() {
    if (!salaryTarget) return
    const amount = Number(amountText)
    if (!Number.isFinite(amount) || amount <= 0) return
    setSavingSalary(true)
    setError(null)
    try {
      const now = dt(toEpochSeconds(new Date()))
      await table('salaries').create({
        pipelineId: String(salaryTarget.id),
        amount,
        note: salaryNote.trim() || undefined,
        status: '待审批',
      })
      await table('pipelines').update(salaryTarget.id, { currentStage: '拟薪', stageTs: now })
      await table('resumes').update(salaryTarget.fields.resumeId, { pipelineStatus: '拟薪' })
      setSalaryTarget(null)
      setAmountText('')
      setSalaryNote('')
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : '提交拟薪失败')
    } finally {
      setSavingSalary(false)
    }
  }

  async function submitApprove() {
    if (!approveTarget) return
    const { row, action } = approveTarget
    if (action === '修改后通过') {
      const finalAmount = Number(finalAmountText)
      if (!Number.isFinite(finalAmount) || finalAmount <= 0) return
    }
    setApproving(true)
    setError(null)
    try {
      await table('salaries').update(row.id, {
        status: action,
        ...(action === '修改后通过' ? { finalAmount: Number(finalAmountText) } : {}),
        approver: viewer.id,
        approvedAt: dt(toEpochSeconds(new Date())),
        ...(action === '驳回' ? { approvalComment: approvalComment.trim() || undefined } : {}),
      })
      // 拟薪审批通过（含修改后通过）：流程自动进入 offer 环节；驳回不动流程，可重新提交拟薪
      if (action !== '驳回') {
        const now = dt(toEpochSeconds(new Date()))
        await table('pipelines').update(row.fields.pipelineId, { currentStage: 'offer', stageTs: now })
        const pipeline = pipelines.find((p) => String(p.id) === String(row.fields.pipelineId))
        if (pipeline) {
          await table('resumes').update(pipeline.fields.resumeId, { pipelineStatus: 'offer' })
        }
      }
      setApproveTarget(null)
      setFinalAmountText('')
      setApprovalComment('')
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : '审批失败')
    } finally {
      setApproving(false)
    }
  }

  const showAmount = canSeeSalaryAmount(roles)

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>背调材料</CardTitle>
          <CardDescription>背调阶段候选人需先上传背调材料，之后才能提交拟薪（流程不可跳步）。</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {error ? <div className="px-4 py-3 text-sm text-red-600">{error}</div> : null}
          <Table>
            <THead>
              <TR>
                <TH>候选人</TH><TH>岗位</TH><TH>已传材料</TH><TH>操作</TH>
              </TR>
            </THead>
            <TBody>
              {loading ? <EmptyRow colSpan={4} text="加载中…" /> : null}
              {!loading && screeningPipelines.length === 0 ? <EmptyRow colSpan={4} /> : null}
              {screeningPipelines.map((p) => {
                const list = materialsByPipeline.get(String(p.id)) ?? []
                const canSubmitSalary = list.length > 0
                return (
                  <TR key={p.id}>
                    <TD className="font-medium">{candidateName(p)}</TD>
                    <TD>{jobTitleOf(p)}</TD>
                    <TD>
                      {list.length === 0 ? (
                        <span className="text-slate-400">暂无材料</span>
                      ) : (
                        <ul className="space-y-1">
                          {list.map((m) => {
                            const kbFile = kbFileOf(m)
                            return (
                              <li key={m.id} className="text-xs text-slate-600">
                                <Badge tone="slate">{selectLabel(m.fields.mtype)}</Badge>{' '}
                                {kbFile ? (
                                  <button
                                    type="button"
                                    className="text-blue-600 hover:underline"
                                    onClick={() => void downloadKbFile(kbFile)}
                                  >
                                    {kbFile.fields.fileName}
                                  </button>
                                ) : (
                                  <span>{fileValueName(m.fields.attachment) || '附件'}</span>
                                )}{' '}
                                · {fmtDateTime(m.fields.uploadedAt)}
                              </li>
                            )
                          })}
                        </ul>
                      )}
                    </TD>
                    <TD>
                      <div className="flex gap-2">
                        <Button
                          type="button"
                          className="h-8 px-3 text-xs"
                          onClick={() => { setUploadTarget(p); setFile(null); setMtype(MATERIAL_TYPES[0]) }}
                        >
                          上传背调材料
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          className="h-8 px-3 text-xs"
                          disabled={!canSubmitSalary}
                          title={canSubmitSalary ? undefined : '需先上传至少 1 条背调材料后才能提交拟薪（流程不可跳步）'}
                          onClick={() => { setSalaryTarget(p); setAmountText(''); setSalaryNote('') }}
                        >
                          提交拟薪
                        </Button>
                      </div>
                    </TD>
                  </TR>
                )
              })}
            </TBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>拟薪审批</CardTitle>
          <CardDescription>拟薪金额仅人事经理可见；待审批记录由人事经理执行通过 / 修改后通过 / 驳回。</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <THead>
              <TR>
                <TH>候选人</TH><TH>岗位</TH><TH>拟薪金额</TH><TH>最终金额</TH><TH>状态</TH>
                <TH>审批人</TH><TH>审批时间</TH><TH>备注</TH><TH>操作</TH>
              </TR>
            </THead>
            <TBody>
              {loading ? <EmptyRow colSpan={9} text="加载中…" /> : null}
              {!loading && salaries.length === 0 ? <EmptyRow colSpan={9} /> : null}
              {salaries.map((s) => {
                const p = pipelines.find((pp) => String(pp.id) === String(s.fields.pipelineId))
                const status = selectLabel(s.fields.status)
                return (
                  <TR key={s.id}>
                    <TD className="font-medium">{p ? candidateName(p) : String(s.fields.pipelineId)}</TD>
                    <TD>{p ? jobTitleOf(p) : '—'}</TD>
                    <TD>{showAmount ? (s.fields.amount ?? '—') : '***'}</TD>
                    <TD>{showAmount ? (s.fields.finalAmount ?? '—') : '***'}</TD>
                    <TD><Badge tone={statusTone(status)}>{status}</Badge></TD>
                    <TD>{memberLabel(s.fields.approver)}</TD>
                    <TD>{s.fields.approvedAt ? fmtDateTime(s.fields.approvedAt) : '—'}</TD>
                    <TD>{s.fields.note || '—'}</TD>
                    <TD>
                      {status === '待审批' && roles.includes('人事经理') ? (
                        <div className="flex gap-1">
                          <Button
                            type="button"
                            className="h-8 px-2 text-xs"
                            onClick={() => { setApproveTarget({ row: s, action: '通过' }); setFinalAmountText(''); setApprovalComment('') }}
                          >
                            通过
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            className="h-8 px-2 text-xs"
                            onClick={() => { setApproveTarget({ row: s, action: '修改后通过' }); setFinalAmountText(String(s.fields.amount ?? '')); setApprovalComment('') }}
                          >
                            修改后通过
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            className="h-8 px-2 text-xs"
                            onClick={() => { setApproveTarget({ row: s, action: '驳回' }); setFinalAmountText(''); setApprovalComment('') }}
                          >
                            驳回
                          </Button>
                        </div>
                      ) : (
                        <span className="text-slate-400">—</span>
                      )}
                    </TD>
                  </TR>
                )
              })}
            </TBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog
        open={uploadTarget !== null}
        onOpenChange={(open) => !open && setUploadTarget(null)}
        title="上传背调材料"
        description={uploadTarget ? `候选人：${candidateName(uploadTarget)}` : undefined}
        footer={
          <>
            <Button type="button" variant="outline" onClick={() => setUploadTarget(null)}>取消</Button>
            <Button type="button" disabled={uploading || !file} onClick={() => void submitUpload()}>
              {uploading ? '上传中…' : '上传'}
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label>材料类型 *</Label>
            <Select value={mtype} onChange={(e) => setMtype(e.target.value)}>
              {MATERIAL_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>附件 *</Label>
            <Input type="file" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
            {file ? <div className="text-xs text-slate-500">已选择：{file.name}</div> : null}
          </div>
        </div>
      </Dialog>

      <Dialog
        open={salaryTarget !== null}
        onOpenChange={(open) => !open && setSalaryTarget(null)}
        title="提交拟薪"
        description={salaryTarget ? `候选人：${candidateName(salaryTarget)}` : undefined}
        footer={
          <>
            <Button type="button" variant="outline" onClick={() => setSalaryTarget(null)}>取消</Button>
            <Button
              type="button"
              disabled={savingSalary || !Number(amountText)}
              onClick={() => void submitSalary()}
            >
              {savingSalary ? '提交中…' : '提交'}
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label>拟薪金额（元/月）*</Label>
            <Input type="number" min={0} value={amountText} onChange={(e) => setAmountText(e.target.value)} placeholder="如：15000" />
          </div>
          <div className="space-y-1.5">
            <Label>备注</Label>
            <Textarea value={salaryNote} onChange={(e) => setSalaryNote(e.target.value)} />
          </div>
        </div>
      </Dialog>

      <Dialog
        open={approveTarget !== null}
        onOpenChange={(open) => !open && setApproveTarget(null)}
        title={approveTarget ? `拟薪审批：${approveTarget.action}` : ''}
        footer={
          <>
            <Button type="button" variant="outline" onClick={() => setApproveTarget(null)}>取消</Button>
            <Button
              type="button"
              disabled={approving || (approveTarget?.action === '修改后通过' && !Number(finalAmountText))}
              onClick={() => void submitApprove()}
            >
              {approving ? '提交中…' : '确认'}
            </Button>
          </>
        }
      >
        {approveTarget?.action === '修改后通过' ? (
          <div className="space-y-1.5">
            <Label>最终金额（元/月）*</Label>
            <Input type="number" min={0} value={finalAmountText} onChange={(e) => setFinalAmountText(e.target.value)} />
          </div>
        ) : null}
        {approveTarget?.action === '驳回' ? (
          <div className="space-y-1.5">
            <Label>驳回意见</Label>
            <Textarea value={approvalComment} onChange={(e) => setApprovalComment(e.target.value)} />
          </div>
        ) : null}
        {approveTarget?.action === '通过' ? (
          <p className="text-sm text-slate-600">确认按拟薪金额审批通过？</p>
        ) : null}
      </Dialog>
    </div>
  )
}
