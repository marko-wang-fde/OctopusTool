import { useCallback, useEffect, useState } from 'react'
import { Button } from '../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Input } from '../components/ui/input'
import { Label } from '../components/ui/label'
import { Sheet } from '../components/ui/sheet'
import { Table, TBody, TD, TH, THead, TR, EmptyRow } from '../components/ui/table'
import { Textarea } from '../components/ui/textarea'
import { queryAll, table } from '../lib/tables'
import type { ArcubaseRow } from '../arcubase/runtime'
import type { DevOperatorFullAccessFields } from '../arcubase/ingresses/devOperatorFullAccess'
import type { PageCtx } from './DemandsPage'

type ConfigRow = ArcubaseRow<DevOperatorFullAccessFields>

type FormState = {
  ckey: string
  cvalue: string
  description: string
}

const emptyForm: FormState = { ckey: '', cvalue: '', description: '' }

/** 内置 key 的友好名称 */
const FRIENDLY_KEYS: Record<string, string> = {
  timeout_workdays: '流程巡检阈值（工作日）',
  mail_template_enabled: '邮件模板启停',
  channel_options: '简历渠道枚举',
  filter_dimensions: 'Q5 筛选维度',
  email_template_interview: '面试邀约邮件模板',
  email_template_offer: 'offer 邮件模板',
  email_template_bgcheck: '背调请求邮件模板',
  email_template_reschedule: '面试改期通知邮件模板',
}

function keyLabel(key: string): string {
  return FRIENDLY_KEYS[key] ?? key
}

export function ConfigPage(_ctx: PageCtx) {
  const [rows, setRows] = useState<ConfigRow[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [sheetOpen, setSheetOpen] = useState(false)
  const [editing, setEditing] = useState<ConfigRow | null>(null)
  const [form, setForm] = useState<FormState>(emptyForm)
  const [saving, setSaving] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      setRows(await queryAll(table('configs')))
    } catch (err) {
      setError(err instanceof Error ? err.message : '加载失败')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { void load() }, [load])

  function openCreate() {
    setEditing(null)
    setForm(emptyForm)
    setSheetOpen(true)
  }

  function openEdit(row: ConfigRow) {
    setEditing(row)
    setForm({
      ckey: row.fields.ckey ?? '',
      cvalue: row.fields.cvalue ?? '',
      description: row.fields.description ?? '',
    })
    setSheetOpen(true)
  }

  async function submit() {
    if (!form.ckey.trim()) return
    setSaving(true)
    try {
      const fields = {
        ckey: form.ckey.trim(),
        cvalue: form.cvalue.trim() || undefined,
        description: form.description.trim() || undefined,
      }
      if (editing) {
        await table('configs').update(editing.id, fields)
      } else {
        await table('configs').create(fields)
      }
      setSheetOpen(false)
      setEditing(null)
      setForm(emptyForm)
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : '保存失败')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between gap-3">
        <div>
          <CardTitle>系统配置</CardTitle>
          <CardDescription>维护流程巡检阈值、邮件模板等系统级配置项。</CardDescription>
        </div>
        <Button type="button" onClick={openCreate}>新建配置</Button>
      </CardHeader>
      <CardContent className="p-0">
        {error ? <div className="px-4 py-3 text-sm text-red-600">{error}</div> : null}
        <Table>
          <THead>
            <TR>
              <TH>配置项</TH><TH>配置值</TH><TH>说明</TH><TH>操作</TH>
            </TR>
          </THead>
          <TBody>
            {loading ? <EmptyRow colSpan={4} text="加载中…" /> : null}
            {!loading && rows.length === 0 ? <EmptyRow colSpan={4} /> : null}
            {rows.map((row) => (
              <TR key={row.id}>
                <TD className="font-medium">{keyLabel(row.fields.ckey)}</TD>
                <TD>{row.fields.cvalue || '—'}</TD>
                <TD>{row.fields.description || '—'}</TD>
                <TD>
                  <Button type="button" variant="outline" onClick={() => openEdit(row)}>编辑</Button>
                </TD>
              </TR>
            ))}
          </TBody>
        </Table>
      </CardContent>

      <Sheet
        open={sheetOpen}
        onOpenChange={setSheetOpen}
        title={editing ? `编辑配置：${keyLabel(editing.fields.ckey)}` : '新建配置'}
        description="配置项按 key 唯一标识，保存后立即生效。"
        footer={
          <>
            <Button type="button" variant="outline" onClick={() => setSheetOpen(false)}>取消</Button>
            <Button type="button" disabled={saving || !form.ckey.trim()} onClick={() => void submit()}>
              {saving ? '保存中…' : '保存'}
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label>配置 Key *</Label>
            <Input
              value={form.ckey}
              onChange={(e) => setForm({ ...form, ckey: e.target.value })}
              placeholder="如：timeout_workdays"
              disabled={editing !== null}
            />
            {FRIENDLY_KEYS[form.ckey.trim()] ? (
              <div className="text-xs text-slate-500">{keyLabel(form.ckey.trim())}</div>
            ) : null}
          </div>
          <div className="space-y-1.5">
            <Label>配置值</Label>
            <Textarea
              value={form.cvalue}
              onChange={(e) => setForm({ ...form, cvalue: e.target.value })}
              rows={6}
            />
            {form.ckey.trim() === 'filter_dimensions' || form.ckey.trim() === 'channel_options' || form.ckey.trim().startsWith('email_template_') ? (
              <div className="text-xs text-slate-500">JSON 格式；保存前请自行校验。</div>
            ) : null}
          </div>
          <div className="space-y-1.5">
            <Label>说明</Label>
            <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </div>
        </div>
      </Sheet>
    </Card>
  )
}
