import { Fragment, useCallback, useEffect, useMemo, useState } from 'react'
import { Badge } from '../components/ui/badge'
import { Button } from '../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Input } from '../components/ui/input'
import { Label } from '../components/ui/label'
import { Select } from '../components/ui/select'
import { Sheet } from '../components/ui/sheet'
import { Table, TBody, TD, TH, THead, TR, EmptyRow } from '../components/ui/table'
import { Textarea } from '../components/ui/textarea'
import { INTERVIEW_MODES, INTERVIEW_RESULTS, statusTone } from '../lib/labels'
import { getKbFileDownloadUrl, uploadKbFile } from '../lib/files'
import { listAllTeamMembers, listDepartments, type DepartmentNode, type TeamMember } from '../lib/syngy'
import { dt, fmtDateTime, memberLabel, queryAll, selectLabel, table, toEpochSeconds } from '../lib/tables'
import type { PageCtx } from './DemandsPage'
import type { ArcubaseRow } from '../arcubase/runtime'
import type { DevOperatorFullAccess2Fields } from '../arcubase/ingresses/devOperatorFullAccess2'
import type { DevOperatorFullAccess4Fields } from '../arcubase/ingresses/devOperatorFullAccess4'
import type { DevOperatorFullAccess5Fields } from '../arcubase/ingresses/devOperatorFullAccess5'
import type { DevOperatorFullAccess8Fields } from '../arcubase/ingresses/devOperatorFullAccess8'
import type { DevOperatorFullAccess9Fields } from '../arcubase/ingresses/devOperatorFullAccess9'
import type { DevOperatorFullAccess10Fields } from '../arcubase/ingresses/devOperatorFullAccess10'
import type { DevOperatorFullAccess16Fields } from '../arcubase/ingresses/devOperatorFullAccess16'

type DemandRow = ArcubaseRow<DevOperatorFullAccess2Fields>
type ResumeRow = ArcubaseRow<DevOperatorFullAccess4Fields>
type PipelineRow = ArcubaseRow<DevOperatorFullAccess5Fields>
type InterviewRow = ArcubaseRow<DevOperatorFullAccess8Fields>
type FeedbackRow = ArcubaseRow<DevOperatorFullAccess9Fields>
type RecordRow = ArcubaseRow<DevOperatorFullAccess10Fields>
type MaterialRow = ArcubaseRow<DevOperatorFullAccess16Fields>

type BookForm = {
  pipelineId: string
  round: string
  mode: string
  scheduledAt: string
  interviewer: string
  meetingNo: string
}

const emptyBook: BookForm = { pipelineId: '', round: '1', mode: '', scheduledAt: '', interviewer: '', meetingNo: '' }

export function InterviewsPage({ viewer }: PageCtx) {
  const [interviews, setInterviews] = useState<InterviewRow[]>([])
  const [pipelines, setPipelines] = useState<PipelineRow[]>([])
  const [resumes, setResumes] = useState<ResumeRow[]>([])
  const [demands, setDemands] = useState<DemandRow[]>([])
  const [feedbacks, setFeedbacks] = useState<FeedbackRow[]>([])
  const [records, setRecords] = useState<RecordRow[]>([])
  const [materials, setMaterials] = useState<MaterialRow[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const [bookTarget, setBookTarget] = useState<PipelineRow | null>(null)
  const [bookForm, setBookForm] = useState<BookForm>(emptyBook)
  const [booking, setBooking] = useState(false)

  const [feedbackTarget, setFeedbackTarget] = useState<InterviewRow | null>(null)
  const [feedbackForm, setFeedbackForm] = useState({ result: '', comment: '' })
  const [feedbackSaving, setFeedbackSaving] = useState(false)

  const [recordTarget, setRecordTarget] = useState<InterviewRow | null>(null)
  const [recordForm, setRecordForm] = useState({ content: '' })
  const [recordFile, setRecordFile] = useState<File | null>(null)
  const [recordSaving, setRecordSaving] = useState(false)

  const [rescheduleTarget, setRescheduleTarget] = useState<InterviewRow | null>(null)
  const [rescheduleAt, setRescheduleAt] = useState('')
  const [rescheduling, setRescheduling] = useState(false)

  /** 面试记录抽屉目标（候选人流程实例） */
  const [recordsTarget, setRecordsTarget] = useState<PipelineRow | null>(null)
  const [focusId, setFocusId] = useState<string | null>(null)
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([])
  const [departments, setDepartments] = useState<DepartmentNode[]>([])

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const [i, p, r, d, f, rec, mat] = await Promise.all([
        queryAll(table('interviews')),
        queryAll(table('pipelines')),
        queryAll(table('resumes')),
        queryAll(table('demands')),
        queryAll(table('feedbacks')),
        queryAll(table('interviewRecords')),
        queryAll(table('resumeMaterials')),
      ])
      setInterviews(i as InterviewRow[])
      setPipelines(p as PipelineRow[])
      setResumes(r as ResumeRow[])
      setDemands(d as DemandRow[])
      setFeedbacks(f as FeedbackRow[])
      setRecords(rec as RecordRow[])
      setMaterials(mat as MaterialRow[])
    } catch (err) {
      setError(err instanceof Error ? err.message : '加载失败')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { void load() }, [load])

  useEffect(() => {
    listAllTeamMembers().then(setTeamMembers).catch(() => { /* 成员加载失败不阻塞主流程 */ })
    listDepartments().then(setDepartments).catch(() => { /* 部门加载失败不阻塞主流程 */ })
  }, [])

  // ?focus= 深链：打开对应候选人的面试记录抽屉并滚动到目标面试
  useEffect(() => {
    const focus = new URLSearchParams(window.location.search).get('focus')
    if (focus) setFocusId(focus)
  }, [])

  useEffect(() => {
    if (!focusId || loading) return
    const iv = interviews.find((i) => String(i.id) === focusId)
    if (iv) {
      const p = pipelines.find((pp) => String(pp.id) === String(iv.fields.pipelineId))
      if (p) setRecordsTarget(p)
    }
    requestAnimationFrame(() => {
      document.querySelector(`[data-interview-id="${focusId}"]`)?.scrollIntoView({ behavior: 'smooth', block: 'center' })
    })
  }, [focusId, loading, interviews, pipelines])

  const resumeById = useMemo(() => {
    const map = new Map<string, ResumeRow>()
    resumes.forEach((r) => map.set(String(r.id), r))
    return map
  }, [resumes])

  const demandById = useMemo(() => {
    const map = new Map<string, DemandRow>()
    demands.forEach((d) => map.set(String(d.id), d))
    return map
  }, [demands])

  /** 面试阶段的流程实例（候选人） */
  const interviewPipelines = useMemo(
    () => pipelines.filter((p) => selectLabel(p.fields.currentStage) === '面试'),
    [pipelines],
  )

  /** 每个候选人（pipeline）的面试记录 */
  const interviewsByPipeline = useMemo(() => {
    const map = new Map<string, InterviewRow[]>()
    interviews.forEach((iv) => {
      const key = String(iv.fields.pipelineId)
      const list = map.get(key) ?? []
      list.push(iv)
      map.set(key, list)
    })
    // 按时间倒序
    map.forEach((list) => list.sort((a, b) => (Number(b.fields.scheduledAt) || 0) - (Number(a.fields.scheduledAt) || 0)))
    return map
  }, [interviews])

  function pipelineLabel(p: PipelineRow): string {
    const resume = resumeById.get(String(p.fields.resumeId))
    const demand = demandById.get(String(p.fields.demandId))
    return `${resume?.fields.name ?? '未知候选人'} - ${demand?.fields.jobTitle ?? '未知岗位'}`
  }

  /** 抽屉中展示的面试列表（按时间倒序） */
  const drawerIvs = useMemo(
    () => (recordsTarget ? interviewsByPipeline.get(String(recordsTarget.id)) ?? [] : []),
    [recordsTarget, interviewsByPipeline],
  )

  function openBook(p: PipelineRow) {
    const existing = interviewsByPipeline.get(String(p.id)) ?? []
    setBookTarget(p)
    setBookForm({ ...emptyBook, pipelineId: String(p.id), round: String(existing.length + 1) })
  }

  /** 预约目标对应需求的部门名 */
  const bookDeptName = useMemo(() => {
    if (!bookTarget) return ''
    const demand = demandById.get(String(bookTarget.fields.demandId))
    return String(demand?.fields.department ?? '')
  }, [bookTarget, demandById])

  /** 需求部门（含子部门）下的全部成员：面试官下拉选项 */
  const bookDeptMembers = useMemo<TeamMember[]>(() => {
    if (!bookDeptName) return []
    const node = departments.find((d) => d.name === bookDeptName || d.id === bookDeptName)
    if (!node) return []
    // 部门自身 + 全部子孙部门的 id 集合
    const ids = new Set<string>([node.id])
    let grew = true
    while (grew) {
      grew = false
      for (const d of departments) {
        if (d.parentId && ids.has(d.parentId) && !ids.has(d.id)) {
          ids.add(d.id)
          grew = true
        }
      }
    }
    return teamMembers.filter((m) => m.departmentIds.some((id) => ids.has(id)))
  }, [bookDeptName, departments, teamMembers])

  /** 打开预约弹窗后默认选中面试官：当前登录人在部门内则选自己，否则选第一个成员 */
  useEffect(() => {
    if (!bookTarget || bookDeptMembers.length === 0) return
    const fallback = bookDeptMembers.find((m) => m.userId === viewer.id) ?? bookDeptMembers[0]
    setBookForm((f) => (f.interviewer ? f : { ...f, interviewer: fallback.arcubaseUserId }))
  }, [bookTarget, bookDeptMembers, viewer.id])

  async function submitBook() {
    if (!bookForm.pipelineId || !bookForm.scheduledAt || !bookForm.round) return
    setBooking(true)
    setError(null)
    try {
      await table('interviews').create({
        pipelineId: String(bookForm.pipelineId),
        round: Number(bookForm.round) || 1,
        mode: bookForm.mode || undefined,
        scheduledAt: dt(toEpochSeconds(bookForm.scheduledAt)),
        interviewer: bookForm.interviewer.trim() || viewer.id,
        meetingNo: bookForm.meetingNo.trim() || undefined,
        status: '已约',
      })
      setBookTarget(null)
      setBookForm(emptyBook)
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : '预约失败')
    } finally {
      setBooking(false)
    }
  }

  async function submitFeedback() {
    if (!feedbackTarget || !feedbackForm.result) return
    setFeedbackSaving(true)
    setError(null)
    try {
      await table('feedbacks').create({
        interviewId: String(feedbackTarget.id),
        result: feedbackForm.result,
        comment: feedbackForm.comment.trim() || undefined,
        submittedBy: viewer.id,
        submittedAt: dt(toEpochSeconds(new Date())),
      })
      await table('interviews').update(feedbackTarget.id, { status: '完成' })
      // 面试录取：流程自动进入背调阶段（HR 在"背调与拟薪"页继续处理）
      if (feedbackForm.result === '录取') {
        const now = dt(toEpochSeconds(new Date()))
        await table('pipelines').update(feedbackTarget.fields.pipelineId, {
          currentStage: '背调',
          stageTs: now,
        })
        const pipeline = pipelines.find((p) => String(p.id) === String(feedbackTarget.fields.pipelineId))
        if (pipeline) {
          await table('resumes').update(pipeline.fields.resumeId, { pipelineStatus: '背调' })
        }
      }
      setFeedbackTarget(null)
      setFeedbackForm({ result: '', comment: '' })
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : '提交反馈失败')
    } finally {
      setFeedbackSaving(false)
    }
  }

  async function submitRecord() {
    if (!recordTarget) return
    setRecordSaving(true)
    setError(null)
    try {
      // 附件存知识库；KB 指针写入 T16 材料表（T10 的 attachment 是 file 类型字段，只认平台 OSS upload 产物，无法存 KB 指针）
      if (recordFile) {
        const kb = await uploadKbFile(recordFile, 'interview-records')
        await table('resumeMaterials').create({
          fileName: kb.fileName,
          logicalPath: kb.logicalPath,
          sizeBytes: kb.sizeBytes,
          contentType: kb.contentType || 'application/octet-stream',
          batchId: `interview-${recordTarget.id}`,
          status: '面试附件',
          uploadedBy: viewer.id as any,
          uploadedAt: dt(toEpochSeconds(new Date())),
        })
      }
      await table('interviewRecords').create({
        interviewId: String(recordTarget.id),
        content: recordForm.content.trim() || undefined,
        uploadedBy: viewer.id,
        uploadedAt: dt(toEpochSeconds(new Date())),
      })
      setRecordTarget(null)
      setRecordForm({ content: '' })
      setRecordFile(null)
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : '提交记录失败')
    } finally {
      setRecordSaving(false)
    }
  }

  /** 面试附件（存知识库，T16 以 batchId=interview-{id} 关联）：点击下载 */
  function interviewAttachments(interviewId: number | string): MaterialRow[] {
    return materials.filter((m) => m.fields.batchId === `interview-${interviewId}`)
  }

  async function downloadAttachment(mat: MaterialRow) {
    try {
      const url = await getKbFileDownloadUrl(mat.fields.logicalPath)
      window.open(url, '_blank')
    } catch {
      setError('获取附件下载地址失败')
    }
  }

  async function submitReschedule() {
    if (!rescheduleTarget || !rescheduleAt) return
    setRescheduling(true)
    setError(null)
    try {
      await table('interviews').update(rescheduleTarget.id, {
        scheduledAt: dt(toEpochSeconds(rescheduleAt)),
        status: '改期',
      })
      window.alert('改期成功，系统将自动重排提醒。')
      setRescheduleTarget(null)
      setRescheduleAt('')
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : '改期失败')
    } finally {
      setRescheduling(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <div>
          <CardTitle>面试管理</CardTitle>
          <CardDescription>每个候选人（面试阶段的流程实例）一行，行内发起预约、反馈、记录、改期。</CardDescription>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {error ? <div className="px-4 py-3 text-sm text-red-600">{error}</div> : null}
        <Table>
          <THead>
            <TR>
              <TH>候选人</TH><TH>岗位</TH><TH>已约次数</TH><TH>最近面试时间</TH><TH>最近状态</TH><TH>面试官</TH><TH>操作</TH>
            </TR>
          </THead>
          <TBody>
            {loading ? <EmptyRow colSpan={7} text="加载中…" /> : null}
            {!loading && interviewPipelines.length === 0 ? <EmptyRow colSpan={7} text="暂无面试中的候选人" /> : null}
            {interviewPipelines.map((p) => {
              const resume = resumeById.get(String(p.fields.resumeId))
              const demand = demandById.get(String(p.fields.demandId))
              const ivs = interviewsByPipeline.get(String(p.id)) ?? []
              const latest = ivs[0]
              const latestStatus = latest ? selectLabel(latest.fields.status) : '待定'
              const focused = focusId !== null && ivs.some((iv) => String(iv.id) === focusId)
              return (
                <Fragment key={p.id}>
                  <TR className={focused ? 'bg-amber-50' : undefined}>
                    <TD className="font-medium">{resume?.fields.name ?? '—'}</TD>
                    <TD>{demand?.fields.jobTitle ?? '—'}</TD>
                    <TD>{ivs.length}</TD>
                    <TD>{latest ? fmtDateTime(latest.fields.scheduledAt) : '—'}</TD>
                    <TD><Badge tone={statusTone(latestStatus)}>{latestStatus}</Badge></TD>
                    <TD>{latest ? memberLabel(latest.fields.interviewer) : '—'}</TD>
                    <TD>
                      <div className="flex gap-1">
                        <Button type="button" size="sm" onClick={() => openBook(p)}>新建面试预约</Button>
                        <Button type="button" size="sm" variant="outline" onClick={() => setRecordsTarget(p)}>
                          记录({ivs.length})
                        </Button>
                      </div>
                    </TD>
                  </TR>
                </Fragment>
              )
            })}
          </TBody>
        </Table>
      </CardContent>

      <Sheet
        open={recordsTarget !== null}
        onOpenChange={(open) => { if (!open) setRecordsTarget(null) }}
        title="面试记录"
        description={recordsTarget ? pipelineLabel(recordsTarget) : undefined}
        width="max-w-2xl"
      >
        {drawerIvs.length === 0 ? (
          <div className="py-8 text-center text-sm text-slate-400">暂无面试记录</div>
        ) : (
          <div className="space-y-3">
            {drawerIvs.map((iv) => {
              const ivStatus = selectLabel(iv.fields.status)
              const ivFeedbacks = feedbacks.filter((f) => String(f.fields.interviewId) === String(iv.id))
              const ivRecords = records.filter((r) => String(r.fields.interviewId) === String(iv.id))
              return (
                <div key={iv.id} data-interview-id={iv.id} className="rounded border border-slate-200 bg-white p-3 text-sm">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-medium">第 {iv.fields.round} 轮</span>
                    <Badge tone={statusTone(ivStatus)}>{ivStatus}</Badge>
                    <span>{selectLabel(iv.fields.mode)}</span>
                    <span>{fmtDateTime(iv.fields.scheduledAt)}</span>
                    <span className="text-slate-400">{memberLabel(iv.fields.interviewer)}</span>
                    {iv.fields.meetingNo ? <span className="text-slate-400">会议号 {iv.fields.meetingNo}</span> : null}
                  </div>
                  <div className="mt-2 flex gap-1">
                    <Button type="button" size="sm" variant="outline" onClick={() => { setFeedbackTarget(iv); setFeedbackForm({ result: '', comment: '' }) }}>反馈</Button>
                    <Button type="button" size="sm" variant="outline" onClick={() => { setRecordTarget(iv); setRecordForm({ content: '' }); setRecordFile(null) }}>文字记录</Button>
                    <Button type="button" size="sm" variant="outline" onClick={() => { setRescheduleTarget(iv); setRescheduleAt('') }}>改期</Button>
                  </div>
                  {ivFeedbacks.length > 0 ? (
                    <div className="mt-2">
                      <div className="mb-1 text-xs font-medium text-slate-500">面试反馈</div>
                      <ul className="space-y-1">
                        {ivFeedbacks.map((f) => (
                          <li key={f.id} className="flex flex-wrap items-center gap-2">
                            <Badge tone={statusTone(selectLabel(f.fields.result))}>{selectLabel(f.fields.result)}</Badge>
                            <span>{f.fields.comment || '—'}</span>
                            <span className="text-slate-400">{memberLabel(f.fields.submittedBy)} · {fmtDateTime(f.fields.submittedAt)}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ) : null}
                  {ivRecords.length > 0 ? (
                    <div className="mt-2">
                      <div className="mb-1 text-xs font-medium text-slate-500">文字记录</div>
                      <ul className="space-y-1">
                        {ivRecords.map((r) => (
                          <li key={r.id}>
                            <div>{r.fields.content || '—'}</div>
                            <div className="text-slate-400">
                              {memberLabel(r.fields.uploadedBy)} · {fmtDateTime(r.fields.uploadedAt)}
                            </div>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ) : null}
                  {interviewAttachments(iv.id).length > 0 ? (
                    <div className="mt-2">
                      <div className="mb-1 text-xs font-medium text-slate-500">附件（知识库）</div>
                      <ul className="space-y-1">
                        {interviewAttachments(iv.id).map((m) => (
                          <li key={m.id}>
                            <button
                              type="button"
                              className="text-blue-600 hover:underline"
                              onClick={() => void downloadAttachment(m)}
                            >
                              附件：{m.fields.fileName}
                            </button>
                            <span className="text-slate-400"> · {memberLabel(m.fields.uploadedBy)} · {fmtDateTime(m.fields.uploadedAt)}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ) : null}
                </div>
              )
            })}
          </div>
        )}
      </Sheet>

      <Sheet
        open={bookTarget !== null}
        onOpenChange={(open) => { if (!open) setBookTarget(null) }}
        title="新建面试预约"
        description={bookTarget ? `候选人：${pipelineLabel(bookTarget)}` : undefined}
        footer={
          <>
            <Button type="button" variant="outline" onClick={() => setBookTarget(null)}>取消</Button>
            <Button
              type="button"
              disabled={booking || !bookForm.scheduledAt}
              onClick={() => void submitBook()}
            >
              {booking ? '提交中…' : '提交'}
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>轮次 *</Label>
              <Input type="number" min={1} value={bookForm.round} onChange={(e) => setBookForm({ ...bookForm, round: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label>方式</Label>
              <Select value={bookForm.mode} onChange={(e) => setBookForm({ ...bookForm, mode: e.target.value })}>
                <option value="">请选择</option>
                {INTERVIEW_MODES.map((m) => <option key={m} value={m}>{m}</option>)}
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>面试时间 *</Label>
            <Input type="datetime-local" value={bookForm.scheduledAt} onChange={(e) => setBookForm({ ...bookForm, scheduledAt: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label>面试官</Label>
            <Select value={bookForm.interviewer} onChange={(e) => setBookForm({ ...bookForm, interviewer: e.target.value })}>
              <option value="">请选择</option>
              {bookDeptMembers.map((m) => (
                <option key={m.userId} value={m.arcubaseUserId}>{m.displayName}</option>
              ))}
            </Select>
            <p className="text-xs text-slate-500">
              {bookDeptMembers.length > 0
                ? `可选「${bookDeptName || '需求部门'}」下全部成员（含子部门）`
                : '未找到需求部门成员，留空将默认为当前登录人'}
            </p>
          </div>
          <div className="space-y-1.5">
            <Label>会议号</Label>
            <Input value={bookForm.meetingNo} onChange={(e) => setBookForm({ ...bookForm, meetingNo: e.target.value })} />
          </div>
        </div>
      </Sheet>

      <Sheet
        open={feedbackTarget !== null}
        onOpenChange={(open) => !open && setFeedbackTarget(null)}
        title="提交面试反馈"
        footer={
          <>
            <Button type="button" variant="outline" onClick={() => setFeedbackTarget(null)}>取消</Button>
            <Button type="button" disabled={feedbackSaving || !feedbackForm.result} onClick={() => void submitFeedback()}>
              {feedbackSaving ? '提交中…' : '提交'}
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label>面试结果 *</Label>
            <Select value={feedbackForm.result} onChange={(e) => setFeedbackForm({ ...feedbackForm, result: e.target.value })}>
              <option value="">请选择</option>
              {INTERVIEW_RESULTS.map((r) => <option key={r} value={r}>{r}</option>)}
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>评语</Label>
            <Textarea value={feedbackForm.comment} onChange={(e) => setFeedbackForm({ ...feedbackForm, comment: e.target.value })} />
          </div>
        </div>
      </Sheet>

      <Sheet
        open={recordTarget !== null}
        onOpenChange={(open) => !open && setRecordTarget(null)}
        title="上传面试文字记录"
        footer={
          <>
            <Button type="button" variant="outline" onClick={() => setRecordTarget(null)}>取消</Button>
            <Button type="button" disabled={recordSaving || !recordForm.content.trim()} onClick={() => void submitRecord()}>
              {recordSaving ? '提交中…' : '提交'}
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label>记录内容 *</Label>
            <Textarea value={recordForm.content} onChange={(e) => setRecordForm({ ...recordForm, content: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label>附件（可选）</Label>
            <Input type="file" onChange={(e) => setRecordFile(e.target.files?.[0] ?? null)} />
          </div>
        </div>
      </Sheet>

      <Sheet
        open={rescheduleTarget !== null}
        onOpenChange={(open) => !open && setRescheduleTarget(null)}
        title="面试改期"
        description="选择新的面试时间，状态将更新为「改期」。"
        footer={
          <>
            <Button type="button" variant="outline" onClick={() => setRescheduleTarget(null)}>取消</Button>
            <Button type="button" disabled={rescheduling || !rescheduleAt} onClick={() => void submitReschedule()}>
              {rescheduling ? '提交中…' : '确认改期'}
            </Button>
          </>
        }
      >
        <div className="space-y-1.5">
          <Label>新面试时间 *</Label>
          <Input type="datetime-local" value={rescheduleAt} onChange={(e) => setRescheduleAt(e.target.value)} />
        </div>
      </Sheet>
    </Card>
  )
}
