import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react'
import { Badge } from '../components/ui/badge'
import { Button } from '../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Select } from '../components/ui/select'
import { Sheet } from '../components/ui/sheet'
import { Table, TBody, TD, TH, THead, TR, EmptyRow } from '../components/ui/table'
import { DEPT_FEEDBACK, statusTone } from '../lib/labels'
import { dt, fmtDateTime, memberLabel, queryAll, selectLabel, table, toEpochSeconds } from '../lib/tables'
import { listAllTeamMembers, listDepartments, type DepartmentNode, type TeamMember } from '../lib/syngy'
import type { PageCtx } from './DemandsPage'
import type { ArcubaseRow } from '../arcubase/runtime'
import type { DevOperatorFullAccess2Fields } from '../arcubase/ingresses/devOperatorFullAccess2'
import type { DevOperatorFullAccess4Fields } from '../arcubase/ingresses/devOperatorFullAccess4'
import type { DevOperatorFullAccess5Fields } from '../arcubase/ingresses/devOperatorFullAccess5'
import type { DevOperatorFullAccess7Fields } from '../arcubase/ingresses/devOperatorFullAccess7'

type DemandRow = ArcubaseRow<DevOperatorFullAccess2Fields>
type ResumeRow = ArcubaseRow<DevOperatorFullAccess4Fields>
type PipelineRow = ArcubaseRow<DevOperatorFullAccess5Fields>
type RecRow = ArcubaseRow<DevOperatorFullAccess7Fields>

export function RecommendationsPage({ viewer, roleNames = [] }: PageCtx) {
  const [recs, setRecs] = useState<RecRow[]>([])
  const [pipelines, setPipelines] = useState<PipelineRow[]>([])
  const [resumes, setResumes] = useState<ResumeRow[]>([])
  const [demands, setDemands] = useState<DemandRow[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [feedbackFilter, setFeedbackFilter] = useState('')
  const [actingId, setActingId] = useState<number | null>(null)
  /** 推荐详情抽屉 */
  const [detailRec, setDetailRec] = useState<RecRow | null>(null)
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([])
  const [departments, setDepartments] = useState<DepartmentNode[]>([])

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const [r, p, res, d] = await Promise.all([
        queryAll(table('recommendations')),
        queryAll(table('pipelines')),
        queryAll(table('resumes')),
        queryAll(table('demands')),
      ])
      setRecs(r as RecRow[])
      setPipelines(p as PipelineRow[])
      setResumes(res as ResumeRow[])
      setDemands(d as DemandRow[])
    } catch (err) {
      setError(err instanceof Error ? err.message : '加载失败')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { void load() }, [load])

  useEffect(() => {
    listAllTeamMembers().then(setTeamMembers).catch(() => { /* 成员加载失败不阻塞主流程 */ })
    listDepartments().then(setDepartments).catch(() => { /* 部门加载失败不阻塞主流程 */ })
  }, [])

  const pipelineById = useMemo(() => {
    const map = new Map<string, PipelineRow>()
    pipelines.forEach((p) => map.set(String(p.id), p))
    return map
  }, [pipelines])
  const resumeById = useMemo(() => {
    const map = new Map<string, ResumeRow>()
    resumes.forEach((r) => map.set(String(r.id), r))
    return map
  }, [resumes])
  const demandById = useMemo(() => {
    const map = new Map<string, DemandRow>()
    demands.forEach((d) => map.set(String(d.id), d))
    return map
  }, [demands])

  /** 需求是否与我相关：我是提出人 / 需求负责人 / 需求部门（含子部门）在我的管辖范围内 */
  function demandInMyScope(demand: DemandRow): boolean {
    const myMember = teamMembers.find((m) => m.userId === viewer.id)
    const myArcId = myMember?.arcubaseUserId ?? ''
    const proposer = String(demand.fields.proposer ?? '')
    const owner = String(demand.fields.departmentOwner ?? '')
    if (proposer === myArcId || owner === myArcId || proposer === viewer.id || owner === viewer.id) return true
    // 需求部门（存部门名）在我的管辖范围内：该部门自身或其任一祖先是我的部门
    const deptName = String(demand.fields.department ?? '')
    if (!deptName || !myMember) return false
    const myDeptIds = new Set(myMember.departmentIds ?? [])
    const deptNode = departments.find((d) => d.name === deptName || d.id === deptName)
    if (!deptNode) {
      // 部门树中找不到时按名称兜底
      const myDeptNames = new Set(departments.filter((d) => myDeptIds.has(d.id)).map((d) => d.name))
      return myDeptNames.has(deptName)
    }
    for (let node: DepartmentNode | undefined = deptNode; node; node = departments.find((d) => d.id === node.parentId)) {
      if (myDeptIds.has(node.id)) return true
    }
    return false
  }

  /** 当前用户是否为部门领导（以平台 actor 绑定为准：listMemberRoles → App 传入 roleNames） */
  const isLeader = roleNames.includes('部门领导')

  /** 列表可见范围：部门领导只看到与自己部门相关的推荐；其他角色（人事专员/人事经理/offer专员等）看全部 */
  const visibleRecs = useMemo(() => {
    if (!isLeader) return recs
    // 部门树/成员未加载完成时不过滤，避免误隐藏
    if (departments.length === 0 || teamMembers.length === 0) return recs
    return recs.filter((rec) => {
      const pipeline = pipelineById.get(String(rec.fields.pipelineId))
      const demand = pipeline ? demandById.get(String(pipeline.fields.demandId)) : undefined
      return demand ? demandInMyScope(demand) : false
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [recs, isLeader, departments, teamMembers, pipelineById, demandById, viewer.id])

  /** 当前用户是否可反馈：需求的提出人 / 需求负责人 / 需求部门（含子部门）的"部门领导"角色成员
   *  同一部门可有多个部门领导（如一车间邱哲、王闻先），权限相同。
   *  注：member 字段存数字 arcubaseUserId，需先把 viewer.id（Host userId）映射过去再比对 */
  function canFeedback(rec: RecRow): boolean {
    const pipeline = pipelineById.get(String(rec.fields.pipelineId))
    const demand = pipeline ? demandById.get(String(pipeline.fields.demandId)) : undefined
    if (!demand) return false
    return demandInMyScope(demand)
  }

  const filtered = useMemo(
    () => visibleRecs.filter((r) => !feedbackFilter || selectLabel(r.fields.deptFeedback) === feedbackFilter),
    [visibleRecs, feedbackFilter],
  )

  async function decide(rec: RecRow, pass: boolean) {
    setActingId(rec.id)
    setError(null)
    try {
      await table('recommendations').update(rec.id, {
        deptFeedback: pass ? '同意面试' : '不面试',
        feedbackChannel: '工作台',
        feedbackAt: dt(toEpochSeconds(new Date())),
      })
      const pipeline = pipelineById.get(String(rec.fields.pipelineId))
      const now = dt(toEpochSeconds(new Date()))
      if (pass) {
        // 同意：进入面试阶段，HR 专员可在面试管理页约面试时间
        await table('pipelines').update(rec.fields.pipelineId, {
          currentStage: '面试',
          stageTs: now,
        })
        if (pipeline) {
          await table('resumes').update(pipeline.fields.resumeId, { pipelineStatus: '面试' })
        }
      } else {
        // 拒绝：流程结束，简历转入储备人才库
        await table('pipelines').update(rec.fields.pipelineId, {
          currentStage: '结束',
          stageTs: now,
        })
        if (pipeline) {
          await table('resumes').update(pipeline.fields.resumeId, {
            library: '储备人才库',
            pipelineStatus: '结束',
          })
        }
      }
      setDetailRec(null)
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : '操作失败')
    } finally {
      setActingId(null)
    }
  }

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between gap-3">
        <div>
          <CardTitle>人才推荐</CardTitle>
          <CardDescription>提出人和部门负责人在此确认：同意后进入面试管理（HR 专员可约面试时间）；拒绝后候选人转入储备人才库。</CardDescription>
        </div>
        <Select value={feedbackFilter} onChange={(e) => setFeedbackFilter(e.target.value)} className="w-32">
          <option value="">全部反馈</option>
          {DEPT_FEEDBACK.map((s) => <option key={s} value={s}>{s}</option>)}
        </Select>
      </CardHeader>
      <CardContent className="p-0">
        {error ? <div className="px-4 py-3 text-sm text-red-600">{error}</div> : null}
        <Table>
          <THead>
            <TR>
              <TH>候选人</TH><TH>岗位</TH><TH>推荐人</TH><TH>接收人</TH><TH>推荐说明</TH>
              <TH>部门反馈</TH><TH>反馈渠道</TH><TH>反馈时间</TH><TH>操作</TH>
            </TR>
          </THead>
          <TBody>
            {loading ? <EmptyRow colSpan={9} text="加载中…" /> : null}
            {!loading && filtered.length === 0 ? <EmptyRow colSpan={9} /> : null}
            {filtered.map((rec) => {
              const pipeline = pipelineById.get(String(rec.fields.pipelineId))
              const resume = pipeline ? resumeById.get(String(pipeline.fields.resumeId)) : undefined
              const demand = pipeline ? demandById.get(String(pipeline.fields.demandId)) : undefined
              const fb = selectLabel(rec.fields.deptFeedback)
              return (
                <TR key={rec.id}>
                  <TD className="font-medium">{resume?.fields.name ?? '—'}</TD>
                  <TD>{demand?.fields.jobTitle ?? '—'}</TD>
                  <TD>{memberLabel(rec.fields.recommender)}</TD>
                  <TD>{memberLabel(rec.fields.receiver)}</TD>
                  <TD className="max-w-64 truncate">{rec.fields.aiSummary || '—'}</TD>
                  <TD><Badge tone={statusTone(fb)}>{fb}</Badge></TD>
                  <TD>{selectLabel(rec.fields.feedbackChannel)}</TD>
                  <TD>{rec.fields.feedbackAt ? fmtDateTime(rec.fields.feedbackAt) : '—'}</TD>
                  <TD>
                    <Button type="button" size="sm" variant="outline" onClick={() => setDetailRec(rec)}>
                      详情
                    </Button>
                  </TD>
                </TR>
              )
            })}
          </TBody>
        </Table>
      </CardContent>
      {detailRec ? <RecommendDetailSheet
        rec={detailRec}
        resume={(() => {
          const p = pipelineById.get(String(detailRec.fields.pipelineId))
          return p ? resumeById.get(String(p.fields.resumeId)) : undefined
        })()}
        demand={(() => {
          const p = pipelineById.get(String(detailRec.fields.pipelineId))
          return p ? demandById.get(String(p.fields.demandId)) : undefined
        })()}
        canFeedback={canFeedback(detailRec)}
        acting={actingId === detailRec.id}
        error={error}
        onClose={() => setDetailRec(null)}
        onDecide={(pass) => void decide(detailRec, pass)}
      /> : null}
    </Card>
  )
}

/** 推荐详情抽屉：候选人信息 + 推荐信息，底部同意/拒绝 */
function RecommendDetailSheet({ rec, resume, demand, canFeedback, acting, error, onClose, onDecide }: {
  rec: RecRow
  resume?: ResumeRow
  demand?: DemandRow
  canFeedback: boolean
  acting: boolean
  error: string | null
  onClose: () => void
  onDecide: (pass: boolean) => void
}) {
  const fb = selectLabel(rec.fields.deptFeedback)
  const f = resume?.fields
  const row = (label: string, value: ReactNode) => (
    <div className="flex gap-2 py-1.5 text-sm">
      <span className="w-20 shrink-0 text-slate-500">{label}</span>
      <span className="min-w-0 flex-1 text-slate-900">{value ?? '—'}</span>
    </div>
  )
  return (
    <Sheet
      open
      onOpenChange={(open) => { if (!open) onClose() }}
      title={`推荐详情${resume?.fields.name ? ` · ${resume.fields.name}` : ''}`}
      description={fb === '未反馈' ? '待部门反馈' : `部门已反馈：${fb}`}
      width="max-w-xl"
      footer={
        fb === '未反馈' && canFeedback ? (
          <>
            <Button type="button" variant="outline" disabled={acting} onClick={() => onDecide(false)}>
              拒绝（转入储备人才库）
            </Button>
            <Button type="button" disabled={acting} onClick={() => onDecide(true)}>
              {acting ? '提交中…' : '同意（进入面试）'}
            </Button>
          </>
        ) : (
          <span className="mr-auto text-sm text-slate-500">
            {fb === '未反馈' ? '当前账号无可反馈权限' : '该推荐已完成反馈'}
          </span>
        )
      }
    >
      {error ? <div className="mb-3 rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div> : null}
      <div className="mb-4">
        <div className="mb-1 text-sm font-semibold text-slate-900">候选人信息</div>
        {row('姓名', resume?.fields.name)}
        {row('性别', f?.gender ? selectLabel(f.gender) : '—')}
        {row('年龄', f?.age ?? '—')}
        {row('学历', f?.education ? selectLabel(f.education) : '—')}
        {row('毕业院校', f?.school || '—')}
        {row('工作年限', f?.workYears !== undefined ? `${f.workYears} 年` : '—')}
        {row('电话', f?.phone || '—')}
        {row('期望薪资', f?.expectedSalary || '—')}
        {row('技能', f?.skills || '—')}
      </div>
      <div>
        <div className="mb-1 text-sm font-semibold text-slate-900">推荐信息</div>
        {row('应聘岗位', demand?.fields.jobTitle)}
        {row('需求部门', demand?.fields.department)}
        {row('推荐人', memberLabel(rec.fields.recommender))}
        {row('接收人', memberLabel(rec.fields.receiver))}
        {row('推荐说明', <span className="whitespace-pre-wrap leading-[150%]">{rec.fields.aiSummary || '—'}</span>)}
        {row('部门反馈', <Badge tone={statusTone(fb)}>{fb}</Badge>)}
        {row('反馈渠道', selectLabel(rec.fields.feedbackChannel))}
        {row('反馈时间', rec.fields.feedbackAt ? fmtDateTime(rec.fields.feedbackAt) : '—')}
      </div>
    </Sheet>
  )
}
