import { useCallback, useEffect, useMemo, useState } from 'react'
import { navigate } from '../App'
import { Badge } from '../components/ui/badge'
import { Button } from '../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Select } from '../components/ui/select'
import { Table, TBody, TD, TH, THead, TR, EmptyRow } from '../components/ui/table'
import { STAGES, statusTone } from '../lib/labels'
import { fmtDateTime, queryAll, selectLabel, table } from '../lib/tables'
import type { ArcubaseRow } from '../arcubase/runtime'
import type { DevOperatorFullAccess5Fields } from '../arcubase/ingresses/devOperatorFullAccess5'
import type { DevOperatorFullAccess4Fields } from '../arcubase/ingresses/devOperatorFullAccess4'
import type { DevOperatorFullAccess2Fields } from '../arcubase/ingresses/devOperatorFullAccess2'
import type { PageCtx } from './DemandsPage'

type PipelineRow = ArcubaseRow<DevOperatorFullAccess5Fields>

function stageTarget(stage: string): string {
  switch (stage) {
    case '面试':
      return '/recruit/interviews'
    case '背调':
    case '拟薪':
      return '/recruit/screening'
    case 'offer':
      return '/recruit/offers'
    case '核验':
      return '/recruit/onboard'
    case '匹配':
    case '待推荐':
      return '/recruit/matching'
    default:
      return '/recruit'
  }
}

export function RecruitPage(_ctx: PageCtx) {
  const [rows, setRows] = useState<PipelineRow[]>([])
  const [resumeNames, setResumeNames] = useState<Record<string, string>>({})
  const [demandTitles, setDemandTitles] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [stageFilter, setStageFilter] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const [pipelines, resumes, demands] = await Promise.all([
        queryAll(table('pipelines')),
        queryAll(table('resumes')),
        queryAll(table('demands')),
      ])
      setRows(pipelines as PipelineRow[])
      const rMap: Record<string, string> = {}
      for (const r of resumes as Array<ArcubaseRow<DevOperatorFullAccess4Fields>>) {
        rMap[String(r.id)] = r.fields.name || '—'
      }
      setResumeNames(rMap)
      const dMap: Record<string, string> = {}
      for (const d of demands as Array<ArcubaseRow<DevOperatorFullAccess2Fields>>) {
        dMap[String(d.id)] = d.fields.jobTitle || '—'
      }
      setDemandTitles(dMap)
    } catch (err) {
      setError(err instanceof Error ? err.message : '加载失败')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { void load() }, [load])

  const filtered = useMemo(
    () => rows.filter((r) => !stageFilter || selectLabel(r.fields.currentStage) === stageFilter),
    [rows, stageFilter],
  )

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between gap-3">
        <div>
          <CardTitle>招聘流程</CardTitle>
          <CardDescription>全部在招流程实例，按当前阶段筛选并前往对应环节处理。</CardDescription>
        </div>
        <Select value={stageFilter} onChange={(e) => setStageFilter(e.target.value)} className="w-32">
          <option value="">全部阶段</option>
          {STAGES.map((s) => <option key={s} value={s}>{s}</option>)}
        </Select>
      </CardHeader>
      <CardContent className="p-0">
        {error ? <div className="px-4 py-3 text-sm text-red-600">{error}</div> : null}
        <Table>
          <THead>
            <TR>
              <TH>候选人</TH><TH>岗位</TH><TH>当前阶段</TH><TH>阶段时间</TH><TH>启动时间</TH><TH>操作</TH>
            </TR>
          </THead>
          <TBody>
            {loading ? <EmptyRow colSpan={6} text="加载中…" /> : null}
            {!loading && filtered.length === 0 ? <EmptyRow colSpan={6} /> : null}
            {filtered.map((row) => {
              const f = row.fields
              const stage = selectLabel(f.currentStage)
              return (
                <TR key={row.id}>
                  <TD className="font-medium">{resumeNames[String(f.resumeId)] ?? f.resumeId}</TD>
                  <TD>{demandTitles[String(f.demandId)] ?? f.demandId}</TD>
                  <TD><Badge tone={statusTone(stage)}>{stage}</Badge></TD>
                  <TD>{f.stageTs ? fmtDateTime(f.stageTs) : '—'}</TD>
                  <TD>{fmtDateTime(f.startedAt)}</TD>
                  <TD>
                    <Button type="button" size="sm" variant="outline" onClick={() => navigate(stageTarget(stage))}>
                      前往处理
                    </Button>
                  </TD>
                </TR>
              )
            })}
          </TBody>
        </Table>
      </CardContent>
    </Card>
  )
}
