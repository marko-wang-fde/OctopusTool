import { useCallback, useEffect, useMemo, useState } from 'react'
import { Badge } from '../components/ui/badge'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Input } from '../components/ui/input'
import { Table, TBody, TD, TH, THead, TR, EmptyRow } from '../components/ui/table'
import { Tabs } from '../components/ui/tabs'
import { LIBRARIES, statusTone } from '../lib/labels'
import { fmtDate, queryAll, selectLabel, table } from '../lib/tables'
import { navigate } from '../App'
import type { ArcubaseRow } from '../arcubase/runtime'
import type { DevOperatorFullAccess4Fields } from '../arcubase/ingresses/devOperatorFullAccess4'
import type { PageCtx } from './DemandsPage'

type ResumeRow = ArcubaseRow<DevOperatorFullAccess4Fields>

export function TalentsPage(_ctx: PageCtx) {
  const [rows, setRows] = useState<ResumeRow[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [activeLibrary, setActiveLibrary] = useState<string>(LIBRARIES[0])
  const [keyword, setKeyword] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      setRows(await queryAll(table('resumes')))
    } catch (err) {
      setError(err instanceof Error ? err.message : '加载失败')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { void load() }, [load])

  const filtered = useMemo(() => {
    const kw = keyword.trim().toLowerCase()
    return rows.filter((row) => {
      const f = row.fields
      if (selectLabel(f.library) !== activeLibrary) return false
      if (!kw) return true
      const name = String(f.name ?? '').toLowerCase()
      const phone = String(f.phone ?? '').toLowerCase()
      return name.includes(kw) || phone.includes(kw)
    })
  }, [rows, activeLibrary, keyword])

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between gap-3">
        <div>
          <CardTitle>人才库</CardTitle>
          <CardDescription>按库管理简历，点击行查看详情。</CardDescription>
        </div>
        <Input
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
          placeholder="搜索姓名 / 电话"
          className="w-56"
        />
      </CardHeader>
      <CardContent className="space-y-4 p-4">
        {error ? <div className="text-sm text-red-600">{error}</div> : null}
        <Tabs
          value={activeLibrary}
          onValueChange={setActiveLibrary}
          items={LIBRARIES.map((lib) => ({ value: lib, label: lib }))}
        />
        <Table>
          <THead>
            <TR>
              <TH>姓名</TH>
              <TH>电话</TH>
              <TH>性别</TH>
              <TH>学历</TH>
              <TH>学校</TH>
              <TH>工作年限</TH>
              <TH>期望薪资</TH>
              <TH>渠道</TH>
              <TH>解析状态</TH>
              <TH>流程状态</TH>
              <TH>来源</TH>
            </TR>
          </THead>
          <TBody>
            {loading ? <EmptyRow colSpan={11} text="加载中…" /> : null}
            {!loading && filtered.length === 0 ? <EmptyRow colSpan={11} /> : null}
            {filtered.map((row) => {
              const f = row.fields
              const parseStatus = selectLabel(f.parseStatus)
              const pipelineStatus = selectLabel(f.pipelineStatus)
              return (
                <TR
                  key={row.id}
                  className="cursor-pointer"
                  onClick={() => navigate(`/talents/${row.id}`)}
                >
                  <TD className="font-medium">{f.name}</TD>
                  <TD>{f.phone}</TD>
                  <TD>{selectLabel(f.gender)}</TD>
                  <TD>{selectLabel(f.education)}</TD>
                  <TD>{f.school || '—'}</TD>
                  <TD>{f.workYears !== undefined ? f.workYears : '—'}</TD>
                  <TD>{f.expectedSalary || '—'}</TD>
                  <TD>{selectLabel(f.channel)}</TD>
                  <TD><Badge tone={statusTone(parseStatus)}>{parseStatus}</Badge></TD>
                  <TD><Badge tone={statusTone(pipelineStatus)}>{pipelineStatus}</Badge></TD>
                  <TD>{selectLabel(f.source)}</TD>
                </TR>
              )
            })}
          </TBody>
        </Table>
      </CardContent>
    </Card>
  )
}
