import { useCallback, useEffect, useMemo, useState } from 'react'
import { Badge } from '../components/ui/badge'
import { Button } from '../components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card'
import { Table, TBody, TD, TH, THead, TR, EmptyRow } from '../components/ui/table'
import { statusTone } from '../lib/labels'
import { dt, fmtDateTime, memberLabel, queryAll, selectLabel, table, toEpochSeconds } from '../lib/tables'
import type { PageCtx } from './DemandsPage'
import type { ArcubaseRow } from '../arcubase/runtime'
import type { DevOperatorFullAccess2Fields } from '../arcubase/ingresses/devOperatorFullAccess2'
import type { DevOperatorFullAccess4Fields } from '../arcubase/ingresses/devOperatorFullAccess4'
import type { DevOperatorFullAccess5Fields } from '../arcubase/ingresses/devOperatorFullAccess5'
import type { DevOperatorFullAccess12Fields } from '../arcubase/ingresses/devOperatorFullAccess12'
import type { DevOperatorFullAccess13Fields } from '../arcubase/ingresses/devOperatorFullAccess13'

type PipelineRow = ArcubaseRow<DevOperatorFullAccess5Fields>
type ResumeRow = ArcubaseRow<DevOperatorFullAccess4Fields>
type DemandRow = ArcubaseRow<DevOperatorFullAccess2Fields>
type SalaryRow = ArcubaseRow<DevOperatorFullAccess12Fields>
type OfferRow = ArcubaseRow<DevOperatorFullAccess13Fields>

type OfferStatus = '已发' | '接受' | '拒绝'

export function OffersPage({ viewer, roles }: PageCtx) {
  const [pipelines, setPipelines] = useState<PipelineRow[]>([])
  const [resumes, setResumes] = useState<ResumeRow[]>([])
  const [demands, setDemands] = useState<DemandRow[]>([])
  const [salaries, setSalaries] = useState<SalaryRow[]>([])
  const [offers, setOffers] = useState<OfferRow[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [actingId, setActingId] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const [p, r, d, s, o] = await Promise.all([
        queryAll(table('pipelines')),
        queryAll(table('resumes')),
        queryAll(table('demands')),
        queryAll(table('salaries')),
        queryAll(table('offers')),
      ])
      setPipelines(p as PipelineRow[])
      setResumes(r as ResumeRow[])
      setDemands(d as DemandRow[])
      setSalaries(s as SalaryRow[])
      setOffers(o as OfferRow[])
    } catch (err) {
      setError(err instanceof Error ? err.message : '加载失败')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { void load() }, [load])

  const resumeById = useMemo(() => new Map(resumes.map((r) => [String(r.id), r])), [resumes])
  const demandById = useMemo(() => new Map(demands.map((d) => [String(d.id), d])), [demands])

  const offerPipelines = useMemo(
    () => pipelines.filter((p) => selectLabel(p.fields.currentStage) === 'offer'),
    [pipelines],
  )

  const offerByPipeline = useMemo(() => {
    const map = new Map<string, OfferRow>()
    for (const o of offers) map.set(String(o.fields.pipelineId ?? ''), o)
    return map
  }, [offers])

  function latestSalary(pipelineId: string): SalaryRow | undefined {
    const list = salaries.filter((s) => String(s.fields.pipelineId) === pipelineId)
    return list.length === 0 ? undefined : list[list.length - 1]
  }

  function candidateName(p: PipelineRow): string {
    return resumeById.get(String(p.fields.resumeId))?.fields.name ?? String(p.fields.resumeId)
  }
  function jobTitleOf(p: PipelineRow): string {
    return demandById.get(String(p.fields.demandId))?.fields.jobTitle ?? String(p.fields.demandId)
  }

  const canOperate = roles.includes('offer专员') || roles.includes('人事专员') || roles.includes('人事经理')

  async function mark(p: PipelineRow, status: OfferStatus) {
    setActingId(`${p.id}:${status}`)
    setError(null)
    try {
      const now = dt(toEpochSeconds(new Date()))
      const existing = offerByPipeline.get(String(p.id))
      if (existing) {
        await table('offers').update(existing.id, { status, markedBy: viewer.id, markedAt: now })
      } else {
        await table('offers').create({ pipelineId: String(p.id), status, markedBy: viewer.id, markedAt: now })
      }
      if (status === '接受') {
        await table('pipelines').update(p.id, { currentStage: '核验', stageTs: now })
        await table('resumes').update(p.fields.resumeId, { pipelineStatus: '核验' })
      }
      await load()
    } catch (err) {
      setError(err instanceof Error ? err.message : '操作失败')
    } finally {
      setActingId(null)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Offer 管理</CardTitle>
        <CardDescription>薪资审批通过后才能标记 Offer 已发（流程不可跳步）；候选人接受后流程进入到岗核验。</CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        {error ? <div className="px-4 py-3 text-sm text-red-600">{error}</div> : null}
        <Table>
          <THead>
            <TR>
              <TH>候选人</TH><TH>岗位</TH><TH>薪资状态</TH><TH>Offer 状态</TH>
              <TH>标记人</TH><TH>标记时间</TH><TH>操作</TH>
            </TR>
          </THead>
          <TBody>
            {loading ? <EmptyRow colSpan={7} text="加载中…" /> : null}
            {!loading && offerPipelines.length === 0 ? <EmptyRow colSpan={7} /> : null}
            {offerPipelines.map((p) => {
              const offer = offerByPipeline.get(String(p.id))
              const offerStatus = offer ? selectLabel(offer.fields.status) : ''
              const salary = latestSalary(String(p.id))
              const salaryStatus = salary ? selectLabel(salary.fields.status) : '—'
              const salaryApproved = salaryStatus === '通过' || salaryStatus === '修改后通过'
              const canSend = canOperate && salaryApproved
              return (
                <TR key={p.id}>
                  <TD className="font-medium">{candidateName(p)}</TD>
                  <TD>{jobTitleOf(p)}</TD>
                  <TD><Badge tone={statusTone(salaryStatus)}>{salaryStatus}</Badge></TD>
                  <TD>{offerStatus ? <Badge tone={statusTone(offerStatus)}>{offerStatus}</Badge> : <span className="text-slate-400">未标记</span>}</TD>
                  <TD>{offer ? memberLabel(offer.fields.markedBy) : '—'}</TD>
                  <TD>{offer?.fields.markedAt ? fmtDateTime(offer.fields.markedAt) : '—'}</TD>
                  <TD>
                    <div className="flex gap-1">
                      <Button
                        type="button"
                        className="h-8 px-2 text-xs"
                        disabled={!canSend || actingId !== null}
                        title={salaryApproved ? undefined : '需拟薪审批通过（通过/修改后通过）后才能标记已发（流程不可跳步）'}
                        onClick={() => void mark(p, '已发')}
                      >
                        标记已发
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        className="h-8 px-2 text-xs"
                        disabled={!canSend || actingId !== null}
                        title={salaryApproved ? undefined : '需拟薪审批通过（通过/修改后通过）后才能操作（流程不可跳步）'}
                        onClick={() => void mark(p, '接受')}
                      >
                        标记接受
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        className="h-8 px-2 text-xs"
                        disabled={!canSend || actingId !== null}
                        title={salaryApproved ? undefined : '需拟薪审批通过（通过/修改后通过）后才能操作（流程不可跳步）'}
                        onClick={() => void mark(p, '拒绝')}
                      >
                        标记拒绝
                      </Button>
                    </div>
                  </TD>
                </TR>
              )
            })}
          </TBody>
        </Table>
      </CardContent>
    </Card>
  )
}
