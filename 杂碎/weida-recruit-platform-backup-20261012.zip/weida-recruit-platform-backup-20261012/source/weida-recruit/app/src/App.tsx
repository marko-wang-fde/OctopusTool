import { useEffect, useMemo, useState } from 'react'
import type { ComponentType } from 'react'
import {
  AlertCircle,
  CalendarCheck,
  ChartNoAxesColumnIncreasing,
  ClipboardList,
  FileText,
  Handshake,
  LayoutDashboard,
  ListChecks,
  LogOut,
  Menu,
  ScanSearch,
  Settings,
  ShieldCheck,
  Sparkles,
  Users,
  X,
} from 'lucide-react'
import { Button } from './components/ui/button'
import { initializeWorkbench, listAllTeamMembers, listDepartments, listMemberRoles, readWorkbenchViewer, signOutWorkbench, type DepartmentNode, type TeamMember, type WorkbenchViewer } from './lib/syngy'
import { registerMemberNames } from './lib/memberNames'
import { inferBusinessRole, type BusinessRole } from './lib/roles'
import { DashboardPage } from './pages/DashboardPage'
import { TodayPage } from './pages/TodayPage'
import { TalentsPage } from './pages/TalentsPage'
import { TalentDetailPage } from './pages/TalentDetailPage'
import { RecruitPage } from './pages/RecruitPage'
import { DemandsPage } from './pages/DemandsPage'
import { MatchingPage } from './pages/MatchingPage'
import { InterviewsPage } from './pages/InterviewsPage'
import { RecommendationsPage } from './pages/RecommendationsPage'
import { ScreeningPage } from './pages/ScreeningPage'
import { OffersPage } from './pages/OffersPage'
import { OnboardPage } from './pages/OnboardPage'
import { JobsPage } from './pages/JobsPage'
import { ConfigPage } from './pages/ConfigPage'

type IconComponent = ComponentType<{ className?: string }>

type NavItem = {
  key: string
  path: string
  label: string
  icon: IconComponent
  title: string
  eyebrow: string
  /** 可见角色（design/04）；空数组=全部角色 */
  roles?: BusinessRole[]
}

type NavGroup = { group: string; items: NavItem[] }

const ALL_ROLES: BusinessRole[] = ['人事专员', '人事经理', '部门领导', 'offer专员', '未知']
const HR_ONLY: BusinessRole[] = ['人事专员', '人事经理', '未知']
const HR_AND_LEADER_RO: BusinessRole[] = ['人事专员', '人事经理', '部门领导', '未知']

const navGroups: NavGroup[] = [
  {
    group: 'M1 招聘驾驶舱',
    items: [
      { key: 'dashboard', path: '/dashboard', label: '招聘驾驶舱', icon: LayoutDashboard, title: '招聘驾驶舱', eyebrow: 'M1 招聘驾驶舱', roles: HR_ONLY },
    ],
  },
  {
    group: 'M2 今日待办',
    items: [
      { key: 'today', path: '/today', label: '今日待办', icon: CalendarCheck, title: '今日待办', eyebrow: 'M2 今日待办', roles: ALL_ROLES },
    ],
  },
  {
    group: 'M3 人才库',
    items: [
      { key: 'talents', path: '/talents', label: '人才库', icon: Users, title: '人才库', eyebrow: 'M3 人才库', roles: ALL_ROLES },
    ],
  },
  {
    group: 'M4 招聘管理',
    items: [
      { key: 'recruit', path: '/recruit', label: '流程列表', icon: ListChecks, title: '招聘流程列表', eyebrow: 'M4 招聘管理', roles: ALL_ROLES },
      { key: 'demands', path: '/recruit/demands', label: '用人需求管理', icon: FileText, title: '用人需求管理', eyebrow: 'M4.1 用人需求', roles: ALL_ROLES },
      { key: 'matching', path: '/recruit/matching', label: '简历匹配', icon: ScanSearch, title: '简历匹配', eyebrow: 'M4.2 简历匹配', roles: HR_ONLY },
      { key: 'recommendations', path: '/recruit/recommendations', label: '人才推荐', icon: Handshake, title: '人才推荐', eyebrow: 'M4.3 人才推荐', roles: ALL_ROLES },
      { key: 'interviews', path: '/recruit/interviews', label: '面试管理', icon: ClipboardList, title: '面试管理', eyebrow: 'M4.4 面试管理', roles: ALL_ROLES },
      { key: 'screening', path: '/recruit/screening', label: '背调与拟薪', icon: ShieldCheck, title: '背调与拟薪', eyebrow: 'M4.5 背调与拟薪', roles: HR_ONLY },
      { key: 'offers', path: '/recruit/offers', label: 'Offer 管理', icon: Handshake, title: 'Offer 管理', eyebrow: 'M4.6 Offer 管理', roles: ['offer专员', '人事专员', '人事经理', '未知'] },
      { key: 'onboard', path: '/recruit/onboard', label: '到岗核验', icon: ChartNoAxesColumnIncreasing, title: '到岗核验', eyebrow: 'M4.7 到岗核验', roles: HR_ONLY },
    ],
  },
  {
    group: 'M5 系统设置',
    items: [
      { key: 'jobs', path: '/settings/jobs', label: '岗位管理', icon: FileText, title: '岗位管理', eyebrow: 'M5.1 岗位管理', roles: HR_AND_LEADER_RO },
      { key: 'config', path: '/settings/config', label: '配置', icon: Settings, title: '配置', eyebrow: 'M5.2 配置', roles: HR_ONLY },
    ],
  },
]

const allItems = navGroups.flatMap((g) => g.items)

type Route = { key: string; param?: string }

function routeFromLocation(): Route {
  if (typeof window === 'undefined') return { key: 'dashboard' }
  const pathname = window.location.pathname.replace(/\/+$/, '') || '/'
  if (pathname === '/') return { key: 'dashboard' }
  const talentMatch = pathname.match(/^\/talents\/(\d+)$/)
  if (talentMatch) return { key: 'talent-detail', param: talentMatch[1] }
  const found = allItems.find((item) => item.path === pathname)
  return { key: found?.key ?? 'dashboard' }
}

export function navigate(path: string) {
  if (window.location.pathname !== path) {
    window.history.pushState({}, '', path)
  }
  window.dispatchEvent(new PopStateEvent('popstate'))
}

function viewerInitial(viewer: WorkbenchViewer | null): string {
  const value = viewer?.displayName || viewer?.email || ''
  return value ? value.slice(0, 1).toUpperCase() : ''
}

export function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [route, setRoute] = useState<Route>(() => routeFromLocation())
  const [ready, setReady] = useState(false)
  const [viewer, setViewer] = useState<WorkbenchViewer | null>(null)
  const [departments, setDepartments] = useState<DepartmentNode[]>([])
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([])
  const [viewerRoleNames, setViewerRoleNames] = useState<string[]>([])
  const [error, setError] = useState<string | null>(null)

  /** 业务角色数组（用于权限/可见性）：平台 actorIds 映射；一个用户可有多个角色 */
  const roles = useMemo<BusinessRole[]>(() => {
    const businessNames = ['人事专员', '人事经理', '部门领导', 'offer专员'] as const
    const matched = businessNames.filter((name) => viewerRoleNames.includes(name))
    if (matched.length > 0) return matched
    return [inferBusinessRole(viewer)]
  }, [viewerRoleNames, viewer])
  /** 主角色（用于展示/提出人角色默认值）：按优先级取第一个 */
  const role = roles[0]
  const activeItem = useMemo(() => allItems.find((item) => item.key === route.key), [route])

  /** 当前用户所在部门名列表（按部门树顺序） */
  const viewerDepartments = useMemo(() => {
    if (!viewer) return [] as string[]
    // viewer.id 是 Host userId；teamMembers 里保存了 arcubaseUserId ↔ Host userId 的映射
    const me = teamMembers.find((m) => m.userId === viewer.id)
    if (!me) return [] as string[]
    const deptMap = new Map(departments.map((d) => [d.id, d.name]))
    return me.departmentIds.map((id) => deptMap.get(id)).filter((name): name is string => Boolean(name))
  }, [viewer, teamMembers, departments])

  useEffect(() => {
    const onPopState = () => setRoute(routeFromLocation())
    window.addEventListener('popstate', onPopState)
    return () => window.removeEventListener('popstate', onPopState)
  }, [])

  useEffect(() => {
    async function loadWorkbench() {
      const state = await initializeWorkbench()
      if (state.status === 'ready') {
        const v = await readWorkbenchViewer()
        const [deps, members, myRoles] = await Promise.all([
          listDepartments().catch(() => [] as DepartmentNode[]),
          listAllTeamMembers().catch(() => [] as TeamMember[]),
          v?.id ? listMemberRoles(v.id).catch(() => null) : Promise.resolve(null),
        ])
        setViewer(v)
        setDepartments(deps)
        setTeamMembers(members)
        // 注册成员姓名（兜底，覆盖 additional.users 里没出现的成员）
        registerMemberNames(members)
        // 平台返回 actors 数组已带 id+name，无需再 join orgRoles 列表
        setViewerRoleNames((myRoles?.actors ?? []).map((a) => a.name).filter(Boolean))
        setReady(true)
        return
      }
      setReady(false)
    }
    void loadWorkbench().catch((err: unknown) => {
      console.error(err)
      setError('应用数据暂时无法准备，请刷新页面重试。')
    })
  }, [])

  function navigateTo(item: NavItem) {
    navigate(item.path)
    setSidebarOpen(false)
  }

  function renderPage() {
    if (!ready || !viewer) {
      return <div className="px-4 py-16 text-center text-sm text-slate-400">正在准备工作台…</div>
    }
    // 权限拦截：无任何 actor 角色绑定 → 拒绝访问业务页
    // 注：Arcubase access-rule 是黑名单模型，不支持"无角色兜底"规则；此前端拦截是唯一强制点
    if (viewerRoleNames.length === 0) {
      return (
        <div className="px-4 py-16 text-center">
          <div className="mx-auto max-w-md rounded-lg border border-slate-200 bg-white p-8 shadow-sm">
            <div className="text-lg font-semibold text-slate-900">无访问权限</div>
            <div className="mt-2 text-sm text-slate-600">
              当前账号未绑定任何业务角色（人事专员 / 人事经理 / 部门领导 / offer专员），无法访问本系统。
            </div>
            <div className="mt-4 text-xs text-slate-500">
              请联系人事经理为你的账号绑定角色后再试。
            </div>
          </div>
        </div>
      )
    }
    const ctx = { viewer, role, roles, roleNames: viewerRoleNames }
    switch (route.key) {
      case 'dashboard': return <DashboardPage {...ctx} />
      case 'today': return <TodayPage {...ctx} />
      case 'talents': return <TalentsPage {...ctx} />
      case 'talent-detail': return route.param ? <TalentDetailPage {...ctx} id={route.param} /> : <TalentsPage {...ctx} />
      case 'recruit': return <RecruitPage {...ctx} />
      case 'demands': return <DemandsPage {...ctx} />
      case 'matching': return <MatchingPage {...ctx} />
      case 'recommendations': return <RecommendationsPage {...ctx} />
      case 'interviews': return <InterviewsPage {...ctx} />
      case 'screening': return <ScreeningPage {...ctx} />
      case 'offers': return <OffersPage {...ctx} />
      case 'onboard': return <OnboardPage {...ctx} />
      case 'jobs': return <JobsPage {...ctx} />
      case 'config': return <ConfigPage {...ctx} />
      default: return <DashboardPage {...ctx} />
    }
  }

  return (
    <main className="min-h-screen bg-slate-100 text-slate-950">
      <div className="flex min-h-screen">
        {sidebarOpen ? (
          <button
            type="button"
            className="fixed inset-0 z-30 bg-slate-950/40 lg:hidden"
            aria-label="Close navigation"
            onClick={() => setSidebarOpen(false)}
          />
        ) : null}

        <aside className={sidebarOpen
          ? 'fixed inset-y-0 left-0 z-40 flex w-64 shrink-0 flex-col border-r border-slate-200 bg-white shadow-xl lg:static lg:shadow-none'
          : 'fixed inset-y-0 left-0 z-40 hidden w-64 shrink-0 flex-col border-r border-slate-200 bg-white shadow-xl lg:static lg:flex lg:shadow-none'}
        >
          <div className="flex h-16 items-center justify-between border-b border-slate-200 px-4">
            <div className="flex items-center gap-3">
              <div className="flex size-9 items-center justify-center rounded-md bg-slate-950 text-white">
                <Sparkles className="size-4" />
              </div>
              <div>
                <div className="font-semibold">韦达招聘</div>
                <div className="text-xs text-slate-500">HR 数字员工</div>
              </div>
            </div>
            <Button type="button" variant="outline" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(false)}>
              <X className="size-4" />
            </Button>
          </div>

          <nav className="flex-1 space-y-3 overflow-y-auto p-3">
            {navGroups.map((group) => {
              const visible = group.items.filter((item) => !item.roles || item.roles.some((r) => roles.includes(r)))
              if (visible.length === 0) return null
              return (
                <div key={group.group} className="space-y-1">
                  <div className="px-3 py-1 text-xs font-medium text-slate-400">{group.group}</div>
                  {visible.map((item) => {
                    const Icon = item.icon
                    const active = route.key === item.key || (item.key === 'talents' && route.key === 'talent-detail')
                    return (
                      <button
                        key={item.key}
                        type="button"
                        className={active
                          ? 'flex h-10 w-full items-center gap-3 rounded-md bg-slate-950 px-3 text-left text-sm font-medium text-white'
                          : 'flex h-10 w-full items-center gap-3 rounded-md px-3 text-left text-sm font-medium text-slate-600 hover:bg-slate-100 hover:text-slate-950'}
                        onClick={() => navigateTo(item)}
                      >
                        <Icon className="size-4" />
                        <span>{item.label}</span>
                      </button>
                    )
                  })}
                </div>
              )
            })}
          </nav>
        </aside>

        <section className="flex min-w-0 flex-1 flex-col">
          <header className="flex h-16 items-center justify-between border-b border-slate-200 bg-white px-4">
            <div className="flex min-w-0 flex-1 items-center gap-3">
              <Button type="button" variant="outline" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
                <Menu className="size-4" />
              </Button>
              <div className="min-w-0">
                <div className="truncate text-sm font-medium text-slate-500">{activeItem?.eyebrow ?? '韦达招聘'}</div>
                <div className="truncate text-base font-semibold">{activeItem?.title ?? '招聘驾驶舱'}</div>
              </div>
            </div>
            <div className="ml-3 flex items-center gap-2">
              <div className="flex min-w-0 items-center gap-2 rounded-md border border-slate-200 bg-white px-2 py-1.5">
                <div className="flex size-7 shrink-0 items-center justify-center rounded-md bg-slate-950 text-xs font-semibold text-white">
                  {viewer ? viewerInitial(viewer) : <Sparkles className="size-3.5" />}
                </div>
                <div className="hidden min-w-0 sm:block">
                  <div className="truncate text-sm font-medium">{viewer?.displayName || '韦达招聘'}</div>
                  <div
                    className="truncate text-xs text-slate-500"
                    title={
                      `部门：${viewerDepartments.length ? viewerDepartments.join('、') : '—'}　` +
                      `角色：${viewerRoleNames.length ? viewerRoleNames.join('、') : '未知'}`
                    }
                  >
                    {(viewerDepartments.length > 0
                      ? `${viewerDepartments[0]}${viewerDepartments.length > 1 ? ` 等${viewerDepartments.length}个部门` : ''}`
                      : '—')
                    }
                    {' | '}
                    {viewerRoleNames.length > 0
                      ? `${viewerRoleNames[0]}${viewerRoleNames.length > 1 ? ` 等${viewerRoleNames.length}个角色` : ''}`
                      : role}
                  </div>
                </div>
              </div>
              <Button
                type="button"
                variant="outline"
                size="icon"
                title="切换账号（清除本地登录态并重新登录）"
                onClick={() => signOutWorkbench()}
              >
                <LogOut className="size-4" />
              </Button>
            </div>
          </header>

          <div className="flex-1 overflow-y-auto p-5">
            <div className="mx-auto flex w-full max-w-7xl flex-col gap-5">
              {error ? (
                <div className="flex items-start gap-2 rounded-md border border-red-200 bg-red-50 p-3 text-sm text-red-700">
                  <AlertCircle className="mt-0.5 size-4 shrink-0" />
                  <span>{error}</span>
                </div>
              ) : null}
              {renderPage()}
            </div>
          </div>
        </section>
      </div>
    </main>
  )
}
