import { createWorkbenchFetch } from '@syngy/workbench-auth'
import { createWorkbenchArcubaseRuntime, getTeamId, writeHostJson } from './syngy'

/**
 * 旧链路：Arcubase 文件上传（aliyun-oss post-object 流程）
 * 用于背调材料等场景（仍走 OSS 直传）；面试文字记录附件已改走 KB 链路
 */
export type ArcubaseFileValue = {
  upload_id: number
  file: string
  file_name: string
  meta: Record<string, any>
}

type UploadTokenResp = {
  id: number
  mode: string
  token_data: {
    accessid: string
    host: string
    policy: string
    signature: string
    dir: string
  }
}

export async function uploadArcubaseFile(file: File): Promise<ArcubaseFileValue[]> {
  const runtime = createWorkbenchArcubaseRuntime()
  const token = await runtime.request<UploadTokenResp>('POST', '/upload/token', { global: false })
  const td = token.token_data
  if (!td?.host || !td.dir || !td.policy || !td.signature || !td.accessid) {
    throw new Error('上传凭证不完整')
  }
  const safeName = file.name.replace(/[/\\]/g, '_')
  const key = `${td.dir}${Date.now()}-${safeName}`
  const form = new FormData()
  form.append('key', key)
  form.append('policy', td.policy)
  form.append('OSSAccessKeyId', td.accessid)
  form.append('signature', td.signature)
  form.append('success_action_status', '200')
  form.append('file', file)
  const resp = await fetch(td.host, { method: 'POST', body: form })
  if (!resp.ok) {
    throw new Error(`文件上传失败: ${resp.status}`)
  }
  return [{
    upload_id: token.id,
    file: key,
    file_name: file.name,
    meta: { size: file.size, mimeType: file.type },
  }]
}

export async function fetchArcubaseFile(fileValue: unknown): Promise<{ name: string; blob: Blob } | null> {
  const arr = Array.isArray(fileValue) ? fileValue : []
  const first = arr[0] as { file?: string; file_name?: string } | undefined
  if (!first?.file) return null
  const runtime = createWorkbenchArcubaseRuntime()
  const preview = await runtime.request<{ url?: string; preview_url?: string }>('POST', '/upload/preview', {
    upload_id: (first as any).upload_id,
    fname: first.file_name ?? first.file.split('/').pop(),
  }).catch(() => null)
  const url = preview?.url ?? preview?.preview_url
  if (!url) return null
  const authFetch = createWorkbenchFetch()
  const resp = await authFetch(url)
  if (!resp.ok) return null
  return { name: first.file_name ?? 'attachment', blob: await resp.blob() }
}

export function fileValueName(fileValue: unknown): string {
  const arr = Array.isArray(fileValue) ? fileValue : []
  const first = arr[0] as { file_name?: string } | undefined
  return first?.file_name ?? ''
}

// ============================================================================
// 以下是新链路：知识库（KB）文件上传
// ============================================================================

/**
 * 知识库（KB）文件上传链路：
 * 1) POST /api/v1/teams/{teamId}/files/presign-put 申请上传地址
 * 2) 浏览器 PUT 直传 fileGateway（同域，无 CORS）
 * 3) POST /api/v1/teams/{teamId}/files/upload-finalize 确认完成
 * 返回 logicalPath（知识库逻辑路径），写入 T16 简历材料表
 */

export type KbUploadResult = {
  logicalPath: string
  fileName: string
  sizeBytes: number
  contentType?: string
}

const KB_ROOT = 'weida-recruitment-resumes'

type PresignPutResp = {
  url: string
  method: string
  finalizeToken: string
  expireAt?: string
}

type FinalizeResp = {
  logicalPath: string
  fileName: string
  sizeBytes: number
  contentType?: string
}

/**
 * 上传文件到知识库
 * @param file 文件
 * @param subDir 子目录（如批次号），最终路径为 weida-recruitment-resumes/{subDir}/{fileName}
 */
export async function uploadKbFile(file: File, subDir?: string): Promise<KbUploadResult> {
  const teamId = getTeamId()
  const safeName = file.name.replace(/[/\\]/g, '_')
  const key = subDir
    ? `${KB_ROOT}/${subDir.replace(/^\/+|\/+$/g, '')}/${safeName}`
    : `${KB_ROOT}/${safeName}`

  // 1. 申请上传地址
  const presign = await writeHostJson<PresignPutResp>(
    `/api/v1/teams/${encodeURIComponent(teamId)}/files/presign-put`,
    { rootKind: 'kb', key, ttlSeconds: 600 },
  )

  // 2. PUT 直传 fileGateway
  const resp = await fetch(presign.url, {
    method: presign.method || 'PUT',
    body: file,
  })
  if (!resp.ok) {
    throw new Error(`文件上传失败: ${resp.status}`)
  }

  // 3. 确认完成
  const finalized = await writeHostJson<FinalizeResp>(
    `/api/v1/teams/${encodeURIComponent(teamId)}/files/upload-finalize`,
    { finalizeToken: presign.finalizeToken, rootKind: 'kb' },
  )

  return {
    logicalPath: finalized.logicalPath,
    fileName: finalized.fileName || safeName,
    sizeBytes: finalized.sizeBytes ?? file.size,
    contentType: finalized.contentType || file.type,
  }
}

/**
 * 获取知识库文件的下载/预览地址（短时有效）
 */
export async function getKbFileDownloadUrl(logicalPath: string): Promise<string> {
  const teamId = getTeamId()
  // logicalPath 形如 /kb/weida-recruitment-resumes/.../file.pdf
  // presign-get 需要的 key 是去掉 /kb/ 前缀后的相对路径
  const key = logicalPath.replace(/^\/kb\//, '')
  const result = await writeHostJson<{ url: string }>(
    `/api/v1/teams/${encodeURIComponent(teamId)}/files/presign-get`,
    { rootKind: 'kb', key, ttlSeconds: 600 },
  )
  return result.url
}

/**
 * 浏览器端计算文件 SHA-256 指纹
 */
export async function sha256File(file: File): Promise<string> {
  const buf = await file.arrayBuffer()
  const hash = await crypto.subtle.digest('SHA-256', buf)
  return Array.from(new Uint8Array(hash))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
}

/**
 * 面试文字记录附件（存知识库）：行内 attachment 字段写入 KB 指针值。
 * file_name 沿用旧字段名，兼容 fileValueName 显示；下载走 getKbFileDownloadUrl。
 */
export type KbAttachmentValue = {
  source: 'kb'
  logicalPath: string
  file_name: string
  meta?: { size?: number; mimeType?: string }
}

export function toKbAttachmentValue(result: KbUploadResult): KbAttachmentValue[] {
  return [{
    source: 'kb',
    logicalPath: result.logicalPath,
    file_name: result.fileName,
    meta: { size: result.sizeBytes, mimeType: result.contentType },
  }]
}

/** 从附件值中提取知识库 logicalPath（非 KB 附件返回空串） */
export function attachmentLogicalPath(fileValue: unknown): string {
  const arr = Array.isArray(fileValue) ? fileValue : []
  const first = arr[0] as { source?: string; logicalPath?: string } | undefined
  return first?.source === 'kb' ? String(first.logicalPath ?? '') : ''
}

// ============================================================================
// 简历解析：PDF/DOCX 文本提取 + 正则字段提取
// ============================================================================

import * as pdfjsLib from 'pdfjs-dist'
// Vite ?worker 后缀：编译为 Worker 构造器，打包时自动处理 worker 依赖
import PdfWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?worker'
pdfjsLib.GlobalWorkerOptions.workerPort = new PdfWorker()

export type ParsedResumeFields = {
  name?: string
  phone?: string
  email?: string
  gender?: string
  age?: number
  education?: string
  school?: string
  workYears?: number
  skills?: string
  expectedSalary?: string
  ethnicity?: string
  currentCity?: string
  expectedPosition?: string
  expectedCity?: string
  educationDetail?: string
  workExperience?: string
}

export type ParseResult = {
  text: string
  fields: ParsedResumeFields
}

/** 解析简历文件（PDF/DOCX），提取文本内容 + 结构化字段 */
export async function parseResumeFile(file: File): Promise<ParseResult> {
  const ext = file.name.toLowerCase().match(/\.([^.]+)$/)?.[1] ?? ''
  let text = ''
  if (ext === 'pdf' || file.type === 'application/pdf') {
    text = await extractPdfText(file)
  } else if (ext === 'docx') {
    text = await extractDocxText(file)
  } else if (ext === 'doc') {
    throw new Error('不支持 .doc 旧格式，请转换为 PDF 或 DOCX 后上传')
  } else {
    text = await file.text()
  }
  const fields = extractFields(text)
  return { text, fields }
}

/** PDF 文本提取（pdfjs-dist） */
async function extractPdfText(file: File): Promise<string> {
  const buf = await file.arrayBuffer()
  const doc = await pdfjsLib.getDocument({ data: new Uint8Array(buf) }).promise
  const parts: string[] = []
  for (let i = 1; i <= doc.numPages; i++) {
    const page = await doc.getPage(i)
    const content = await page.getTextContent()
    parts.push(content.items.map((item: any) => item.str).join(' '))
  }
  // 清理 pdfjs 文档资源（不同版本方法名可能不同，失败不阻塞）
  try { await (doc as any).cleanup?.() ?? (doc as any).destroy?.() } catch { /* ignore */ }
  return parts.join('\n')
}

/** DOCX 文本提取（mammoth 浏览器构建） */
async function extractDocxText(file: File): Promise<string> {
  const mod = await import('mammoth/mammoth.browser')
  const mammoth = (mod as any).default ?? mod
  const result = await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() })
  return result.value ?? ''
}

/** 从简历文本中正则提取结构化字段 */
function extractFields(rawText: string): ParsedResumeFields {
  const fields: ParsedResumeFields = {}
  // 归一化：压缩中文字符之间的多余空格（PDF 排版导致"姓    名" → "姓名"）
  const text = rawText.replace(/([\u4e00-\u9fa5])\s{2,}([\u4e00-\u9fa5])/g, '$1$2')
  const head = text.slice(0, 300)

  // 手机号：匹配连续11位或带横线/空格的格式
  const phoneMatch = text.match(/1[3-9]\d{9}/) || text.match(/1[3-9]\d[-\s]\d{4}[-\s]\d{4}/)
  if (phoneMatch) fields.phone = phoneMatch[0].replace(/[-\s]/g, '')

  // 邮箱
  const emailMatch = text.match(/[\w.+-]+@[\w-]+\.[\w.-]+/)
  if (emailMatch) fields.email = emailMatch[0]

  // 性别：优先按 "性别：男/女"，退而求其次在头部单独出现男/女
  const genderMatch = text.match(/性别\s*[:：]?\s*(男|女)/)
  if (genderMatch) {
    fields.gender = genderMatch[1]
  } else {
    const headNoNewline = head.replace(/\n/g, ' ')
    if (/男/.test(headNoNewline) && !/女|男女/.test(headNoNewline)) fields.gender = '男'
    else if (/女/.test(headNoNewline) && !/男|男女/.test(headNoNewline)) fields.gender = '女'
  }

  // 年龄
  const ageMatch = text.match(/(\d{1,2})\s*岁/)
  if (ageMatch) {
    const age = parseInt(ageMatch[1], 10)
    if (age >= 16 && age <= 70) fields.age = age
  }

  // 学历
  const eduMatch = text.match(/(博士研究生|硕士研究生|硕士|本科|大专|专科|MBA|EMBA)/)
  if (eduMatch) {
    const e = eduMatch[1]
    if (e.includes('博士')) fields.education = '博士'
    else if (e.includes('硕士') || e.includes('MBA') || e.includes('EMBA')) fields.education = '硕士'
    else if (e.includes('本科')) fields.education = '本科'
    else if (e.includes('大专') || e.includes('专科')) fields.education = '大专'
  }

  // 工作年限：匹配"工作年限：2年""2年采购经验""工作2年"等
  const yearsMatch = text.match(/工作年限\s*[:：]?\s*(\d+)\s*年/)
    || text.match(/(\d+)\s*年(?:工作|采购|从业|经验|销售|管理|技术)/)
    || text.match(/工作(?:经验)?\s*[:：]?\s*(\d+)\s*年/)
  if (yearsMatch) {
    fields.workYears = parseInt(yearsMatch[1], 10)
  }

  // 期望薪资：匹配"8-10K""8000-10000元/月"等
  const salaryMatch = text.match(/期望薪资\s*[:：]?\s*([\d\-~至]+(?:k|K|万|元)?(?:\/?月)?)/)
    || text.match(/(?:期望|要求)?(?:薪资|月薪|薪水|薪酬)\s*[:：]?\s*([\d\-~至]+(?:k|K|万|元)?(?:\/?月)?)/)
  if (salaryMatch) fields.expectedSalary = salaryMatch[1]

  // 毕业院校
  const schoolMatch = text.match(/(?:毕业院校|毕业学校|院校|学校|毕业于)\s*[:：]?\s*(.+?)(?:\n|$|。|，|；)/)
  if (schoolMatch) {
    fields.school = schoolMatch[1].trim()
  } else {
    // 尝试匹配大学/学院名称
    const uniMatch = text.match(/([\u4e00-\u9fa5]{2,20}(?:大学|学院|理工大学|科技大学|工业大学|农业大学|医科大学|师范大学|财经大学|政法大学|交通大学|人民大学))/)
    if (uniMatch) fields.school = uniMatch[1]
  }

  // 姓名：优先按 "姓名：XXX"，否则从前15行中找最可能是姓名的中文片段
  const nameMatch = text.match(/(?:姓名|名字)\s*[:：]\s*([\u4e00-\u9fa5]{2,4})/)
  if (nameMatch) {
    fields.name = nameMatch[1]
  } else {
    // 职位关键词：匹配到则排除该候选（避免把"采购专员"误识为姓名）
    const jobKw = /(专员|经理|主管|总监|助理|工程师|管理员|操作工|技术员|分析师|设计师|主任|部长|组长|秘书|文员|客服|销售|采购|仓库|质检|维修|电工|焊工|司机|保安|财务|会计|出纳|人事|行政|运营|市场|编辑|律师|医生|护士|教师|教授|学生|实习|生产|调度|统计|店长|店员|收银|前台|后勤|仓管|计划|跟单|物流|装卸|包装|录入|测试|运维|开发|前端|后端|算法|产品|项目|架构|安全|审计|税务|法务|品牌|媒介|直播|内容|增长|商业|投资|融资|上市|董秘)/
    // 常见姓氏（百家姓前120）
    const surnames = '李王张刘陈杨赵黄周吴徐孙胡朱高林何郭马罗梁宋郑谢韩唐冯于董萧程曹袁邓许傅沈曾彭吕苏蒋贾丁魏薛叶阎余潘杜戴夏钟汪田任姜范方石姚谭廖邹熊金陆郝孔白崔康毛邱秦江史顾侯邵龙万段雷钱汤尹黎易常武乔赖龚卢莫'
    // 排除非姓名词汇（户籍、地址、电话等字段标签）
    const excludeWords = /^(户籍|地址|电话|邮箱|手机|性别|年龄|民族|学历|籍贯|出生|身高|体重|政治|面貌|婚姻|状况|求职|意向|期望|工作|经验|年限|现居|居住|所在|城市|毕业|院校|专业|技能|证书|荣誉|语言|自我|评价|个人|优势|工作|经历|教育|背景|项目|经验|薪资|待遇|到岗|时间|目前|状态)$/
    const lines = text.split(/[\n\r]/).map((l) => l.trim()).filter(Boolean).slice(0, 15)
    let bestName = ''
    let bestScore = 0
    for (const line of lines) {
      const m = line.match(/^([\u4e00-\u9fa5]{2,4})(?![\u4e00-\u9fa5])/)
      if (!m) continue
      const name = m[1]
      // 排除职位行和非姓名词汇
      if (jobKw.test(name) || jobKw.test(line) || excludeWords.test(name)) continue
      let score = 1
      if (surnames.includes(name[0])) score += 10
      if (line === name) score += 5
      if (score > bestScore) { bestScore = score; bestName = name }
    }
    if (bestName) fields.name = bestName
  }

  // 技能：截取"专业技能/技能/特长"后的内容，最多取前3行（避免工作经历等正文污染）
  const skillMatch = text.match(/(?:专业技能|技能特长|技能|技术栈|特长)\s*[:：]?\s*([\s\S]+?)(?=\n\s*\n|工作经历|工作简历|教育经历|项目经验|项目经历|自我评价|工作经历|个人评价|$)/)
  if (skillMatch) {
    // 只取前3行非空行，防止正文被误纳入
    const lines = skillMatch[1].split(/[\n\r]+/).map((l) => l.trim()).filter(Boolean).slice(0, 3)
    const skills = lines.join('、').replace(/\s{2,}/g, ' ').trim().slice(0, 200)
    if (skills) fields.skills = skills
  }

  // 民族
  const ethnicityMatch = text.match(/民族\s*[:：]?\s*([\u4e00-\u9fa5]{1,4}族)/)
  if (ethnicityMatch) fields.ethnicity = ethnicityMatch[1]

  // 现居地
  const cityMatch = text.match(/(?:现居地|居住地|所在城市|城市)\s*[:：]?\s*([\u4e00-\u9fa5]{2,10}(?:市|区|县)?)/)
  if (cityMatch) fields.currentCity = cityMatch[1]

  // 应聘职位
  const positionMatch = text.match(/(?:应聘职位|求职意向|意向岗位|期望职位|目标岗位)\s*[:：]?\s*(.+?)(?:\n|$|。|，|；)/)
  if (positionMatch) fields.expectedPosition = positionMatch[1].trim()

  // 期望城市
  const expCityMatch = text.match(/(?:期望城市|期望工作地|意向城市|工作地点)\s*[:：]?\s*(.+?)(?:\n|$|。|，|；)/)
  if (expCityMatch) fields.expectedCity = expCityMatch[1].trim()

  // 教育背景段落：从"教育经历/教育背景/教育培训"开始到下一个大标题
  const eduSectionMatch = rawText.match(/(?:教育经历|教育背景|教育培训|教育情况)\s*[:：]?\s*([\s\S]+?)(?=\n\s*(?:工作经历|工作经验|项目经验|项目经历|自我评价|个人评价|技能|证书|荣誉|语言|求职意向|应聘职位|期望|个人优势|自我描述)|$)/i)
  if (eduSectionMatch) {
    const eduText = eduSectionMatch[1].trim().replace(/\s{2,}/g, ' ').slice(0, 2000)
    if (eduText) fields.educationDetail = eduText
  }

  // 工作经历段落：从"工作经历/工作经验/工作简历"开始到下一个大标题
  const workSectionMatch = rawText.match(/(?:工作经历|工作经验|工作简历|职业经历)\s*[:：]?\s*([\s\S]+?)(?=\n\s*(?:教育经历|教育背景|项目经验|项目经历|自我评价|个人评价|技能|证书|荣誉|语言|求职意向|应聘职位|期望|个人优势|自我描述)|$)/i)
  if (workSectionMatch) {
    const workText = workSectionMatch[1].trim().replace(/\s{2,}/g, ' ').slice(0, 4000)
    if (workText) fields.workExperience = workText
  }

  return fields
}
