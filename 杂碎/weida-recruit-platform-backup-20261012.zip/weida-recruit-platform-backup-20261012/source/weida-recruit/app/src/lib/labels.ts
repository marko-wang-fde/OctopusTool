/**
 * 业务枚举常量（与 design/05 表字典一致）。
 */

export const DEMAND_STATUS = ['草稿', '待审批', '通过', '驳回'] as const
export const PROPOSER_ROLES = ['部门领导', '人事专员'] as const
export const JOB_STATUS = ['启用', '停用'] as const
export const GENDERS = ['男', '女', '未知'] as const
export const EDUCATIONS = ['大专', '本科', '硕士', '博士', '其他'] as const
export const CHANNELS = ['boss直聘', '前程无忧', '智联招聘', '猎聘', '拉勾', '内推', '猎头推荐', '官网投递', '其他'] as const
export const LIBRARIES = ['应聘简历库', '储备人才库', '关键岗位人才库', '风险受控', '在职员工库'] as const
export const RESUME_PIPELINE_STATUS = ['未进流程', '匹配', '待推荐', '面试', '背调', '拟薪', 'offer', '核验', '暂停', '结束'] as const
export const PARSE_STATUS = ['待解析', '已解析', '失败'] as const
export const RESUME_SOURCES = ['上传', '企微'] as const
export const STAGES = ['匹配', '待推荐', '面试', '背调', '拟薪', 'offer', '核验', '暂停', '结束'] as const
export const MATCH_TIERS = ['合适', '待定', '不合适'] as const
export const MATCH_SOURCES = ['自动', '手动'] as const
export const DEPT_FEEDBACK = ['同意面试', '不面试', '未反馈'] as const
export const FEEDBACK_CHANNELS = ['企微', '工作台'] as const
export const INTERVIEW_MODES = ['线上', '线下'] as const
export const INTERVIEW_STATUS = ['已约', '完成', '改期', '取消', '待定'] as const
export const INTERVIEW_RESULTS = ['录取', '不通过', '再次面试', '待定'] as const
export const MATERIAL_TYPES = ['薪资流水', '学历证明', '离职证明', '其他'] as const
export const SALARY_STATUS = ['待审批', '通过', '修改后通过', '驳回'] as const
export const OFFER_STATUS = ['已发', '接受', '拒绝'] as const
export const ONBOARD_RESULTS = ['已到岗', '提前说明不来', '无故未到'] as const
export const REMINDER_TYPES = ['审批超时', '反馈超时', '面试前', '上传记录', '核验提醒'] as const
export const REMINDER_STATUS = ['待发', '已发', '停止'] as const
export const REMINDER_CHANNELS = ['企微', '系统', '企微+系统'] as const
export const MATERIAL_STATUS = ['待解析', '已解析', '解析失败'] as const

/** 阶段顺序（流程不可跳步红线） */
export const STAGE_ORDER = ['匹配', '待推荐', '面试', '背调', '拟薪', 'offer', '核验'] as const

/** 状态徽标颜色 */
export function statusTone(status: string): 'default' | 'green' | 'red' | 'amber' | 'blue' | 'slate' {
  switch (status) {
    case '通过': case '已到岗': case '接受': case '录取': case '同意面试': case '合适': case '已发': case '已完成':
      return 'green'
    case '驳回': case '不通过': case '不面试': case '不合适': case '拒绝': case '无故未到': case '失败':
      return 'red'
    case '待审批': case '待解析': case '未反馈': case '待定': case '待发': case '暂停':
      return 'amber'
    case '面试': case '背调': case '拟薪': case 'offer': case '核验': case '匹配': case '待推荐': case '已约': case '再次面试':
      return 'blue'
    default:
      return 'slate'
  }
}
