import type { WorkbenchViewer } from './syngy'

/**
 * 业务角色（design/03 §2）。
 * 平台角色 actor id 尚未配置，当前从会话 viewer.role 文本推断；
 * 数据级隔离必须由后端 access-rule 强制（待角色矩阵生效），前端仅做展示层控制。
 */
export type BusinessRole = '人事专员' | '人事经理' | '部门领导' | 'offer专员' | '未知'

export function inferBusinessRole(viewer: WorkbenchViewer | null): BusinessRole {
  const text = `${viewer?.role ?? ''} ${viewer?.displayName ?? ''}`
  if (text.includes('人事经理')) return '人事经理'
  if (text.includes('人事专员')) return '人事专员'
  if (text.includes('offer专员') || text.includes('Offer专员')) return 'offer专员'
  if (text.includes('部门领导') || text.includes('部门负责人')) return '部门领导'
  return '未知'
}

/** 拟薪金额仅人事经理可见（前端展示层；后端 access-rule 矩阵待生效后强制）。 */
export function canSeeSalaryAmount(roles: BusinessRole[]): boolean {
  return roles.includes('人事经理')
}
