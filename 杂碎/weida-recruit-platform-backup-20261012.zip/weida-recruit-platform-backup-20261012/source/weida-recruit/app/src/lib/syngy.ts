import { createWorkbenchFetch, ensureWorkbenchRuntime, getWorkbenchHostApiBaseUrl, getWorkbenchRuntimeConfig } from '@syngy/workbench-auth'
import { redirectToWorkbenchDevLogin } from '@syngy/workbench-devtools/runtime'
import { clearWorkbenchSession } from '@syngy/workbench-auth'
import { createOctopusClient } from '@syngy/octopus-client'
import { createArcubaseClient } from '@syngy/arcubase-client'
import { captureAdditionalUsers } from './memberNames'

export type WorkbenchViewer = {
  id: string
  displayName: string
  email?: string
  role?: string
  avatarUrl?: string
}

function cleanViewerValue(value: unknown): string {
  return typeof value === 'string' ? value.trim() : ''
}

function viewerFromRuntime(runtime: SyngyRuntimeConfig): WorkbenchViewer | null {
  const runtimeViewer = runtime.viewer
  const id = cleanViewerValue(runtimeViewer?.id)
  const displayName = cleanViewerValue(runtimeViewer?.displayName) || cleanViewerValue(runtimeViewer?.email)
  if (!id) {
    return null
  }
  return {
    id,
    displayName: displayName || id,
    email: cleanViewerValue(runtimeViewer?.email) || undefined,
    role: cleanViewerValue(runtimeViewer?.role) || undefined,
    avatarUrl: cleanViewerValue(runtimeViewer?.avatarUrl) || undefined,
  }
}

function unwrapPinData<T>(payload: { data?: T } | T): T {
  return payload && typeof payload === 'object' && 'data' in payload ? payload.data as T : payload as T
}

async function readHostJson<T>(path: string): Promise<T> {
  const runtime = getWorkbenchRuntimeConfig()
  const authFetch = createWorkbenchFetch()
  const url = new URL(path.replace(/^\/+/, ''), `${getWorkbenchHostApiBaseUrl(runtime)}/`).toString()
  const response = await authFetch(url, { headers: { Accept: 'application/json' } })
  const payload = await response.json() as { data?: T } | T
  if (!response.ok) {
    throw new Error(`Host request failed: ${response.status}`)
  }
  return unwrapPinData(payload)
}

/** POST 到 Host API（KB 文件上传等平台能力走此通道，不走 Arcubase） */
export async function writeHostJson<T>(path: string, body: unknown): Promise<T> {
  const runtime = getWorkbenchRuntimeConfig()
  const authFetch = createWorkbenchFetch()
  const url = new URL(path.replace(/^\/+/, ''), `${getWorkbenchHostApiBaseUrl(runtime)}/`).toString()
  const response = await authFetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify(body),
  })
  const payload = await response.json() as { data?: T; error?: { message?: string } } | T
  const upstreamError = payload && typeof payload === 'object' && 'error' in payload ? payload.error : undefined
  if (!response.ok || upstreamError) {
    throw new Error(upstreamError?.message ?? `Host request failed: ${response.status}`)
  }
  return unwrapPinData(payload)
}

/** 获取当前团队 ID（KB 文件接口需要） */
export function getTeamId(): string {
  const runtime = getWorkbenchRuntimeConfig()
  if (!runtime.teamId) throw new Error('Workbench runtime teamId is required')
  return runtime.teamId
}

export async function initializeWorkbench() {
  const state = await ensureWorkbenchRuntime({ standaloneAuth: 'never' })
  if (state.status !== 'ready' && redirectToWorkbenchDevLogin()) {
    return { status: 'redirecting_to_workbench_login' } as const
  }
  return state
}

/**
 * 切换账号：清除本地登录态（cookie + localStorage 的 token/runtime/session），
 * 重新加载页面后由 ensureWorkbenchRuntime 跳转平台登录页。
 * 注意：仅"刷新 cookie"无法切换账号——刷新的仍是同一用户的 token，必须重新登录。
 */
export function signOutWorkbench() {
  clearWorkbenchSession()
  window.location.reload()
}

export async function readWorkbenchViewer(): Promise<WorkbenchViewer> {
  const runtime = getWorkbenchRuntimeConfig()
  const runtimeViewer = viewerFromRuntime(runtime)
  if (runtimeViewer) {
    return runtimeViewer
  }
  const me = await readHostJson<{
    user?: { id?: string; name?: string; email?: string }
    memberships?: Array<{
      teamId?: string
      userId?: string
      displayName?: string
      realName?: string
      role?: string
      avatarUrl?: string
      workEmail?: string
    }>
  }>('/api/v1/me')
  const membership = (me.memberships ?? []).find((item) => item.teamId === runtime.teamId)
  const id = cleanViewerValue(me.user?.id)
  const displayName = cleanViewerValue(membership?.displayName)
    || cleanViewerValue(membership?.realName)
    || cleanViewerValue(me.user?.name)
    || cleanViewerValue(me.user?.email)
  if (!id) {
    throw new Error('Current Workbench user id is missing')
  }
  return {
    id,
    displayName: displayName || id,
    email: cleanViewerValue(membership?.workEmail) || cleanViewerValue(me.user?.email) || undefined,
    role: cleanViewerValue(membership?.role) || undefined,
    avatarUrl: cleanViewerValue(membership?.avatarUrl) || undefined,
  }
}

export type SyngyRuntimeState = Awaited<ReturnType<typeof initializeWorkbench>>
export type SyngyRuntimeConfig = Extract<SyngyRuntimeState, { status: 'ready' }>['runtime']

export type DepartmentNode = {
  id: string
  name: string
  parentId: string
  depth: number
  path: string
  children?: DepartmentNode[]
}

/** 拉取部门树，扁平化为按层级排序的列表（depth 越小越靠前，兄弟按 name 排序） */
export async function listDepartments(): Promise<DepartmentNode[]> {
  const runtime = getWorkbenchRuntimeConfig()
  const teamId = runtime.teamId
  const payload = await readHostJson<{ items?: DepartmentNode[] } | DepartmentNode[]>(
    `/api/v1/teams/${encodeURIComponent(teamId)}/arcubase/departments/tree`,
  )
  const roots = Array.isArray(payload) ? payload : (payload.items ?? [])
  const flat: DepartmentNode[] = []
  const walk = (nodes: DepartmentNode[]) => {
    for (const node of nodes) {
      flat.push(node)
      if (node.children?.length) walk(node.children)
    }
  }
  walk(roots)
  return flat
}

export type OrganizationRole = {
  id: string
  name: string
}

/** 拉取平台业务角色（actor）列表 */
export async function listOrganizationRoles(): Promise<OrganizationRole[]> {
  const runtime = getWorkbenchRuntimeConfig()
  const teamId = runtime.teamId
  const payload = await readHostJson<{ items?: OrganizationRole[] } | OrganizationRole[]>(
    `/api/v1/teams/${encodeURIComponent(teamId)}/arcubase/organization/roles`,
  )
  return Array.isArray(payload) ? payload : (payload.items ?? [])
}

export type MemberRoleBinding = {
  arcubaseUserId: string
  actorIds: string[]
  actors: Array<{ id: string; name: string }>
}

/** 按 Host userId 查指定成员绑定的 actor 角色（members:search 不返回角色，需调本接口） */
export async function listMemberRoles(hostUserId: string): Promise<MemberRoleBinding | null> {
  const runtime = getWorkbenchRuntimeConfig()
  const teamId = runtime.teamId
  const payload = await readHostJson<{ data?: MemberRoleBinding } | MemberRoleBinding>(
    `/api/v1/teams/${encodeURIComponent(teamId)}/members/${encodeURIComponent(hostUserId)}/arcubase/organization/roles`,
  ).catch(() => null)
  if (!payload) return null
  const inner = (payload as { data?: MemberRoleBinding }).data
  return inner ?? (payload as MemberRoleBinding)
}

export type TeamMember = {
  userId: string
  arcubaseUserId: string
  displayName: string
  status: string
  departmentIds: string[]
  roleIds: string[]
}

/** 按部门 id 拉成员；不传 departmentIds 拉全量（逐个一级部门遍历） */
export async function listTeamMembersByDepartment(departmentIds: string[]): Promise<TeamMember[]> {
  const runtime = getWorkbenchRuntimeConfig()
  const teamId = runtime.teamId
  const authFetch = createWorkbenchFetch()
  const url = new URL(
    `/api/v1/teams/${encodeURIComponent(teamId)}/organization/members:search`,
    `${getWorkbenchHostApiBaseUrl(runtime)}/`,
  ).toString()
  const response = await authFetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ departmentIds }),
  })
  const payload = await response.json() as { data?: { items?: TeamMember[] } }
  if (!response.ok) {
    throw new Error(`Host request failed: ${response.status}`)
  }
  return payload.data?.items ?? []
}

/** 拉全部团队成员（遍历所有部门；同一人在多部门时 departmentIds 合并）
 * 注：members:search 返回的 departmentIds 可能不准，统一以"被搜到的部门 id"为准合并。 */
export async function listAllTeamMembers(): Promise<TeamMember[]> {
  const departments = await listDepartments()
  const byUserId = new Map<string, TeamMember>()
  for (const dept of departments) {
    try {
      const members = await listTeamMembersByDepartment([dept.id])
      for (const m of members) {
        const key = m.userId || m.arcubaseUserId
        if (!key) continue
        const existing = byUserId.get(key)
        // 以"被搜到 dept.id"为权威：无论 API 是否返回 departmentIds，都把这个部门合入
        const newDeptIds = new Set<string>([dept.id, ...(m.departmentIds ?? [])])
        if (!existing) {
          byUserId.set(key, { ...m, departmentIds: Array.from(newDeptIds) })
          continue
        }
        const merged = new Set([...(existing.departmentIds ?? []), ...Array.from(newDeptIds)])
        existing.departmentIds = Array.from(merged)
      }
    } catch {
      // 单部门失败不阻塞其他部门
    }
  }
  return Array.from(byUserId.values())
}

/** 成员 → 部门名（取首个匹配部门） */
export function memberDepartmentNames(
  member: TeamMember,
  departments: DepartmentNode[],
): string[] {
  const map = new Map(departments.map((d) => [d.id, d.name]))
  return member.departmentIds
    .map((id) => map.get(id))
    .filter((name): name is string => Boolean(name))
}

export function createSyngyClients() {
  return {
    octopus: createOctopusClient(),
    arcubase: createArcubaseClient(),
  }
}

export type SyngyClients = ReturnType<typeof createSyngyClients>

export function createWorkbenchArcubaseRuntime() {
  const runtime = getWorkbenchRuntimeConfig()
  const authFetch = createWorkbenchFetch()
  const endpoint = runtime.endpoints?.arcubase?.trim()
  if (!endpoint) {
    throw new Error('Workbench runtime endpoints.arcubase is required')
  }
  if (!endpoint.replace(/\/+$/, '').endsWith('/arcubase/api')) {
    throw new Error('Workbench runtime endpoints.arcubase must end with /arcubase/api')
  }
  const baseURL = new URL(endpoint, getWorkbenchHostApiBaseUrl(runtime)).toString().replace(/\/+$/, '')

  return {
    async request<T>(method: string, path: string, body?: unknown): Promise<T> {
      const url = new URL(path.replace(/^\/+/, ''), `${baseURL}/`).toString()
      const response = await authFetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: body === undefined ? undefined : JSON.stringify(body),
      })
      const payload = await response.json().catch(() => null) as { data?: T; error?: { message?: string; key?: string } } | T | null
      // 捕获查询响应里的 additional.users（member id → 姓名），供 memberLabel 全局显示
      captureAdditionalUsers(payload)
      const upstreamError = payload && typeof payload === 'object' && 'error' in payload ? payload.error : undefined
      if (!response.ok || upstreamError) {
        throw new Error(upstreamError?.message ?? `Arcubase request failed: ${response.status}`)
      }
      return payload && typeof payload === 'object' && 'data' in payload ? payload.data as T : payload as T
    },
  }
}

