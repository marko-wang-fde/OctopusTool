/**
 * 对话 API 客户端：调用数字员工解析简历
 *
 * 流程：创建对话 → 上传 PDF 文件 → 发送消息 → SSE 流获取响应 → 解析 JSON
 * 失败时由调用方回退到正则解析
 */

import { createWorkbenchFetch, getWorkbenchHostApiBaseUrl, getWorkbenchRuntimeConfig } from '@syngy/workbench-auth'
import { getTeamId } from './syngy'
import type { ParsedResumeFields, ParseResult } from './files'

/** 招聘专家数字员工 ID */
const DIGI_EMPLOYEE_ID = 'de_75dd727a-e56a-47b8-b4dc-1c9c75b176e1'

/** 解析简历的 prompt */
const PARSE_PROMPT = `请提取这份简历的关键信息，以JSON格式返回。字段：
- name: 姓名（中文）
- gender: 性别（男/女）
- age: 年龄（数字）
- ethnicity: 民族（如：汉族）
- currentCity: 现居地（城市名）
- education: 学历（大专/本科/硕士/博士）
- school: 毕业院校
- workYears: 工作年限（数字）
- phone: 手机号（11位数字）
- email: 邮箱
- expectedPosition: 应聘职位（期望岗位名称）
- expectedSalary: 期望薪资（原文，如 "8-10K"）
- expectedCity: 期望城市
- availableDate: 到岗时间（原文，如 "随时到岗"）
- skills: 技能列表（字符串数组）
- educationDetail: 教育背景原文段落（从简历中"教育经历/教育背景"标题开始到下一个大标题为止的完整文本）
- workExperience: 工作经历原文段落（从简历中"工作经历/工作经验/项目经历"标题开始到下一个大标题为止的完整文本）

规则：
1. 字段不存在时省略该字段，不要返回 null 或空字符串
2. educationDetail 和 workExperience 保留原文换行（用 \\n）
3. 只返回JSON，不要其他内容。`

type TempFileRef = {
  uploadId: string
  logicalPath: string
  runtimePath: string
  fileName: string
  contentType?: string
  sizeBytes: number
}

type UploadAuthorizeResp = {
  uploadId: string
  uploadUrl: string
  finalizeToken: string
  method: string
  logicalPath?: string
  runtimePath?: string
}

type UploadFinalizeResp = {
  uploadId?: string
  logicalPath?: string
  runtimePath?: string
  fileName?: string
  contentType?: string
  sizeBytes?: number
}

/** 构建 API URL */
function apiUrl(path: string): string {
  const runtime = getWorkbenchRuntimeConfig()
  const base = getWorkbenchHostApiBaseUrl(runtime)
  return new URL(path.replace(/^\/+/, ''), `${base}/`).toString()
}

/** POST JSON 请求 */
async function postJson<T>(path: string, body: unknown, extraHeaders?: Record<string, string>): Promise<T> {
  const authFetch = createWorkbenchFetch()
  const resp = await authFetch(apiUrl(path), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json', ...extraHeaders },
    body: JSON.stringify(body),
  })
  const payload = await resp.json().catch(() => ({}))
  if (!resp.ok) {
    const msg = (payload as any)?.error?.message ?? (payload as any)?.message ?? `HTTP ${resp.status}`
    throw new Error(`对话 API 失败: ${msg}`)
  }
  const data = (payload as any)?.data ?? payload
  return data as T
}

/** 创建对话，返回 conversationId */
async function createConversation(title: string): Promise<string> {
  const resp = await postJson<{ id?: string; conversationId?: string }>('/api/v1/conversations', {
    teamId: getTeamId(),
    digiEmployeeId: DIGI_EMPLOYEE_ID,
    title,
  })
  const id = resp.id ?? resp.conversationId
  if (!id) throw new Error('创建对话失败：未返回 conversation id')
  return id
}

/** 上传临时文件到对话 */
async function uploadTempFile(conversationId: string, file: File): Promise<TempFileRef> {
  // 1. 请求上传授权
  const authorized = await postJson<UploadAuthorizeResp>(
    `/api/v1/conversations/${encodeURIComponent(conversationId)}/temp-files/upload-authorize`,
    { fileName: file.name, contentType: file.type || 'application/pdf', sizeLimitBytes: file.size },
  )
  if (!authorized.uploadUrl || !authorized.finalizeToken) {
    throw new Error('上传授权失败：缺少 uploadUrl 或 finalizeToken')
  }

  // 2. PUT 文件到授权 URL（仅设 Content-Type，presign URL 自带认证）
  const putHeaders: Record<string, string> = {}
  if (file.type) putHeaders['Content-Type'] = file.type
  const putResp = await fetch(authorized.uploadUrl, {
    method: authorized.method || 'PUT',
    body: file,
    headers: putHeaders,
  })
  if (!putResp.ok) throw new Error(`文件上传失败: ${putResp.status}`)

  // 3. 确认上传
  const finalized = await postJson<UploadFinalizeResp>(
    `/api/v1/conversations/${encodeURIComponent(conversationId)}/temp-files/upload-finalize`,
    { uploadId: authorized.uploadId, finalizeToken: authorized.finalizeToken },
  )
  const uploadId = String(finalized.uploadId ?? authorized.uploadId)
  const logicalPath = String(finalized.logicalPath ?? '')
  const runtimePath = String(finalized.runtimePath ?? '')
  if (!uploadId || !logicalPath || !runtimePath) {
    throw new Error('上传确认失败：返回数据不完整')
  }
  return {
    uploadId,
    logicalPath,
    runtimePath,
    fileName: finalized.fileName ?? file.name,
    contentType: finalized.contentType ?? file.type,
    sizeBytes: finalized.sizeBytes ?? file.size,
  }
}

/** 发送用户消息（含附件） */
async function postHumanTurn(conversationId: string, content: string, tempFiles: TempFileRef[]): Promise<void> {
  const parts: unknown[] = []
  if (content.trim()) parts.push({ type: 'text', text: content.trim() })
  for (const f of tempFiles) {
    parts.push({
      type: 'file',
      fileRef: {
        uploadId: f.uploadId,
        logicalPath: f.logicalPath,
        runtimePath: f.runtimePath,
        fileName: f.fileName,
        contentType: f.contentType,
        sizeBytes: f.sizeBytes,
      },
    })
  }
  const body = tempFiles.length ? { parts, tempFiles } : { content }
  const resp = await postJson<{ accepted?: boolean }>(
    `/api/v1/conversations/${encodeURIComponent(conversationId)}/turns/human`,
    body,
    { 'Idempotency-Key': `weida-${Date.now()}-${Math.random().toString(16).slice(2)}` },
  )
  // 202 Accepted 可能无 body，resp 为 {}
  if (resp && typeof resp === 'object' && 'accepted' in resp && !resp.accepted) {
    throw new Error('发送消息失败：服务器未接受')
  }
}

/** SSE 帧解析 */
function parseSSEFrame(frame: string): { event: string; data: string } | null {
  let event = 'message'
  const dataLines: string[] = []
  for (const rawLine of frame.split(/\r?\n/)) {
    const line = rawLine.trimEnd()
    if (!line || line.startsWith(':')) continue
    if (line.startsWith('event:')) {
      event = line.slice('event:'.length).trim()
      continue
    }
    if (line.startsWith('data:')) {
      dataLines.push(line.slice('data:'.length).trimStart())
    }
  }
  if (dataLines.length === 0) return null
  return { event, data: dataLines.join('\n') }
}

/**
 * 监听 SSE 流，累积 assistant 文本，turn.completed 时返回
 * 总超时 5 分钟（数字员工处理 PDF 通常需要 1-3 分钟）
 */
async function watchConversationResponse(conversationId: string): Promise<string> {
  // 1. 获取 stream ticket
  const ticketResp = await postJson<{ streamTicket?: string }>(
    `/api/v1/conversations/${encodeURIComponent(conversationId)}/stream-ticket`,
    {},
  )
  const ticket = ticketResp.streamTicket?.trim()
  if (!ticket) throw new Error('获取 stream ticket 失败')

  // 2. SSE 流监听
  const streamUrl = `${apiUrl(`/api/v1/conversations/${encodeURIComponent(conversationId)}/stream`)}?stream_ticket=${encodeURIComponent(ticket)}`
  const authFetch = createWorkbenchFetch()
  const resp = await authFetch(streamUrl, { headers: { Accept: 'text/event-stream' } })
  if (!resp.ok || !resp.body) throw new Error(`SSE 流连接失败: ${resp.status}`)

  const reader = resp.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''
  let assistantText = ''
  let done = false
  const startTime = Date.now()
  const TIMEOUT_MS = 300_000

  try {
    for (;;) {
      if (Date.now() - startTime > TIMEOUT_MS) throw new Error('数字员工响应超时（5分钟）')
      const { value, done: streamDone } = await reader.read()
      if (streamDone) break
      buffer += decoder.decode(value, { stream: true })
      // 按空行分帧
      let boundary = buffer.search(/\r?\n\r?\n/)
      while (boundary >= 0) {
        const frame = buffer.slice(0, boundary)
        const separator = buffer.slice(boundary).match(/^\r?\n\r?\n/)?.[0] ?? '\n\n'
        buffer = buffer.slice(boundary + separator.length)
        const parsed = parseSSEFrame(frame)
        if (parsed) {
          // 调试：打印 SSE 事件
          console.log('[SSE]', parsed.event, parsed.data.slice(0, 200))
          // 尝试解析 data 为 JSON
          let dataObj: any = parsed.data
          try { dataObj = JSON.parse(parsed.data) } catch { /* 纯文本 */ }
          // 累积 assistant 文本
          if (typeof dataObj === 'string' && dataObj.trim()) {
            assistantText += dataObj
          } else if (dataObj && typeof dataObj === 'object') {
            // 常见字段：text / content / delta / message
            const text = dataObj.text ?? dataObj.content ?? dataObj.delta ?? dataObj.message ?? ''
            if (text) assistantText += String(text)
          }
          // 完成事件：data 中可能包含完整回复
          if (parsed.event === 'turn.completed') {
            // 如果 turn.completed 的 data 中有完整文本且累积文本为空，用 data 中的
            if (!assistantText.trim() && dataObj && typeof dataObj === 'object') {
              const fullText = dataObj.text ?? dataObj.content ?? dataObj.message ?? dataObj.result ?? ''
              if (fullText) assistantText = String(fullText)
            }
            done = true
            break
          }
          if (parsed.event === 'turn.error') throw new Error(`数字员工处理失败: ${parsed.data}`)
        }
        boundary = buffer.search(/\r?\n\r?\n/)
      }
      if (done) break
    }
  } finally {
    if (!done) await reader.cancel().catch(() => undefined)
    reader.releaseLock()
  }

  if (!assistantText.trim()) throw new Error('数字员工未返回文本')
  return assistantText.trim()
}

/** 从 assistant 文本中提取 JSON */
function extractJsonFromText(text: string): any {
  // 尝试直接解析
  try { return JSON.parse(text) } catch { /* continue */ }
  // 尝试提取 ```json ... ``` 中的内容
  const codeBlock = text.match(/```(?:json)?\s*([\s\S]*?)```/)
  if (codeBlock) {
    try { return JSON.parse(codeBlock[1].trim()) } catch { /* continue */ }
  }
  // 尝试提取第一个 { ... } 块
  const jsonMatch = text.match(/\{[\s\S]*\}/)
  if (jsonMatch) {
    try { return JSON.parse(jsonMatch[0]) } catch { /* continue */ }
  }
  return null
}

/**
 * 调用数字员工解析简历文件
 * 返回提取的文本和结构化字段
 */
export async function parseResumeWithDigiEmployee(file: File): Promise<ParseResult> {
  // 1. 创建对话
  const conversationId = await createConversation(`简历解析-${file.name}`)

  // 2. 上传 PDF 文件
  const tempFile = await uploadTempFile(conversationId, file)

  // 3. 发送消息，让 LLM 提取字段
  await postHumanTurn(conversationId, PARSE_PROMPT, [tempFile])

  // 4. 监听 SSE 流，获取 assistant 响应
  const responseText = await watchConversationResponse(conversationId)

  // 5. 解析 JSON
  const parsed = extractJsonFromText(responseText)
  if (!parsed) throw new Error('数字员工返回非 JSON 格式')

  // 6. 构造 ParsedResumeFields
  const fields: ParsedResumeFields = {
    name: parsed.name ? String(parsed.name) : undefined,
    phone: parsed.phone ? String(parsed.phone) : undefined,
    email: parsed.email ? String(parsed.email) : undefined,
    gender: parsed.gender ? String(parsed.gender) : undefined,
    age: parsed.age ? Number(parsed.age) : undefined,
    education: parsed.education ? String(parsed.education) : undefined,
    school: parsed.school ? String(parsed.school) : undefined,
    workYears: parsed.workYears ? Number(parsed.workYears) : undefined,
    skills: Array.isArray(parsed.skills) ? parsed.skills.join('、') : (parsed.skills ? String(parsed.skills) : undefined),
    expectedSalary: parsed.expectedSalary ? String(parsed.expectedSalary) : undefined,
    ethnicity: parsed.ethnicity ? String(parsed.ethnicity) : undefined,
    currentCity: parsed.currentCity ? String(parsed.currentCity) : undefined,
    expectedPosition: parsed.expectedPosition ? String(parsed.expectedPosition) : undefined,
    expectedCity: parsed.expectedCity ? String(parsed.expectedCity) : undefined,
    educationDetail: parsed.educationDetail ? String(parsed.educationDetail) : undefined,
    workExperience: parsed.workExperience ? String(parsed.workExperience) : undefined,
  }

  // 7. 构造用于匹配的文本（包含姓名、技能、学校、学历等关键词）
  const text = [fields.name, fields.skills, fields.school, fields.education, fields.workYears ? `${fields.workYears}年工作经验` : '']
    .filter(Boolean).join(' ')

  return { text, fields }
}
