/**
 * 成员姓名注册表（member id → 显示名）。
 * 两个来源：
 * 1. Arcubase 查询响应里的 additional.users（自动捕获，覆盖所有行内 member 字段）
 * 2. listAllTeamMembers 结果（App 启动时注册）
 */
const memberNameMap = new Map<string, string>()

export function registerMemberName(id: unknown, name: unknown) {
  const key = String(id ?? '').trim()
  const value = String(name ?? '').trim()
  if (key && value && key !== '0') memberNameMap.set(key, value)
}

export function registerMemberNames(entries: Array<{ arcubaseUserId?: string; userId?: string; displayName?: string }>) {
  for (const e of entries) {
    registerMemberName(e.arcubaseUserId, e.displayName)
    registerMemberName(e.userId, e.displayName)
  }
}

/** 从 Arcubase 查询/详情响应的 additional.users 捕获姓名（不动返回体）。 */
export function captureAdditionalUsers(payload: unknown) {
  if (!payload || typeof payload !== 'object') return
  const p = payload as Record<string, any>
  const users = p?.data?.additional?.users ?? p?.additional?.users
  if (!users || typeof users !== 'object') return
  for (const [id, u] of Object.entries(users)) {
    const name = (u as Record<string, any>)?.name ?? (u as Record<string, any>)?.displayName
    registerMemberName(id, name)
  }
}

export function lookupMemberName(id: unknown): string | null {
  return memberNameMap.get(String(id)) ?? null
}
