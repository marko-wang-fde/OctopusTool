import { createArcubaseClientFromRuntime, type ArcubaseIngressMap } from '../arcubase/client'
import type { ArcubaseRow } from '../arcubase/runtime'
import { createWorkbenchArcubaseRuntime } from './syngy'
import { lookupMemberName, registerMemberNames } from './memberNames'

export { registerMemberNames }

/**
 * 业务表 → codegen ingress key 映射。
 * codegen 生成的 ingress 命名为同名规则编号，前端统一经此文件按业务名引用。
 */
export const TABLE_INGRESS = {
  demands: 'devOperatorFullAccess2', // T1 用人需求单 2191603449
  jobs: 'devOperatorFullAccess3', // T2 岗位 2191603450
  resumes: 'devOperatorFullAccess4', // T3 简历 2191603451
  pipelines: 'devOperatorFullAccess5', // T4 招聘流程实例 2191603452
  matches: 'devOperatorFullAccess6', // T5 匹配结果 2191603453
  recommendations: 'devOperatorFullAccess7', // T6 推荐记录 2191603454
  interviews: 'devOperatorFullAccess8', // T7 面试预约 2191603455
  feedbacks: 'devOperatorFullAccess9', // T8 面试反馈 2191603456
  interviewRecords: 'devOperatorFullAccess10', // T9 面试文字记录 2191603457
  bgMaterials: 'devOperatorFullAccess11', // T10 背调材料 2191603458
  salaries: 'devOperatorFullAccess12', // T11 拟薪 2191603459
  offers: 'devOperatorFullAccess13', // T12 Offer 记录 2191603460
  onboardChecks: 'devOperatorFullAccess14', // T13 到岗核验 2191603461
  reminders: 'devOperatorFullAccess15', // T14 提醒任务 2191603462
  configs: 'devOperatorFullAccess', // T15 系统配置 2191603463
  resumeMaterials: 'devOperatorFullAccess16', // T16 简历材料 2191605785
} as const

export type TableKey = keyof typeof TABLE_INGRESS
export type IngressOf<K extends TableKey> = ArcubaseIngressMap[(typeof TABLE_INGRESS)[K]]

export function db() {
  return createArcubaseClientFromRuntime(createWorkbenchArcubaseRuntime())
}

export function table<K extends TableKey>(key: K): IngressOf<K> {
  return db().ingress(TABLE_INGRESS[key]) as IngressOf<K>
}

type Queryable = {
  query(params?: {
    limit?: number
    offset?: number
    search?: Record<string, any>
    sorts?: Array<{ column: string; order: 'asc' | 'desc' }>
  }): Promise<{ items: Array<ArcubaseRow<any>>; total?: number }>
}

/** 拉取全部行（分页 200 循环）。search 透传 Arcubase 条件（key 用业务字段 key）。 */
export async function queryAll<I extends Queryable>(
  ingress: I,
  search?: Record<string, any>,
): Promise<Awaited<ReturnType<I['query']>>['items']> {
  const all: Array<ArcubaseRow<any>> = []
  const limit = 200
  let offset = 0
  for (;;) {
    const res = await ingress.query({ limit, offset, ...(search ? { search } : {}) })
    all.push(...res.items)
    if (res.items.length < limit) break
    offset += limit
  }
  return all as Awaited<ReturnType<I['query']>>['items']
}

/* ---------------- datetime 红线：一律 epoch 秒写入 ---------------- */

/** 任意输入转 epoch 秒（number 输入自动区分秒/毫秒）。 */
export function toEpochSeconds(value: string | Date | number): number {
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new Error('Invalid datetime value')
    // 大于 1e12 视为毫秒
    return Math.floor(value > 1e12 ? value / 1000 : value)
  }
  const ms = value instanceof Date ? value.getTime() : Date.parse(value)
  if (!Number.isFinite(ms)) throw new Error('Invalid datetime value')
  return Math.floor(ms / 1000)
}

/** codegen 将 datetime 标成 string；写入时用该助手把 epoch 秒安全透传。 */
export function dt(epochSeconds: number): string {
  return epochSeconds as unknown as string
}

/** 读取 datetime 值（兼容 epoch 秒/毫秒/ISO 字符串），返回 epoch 秒或 null。 */
export function readEpoch(value: unknown): number | null {
  if (value === null || value === undefined || value === '') return null
  if (typeof value === 'number' && Number.isFinite(value)) {
    return Math.floor(value > 1e12 ? value / 1000 : value)
  }
  if (typeof value === 'string') {
    const asNum = Number(value)
    if (Number.isFinite(asNum) && value.trim() !== '') {
      return Math.floor(asNum > 1e12 ? asNum / 1000 : asNum)
    }
    const ms = Date.parse(value)
    return Number.isFinite(ms) ? Math.floor(ms / 1000) : null
  }
  return null
}

export function fmtDate(value: unknown): string {
  const epoch = readEpoch(value)
  if (epoch === null) return '—'
  const d = new Date(epoch * 1000)
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

export function fmtDateTime(value: unknown): string {
  const epoch = readEpoch(value)
  if (epoch === null) return '—'
  const d = new Date(epoch * 1000)
  return `${fmtDate(epoch)} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

/* ---------------- 成员姓名显示 ---------------- */

/** member 字段显示：兼容 id 字符串/数字、对象，以及 0 值。优先查姓名注册表（memberNames）。 */
export function memberLabel(value: unknown): string {
  if (value === null || value === undefined || value === '' || value === 0) return '—'
  if (typeof value === 'string' || typeof value === 'number') {
    return lookupMemberName(value) ?? String(value)
  }
  if (typeof value === 'object') {
    const v = value as Record<string, any>
    const direct = String(v.name ?? v.displayName ?? v.realName ?? '').trim()
    if (direct) return direct
    if (v.id !== undefined) return lookupMemberName(v.id) ?? String(v.id)
    return '—'
  }
  return '—'
}

/** select 字段显示（读回可能是文本、选项 id 或对象）。 */
export function selectLabel(value: unknown): string {
  if (value === null || value === undefined || value === '') return '—'
  if (typeof value === 'object') {
    const v = value as Record<string, any>
    return String(v.label ?? v.name ?? v.value ?? '—')
  }
  return String(value)
}
