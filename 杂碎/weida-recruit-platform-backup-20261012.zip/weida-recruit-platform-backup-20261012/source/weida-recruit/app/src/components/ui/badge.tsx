import * as React from 'react'
import { cn } from '../../lib/utils'

type Tone = 'default' | 'green' | 'red' | 'amber' | 'blue' | 'slate' | 'outline'

const toneClass: Record<Tone, string> = {
  default: 'bg-slate-950 text-white',
  green: 'bg-emerald-100 text-emerald-700',
  red: 'bg-red-100 text-red-700',
  amber: 'bg-amber-100 text-amber-700',
  blue: 'bg-blue-100 text-blue-700',
  slate: 'bg-slate-100 text-slate-600',
  outline: 'border border-slate-300 text-slate-600',
}

export function Badge({ className, tone = 'default', ...props }: React.HTMLAttributes<HTMLSpanElement> & { tone?: Tone }) {
  return (
    <span
      className={cn('inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium', toneClass[tone], className)}
      {...props}
    />
  )
}
