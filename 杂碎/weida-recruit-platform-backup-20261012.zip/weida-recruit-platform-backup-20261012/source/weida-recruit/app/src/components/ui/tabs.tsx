import * as React from 'react'
import { cn } from '../../lib/utils'

/** 受控 Tabs：value + onValueChange */
export function Tabs({
  value,
  onValueChange,
  items,
  className,
}: {
  value: string
  onValueChange: (v: string) => void
  items: Array<{ value: string; label: React.ReactNode }>
  className?: string
}) {
  return (
    <div className={cn('flex flex-wrap items-center gap-1 rounded-md bg-slate-100 p-1', className)}>
      {items.map((item) => {
        const active = item.value === value
        return (
          <button
            key={item.value}
            type="button"
            onClick={() => onValueChange(item.value)}
            className={cn(
              'rounded px-3 py-1.5 text-sm font-medium transition-colors',
              active ? 'bg-white text-slate-950 shadow-sm' : 'text-slate-500 hover:text-slate-900',
            )}
          >
            {item.label}
          </button>
        )
      })}
    </div>
  )
}
