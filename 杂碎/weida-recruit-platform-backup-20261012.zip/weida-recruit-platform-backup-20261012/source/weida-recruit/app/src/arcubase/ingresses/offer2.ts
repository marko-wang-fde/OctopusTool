import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Offer2FieldKey = 'pipelineId' | 'status' | 'markedBy' | 'markedAt'

export type Offer2Fields = {
  pipelineId: string
  status: number | string
  markedBy?: unknown
  markedAt?: string
}

export type Offer2CreateInput = Offer2Fields
export type Offer2UpdateInput = Partial<Offer2Fields>
export type Offer2Action = 'view' | 'add' | 'edit'
export type Offer2CustomAction = never

export type Offer2Sort = {
  column: Offer2FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Offer2QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Offer2Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Offer2Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Offer2Sort[]
}

export type Offer2BulkUpdateField = {
  key: Offer2FieldKey
  action: Record<string, any>
}

export type Offer2ExportOptions = {
  fields?: Offer2FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "n095RyzN8Og3yNA"
const fieldIds = {
  pipelineId: 1001,
  status: 1002,
  markedBy: 1003,
  markedAt: 1004,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Offer2Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Offer2Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Offer2Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createOffer2Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Offer2QueryParams = {}): Promise<{ items: ArcubaseRow<Offer2Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603460/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Offer2Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603460/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603460/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: Offer2CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603460/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: Offer2UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603460/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },
  }
}
