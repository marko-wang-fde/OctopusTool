import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604544FieldKey = 'resumeId' | 'demandId' | 'currentStage' | 'stageTs' | 'startedAt'

export type Ingress2191604544Fields = {
  resumeId: string
  demandId: string
  currentStage: number | string
  stageTs?: string
  startedAt: string
}

export type Ingress2191604544CreateInput = Ingress2191604544Fields
export type Ingress2191604544UpdateInput = Partial<Ingress2191604544Fields>
export type Ingress2191604544Action = 'view'
export type Ingress2191604544CustomAction = never

export type Ingress2191604544Sort = {
  column: Ingress2191604544FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604544QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604544Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604544Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604544Sort[]
}

export type Ingress2191604544BulkUpdateField = {
  key: Ingress2191604544FieldKey
  action: Record<string, any>
}

export type Ingress2191604544ExportOptions = {
  fields?: Ingress2191604544FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "mAg57j2WZe73jnx"
const fieldIds = {
  resumeId: 1001,
  demandId: 1002,
  currentStage: 1003,
  stageTs: 1004,
  startedAt: 1005,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604544Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604544Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604544Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604544Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604544QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604544Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603452/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604544Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603452/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },
  }
}
