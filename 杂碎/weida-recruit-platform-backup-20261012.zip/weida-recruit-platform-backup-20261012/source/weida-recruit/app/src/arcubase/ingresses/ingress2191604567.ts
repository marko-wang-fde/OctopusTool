import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604567FieldKey = 'pipelineId' | 'mtype' | 'attachment' | 'uploadedBy' | 'uploadedAt'

export type Ingress2191604567Fields = {
  pipelineId: string
  mtype?: number | string
  attachment: unknown
  uploadedBy?: unknown
  uploadedAt?: string
}

export type Ingress2191604567CreateInput = Ingress2191604567Fields
export type Ingress2191604567UpdateInput = Partial<Ingress2191604567Fields>
export type Ingress2191604567Action = 'view' | 'add' | 'edit' | 'delete'
export type Ingress2191604567CustomAction = never

export type Ingress2191604567Sort = {
  column: Ingress2191604567FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604567QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604567Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604567Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604567Sort[]
}

export type Ingress2191604567BulkUpdateField = {
  key: Ingress2191604567FieldKey
  action: Record<string, any>
}

export type Ingress2191604567ExportOptions = {
  fields?: Ingress2191604567FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "Yog3G2bE4VEQZO1"
const fieldIds = {
  pipelineId: 1001,
  mtype: 1002,
  attachment: 1003,
  uploadedBy: 1004,
  uploadedAt: 1005,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604567Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604567Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604567Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604567Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604567QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604567Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603458/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604567Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603458/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603458/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: Ingress2191604567CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603458/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: Ingress2191604567UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603458/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },

    async delete(selection: Ingress2191604567Selection): Promise<{ deleted?: number } | boolean> {
      return runtime.request<{ deleted?: number } | boolean>('POST', `/entity/2191603448/2191603458/delete-item`, {
        policy_id: ingressId,
        selection: toArcubaseSelection(selection),
      })
    },
  }
}
