import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604537FieldKey = 'name' | 'department' | 'jd' | 'owner' | 'status' | 'grade' | 'headcount' | 'educationRequirement' | 'experienceRequirement' | 'remark' | 'ageMin' | 'ageMax' | 'salaryMin' | 'salaryMax' | 'skillItems' | 'skillName'

export type Ingress2191604537Fields = {
  name: string
  department?: string
  jd?: string
  owner?: unknown
  status: number | string
  grade?: string
  headcount?: string
  educationRequirement?: string
  experienceRequirement?: string
  remark?: string
  ageMin?: string
  ageMax?: string
  salaryMin?: string
  salaryMax?: string
  skillItems?: unknown
  skillName?: string
}

export type Ingress2191604537CreateInput = Ingress2191604537Fields
export type Ingress2191604537UpdateInput = Partial<Ingress2191604537Fields>
export type Ingress2191604537Action = 'view'
export type Ingress2191604537CustomAction = never

export type Ingress2191604537Sort = {
  column: Ingress2191604537FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604537QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604537Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604537Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604537Sort[]
}

export type Ingress2191604537BulkUpdateField = {
  key: Ingress2191604537FieldKey
  action: Record<string, any>
}

export type Ingress2191604537ExportOptions = {
  fields?: Ingress2191604537FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "ExKQ8b9a28g5Dkj"
const fieldIds = {
  name: 1001,
  department: 1002,
  jd: 1003,
  owner: 1006,
  status: 1007,
  grade: 1008,
  headcount: 1009,
  educationRequirement: 1011,
  experienceRequirement: 1013,
  remark: 1015,
  ageMin: 1016,
  ageMax: 1017,
  salaryMin: 1018,
  salaryMax: 1019,
  skillItems: 1020,
  skillName: 1021,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604537Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604537Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604537Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604537Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604537QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604537Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603450/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604537Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603450/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },
  }
}
