export const arcubaseSchema = {
  "ingresses": {
    "ingress2191605786": {
      "appId": 2191603448,
      "ingressId": "naE5Mljgp7J3J0Y",
      "entityId": 2191605785,
      "name": "人事专员-简历材料",
      "actions": [
        "view",
        "add",
        "edit"
      ],
      "fields": {
        "fileName": {
          "fieldId": 1001,
          "label": "原文件名",
          "type": "text",
          "required": true
        },
        "logicalPath": {
          "fieldId": 1002,
          "label": "知识库路径",
          "type": "text",
          "required": true
        },
        "sizeBytes": {
          "fieldId": 1003,
          "label": "文件大小(字节)",
          "type": "number",
          "required": false
        },
        "sha256": {
          "fieldId": 1004,
          "label": "SHA-256指纹",
          "type": "text",
          "required": false
        },
        "batchId": {
          "fieldId": 1005,
          "label": "批次号",
          "type": "text",
          "required": false
        },
        "contentType": {
          "fieldId": 1006,
          "label": "MIME类型",
          "type": "text",
          "required": false
        },
        "status": {
          "fieldId": 1007,
          "label": "处理状态",
          "type": "select",
          "required": false
        },
        "parseError": {
          "fieldId": 1008,
          "label": "解析失败原因",
          "type": "textarea",
          "required": false
        },
        "resumeId": {
          "fieldId": 1009,
          "label": "关联简历ID",
          "type": "text",
          "required": false
        },
        "uploadedBy": {
          "fieldId": 1010,
          "label": "上传人",
          "type": "member",
          "required": false
        },
        "uploadedAt": {
          "fieldId": 1011,
          "label": "上传时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191605787": {
      "appId": 2191603448,
      "ingressId": "BrW6qMWNRzw6ZMm",
      "entityId": 2191605785,
      "name": "人事经理-简历材料",
      "actions": [
        "view",
        "add",
        "edit"
      ],
      "fields": {
        "fileName": {
          "fieldId": 1001,
          "label": "原文件名",
          "type": "text",
          "required": true
        },
        "logicalPath": {
          "fieldId": 1002,
          "label": "知识库路径",
          "type": "text",
          "required": true
        },
        "sizeBytes": {
          "fieldId": 1003,
          "label": "文件大小(字节)",
          "type": "number",
          "required": false
        },
        "sha256": {
          "fieldId": 1004,
          "label": "SHA-256指纹",
          "type": "text",
          "required": false
        },
        "batchId": {
          "fieldId": 1005,
          "label": "批次号",
          "type": "text",
          "required": false
        },
        "contentType": {
          "fieldId": 1006,
          "label": "MIME类型",
          "type": "text",
          "required": false
        },
        "status": {
          "fieldId": 1007,
          "label": "处理状态",
          "type": "select",
          "required": false
        },
        "parseError": {
          "fieldId": 1008,
          "label": "解析失败原因",
          "type": "textarea",
          "required": false
        },
        "resumeId": {
          "fieldId": 1009,
          "label": "关联简历ID",
          "type": "text",
          "required": false
        },
        "uploadedBy": {
          "fieldId": 1010,
          "label": "上传人",
          "type": "member",
          "required": false
        },
        "uploadedAt": {
          "fieldId": 1011,
          "label": "上传时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191605788": {
      "appId": 2191603448,
      "ingressId": "mAg57j2WZNd3jnx",
      "entityId": 2191605785,
      "name": "部门领导-简历材料",
      "actions": [
        "view"
      ],
      "fields": {
        "fileName": {
          "fieldId": 1001,
          "label": "原文件名",
          "type": "text",
          "required": true
        },
        "logicalPath": {
          "fieldId": 1002,
          "label": "知识库路径",
          "type": "text",
          "required": true
        },
        "sizeBytes": {
          "fieldId": 1003,
          "label": "文件大小(字节)",
          "type": "number",
          "required": false
        },
        "sha256": {
          "fieldId": 1004,
          "label": "SHA-256指纹",
          "type": "text",
          "required": false
        },
        "batchId": {
          "fieldId": 1005,
          "label": "批次号",
          "type": "text",
          "required": false
        },
        "contentType": {
          "fieldId": 1006,
          "label": "MIME类型",
          "type": "text",
          "required": false
        },
        "status": {
          "fieldId": 1007,
          "label": "处理状态",
          "type": "select",
          "required": false
          "required": true
        },
        "sizeBytes": {
          "fieldId": 1003,
          "label": "文件大小(字节)",
          "type": "number",
          "required": false
        },
        "sha256": {
          "fieldId": 1004,
          "label": "SHA-256指纹",
          "type": "text",
          "required": false
        },
        "batchId": {
          "fieldId": 1005,
          "label": "批次号",
          "type": "text",
          "required": false
        },
        "contentType": {
          "fieldId": 1006,
          "label": "MIME类型",
          "type": "text",
          "required": false
        },
        "status": {
          "fieldId": 1007,
          "label": "处理状态",
          "type": "select",
          "required": false
        },
        "parseError": {
          "fieldId": 1008,
          "label": "解析失败原因",
          "type": "textarea",
          "required": false
        },
        "resumeId": {
          "fieldId": 1009,
          "label": "关联简历ID",
          "type": "text",
          "required": false
        },
        "uploadedBy": {
          "fieldId": 1010,
          "label": "上传人",
          "type": "member",
          "required": false
        },
        "uploadedAt": {
          "fieldId": 1011,
          "label": "上传时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "devOperatorFullAccess16": {
      "appId": 2191603448,
      "ingressId": "eDO6zOXbJ2pQMdx",
      "entityId": 2191605785,
      "name": "Dev operator full access",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "fileName": {
          "fieldId": 1001,
          "label": "原文件名",
          "type": "text",
          "required": true
        },
        "logicalPath": {
          "fieldId": 1002,
          "label": "知识库路径",
          "type": "text",
          "required": true
        },
        "sizeBytes": {
          "fieldId": 1003,
          "label": "文件大小(字节)",
          "type": "number",
          "required": false
        },
        "sha256": {
          "fieldId": 1004,
          "label": "SHA-256指纹",
          "type": "text",
          "required": false
        },
        "batchId": {
          "fieldId": 1005,
          "label": "批次号",
          "type": "text",
          "required": false
        },
        "contentType": {
          "fieldId": 1006,
          "label": "MIME类型",
          "type": "text",
          "required": false
        },
        "status": {
          "fieldId": 1007,
          "label": "处理状态",
          "type": "select",
          "required": false
        },
        "parseError": {
          "fieldId": 1008,
          "label": "解析失败原因",
          "type": "textarea",
          "required": false
        },
        "resumeId": {
          "fieldId": 1009,
          "label": "关联简历ID",
          "type": "text",
          "required": false
        },
        "uploadedBy": {
          "fieldId": 1010,
          "label": "上传人",
          "type": "member",
          "required": false
        },
        "uploadedAt": {
          "fieldId": 1011,
          "label": "上传时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "devOperatorFullAccess": {
      "appId": 2191603448,
      "ingressId": "mRj3vBoaP89398w",
      "entityId": 2191603463,
      "name": "Dev operator full access",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "ckey": {
          "fieldId": 1001,
          "label": "配置键",
          "type": "text",
          "required": true
        },
        "cvalue": {
          "fieldId": 1002,
          "label": "配置值",
          "type": "text",
          "required": false
        },
        "description": {
          "fieldId": 1003,
          "label": "说明",
          "type": "text",
          "required": false
        }
      }
    },
    "ingress2191604582": {
      "appId": 2191603448,
      "ingressId": "Rmn6JEblRP95AMY",
      "entityId": 2191603463,
      "name": "人事专员",
      "actions": [
        "view",
        "edit"
      ],
      "fields": {
        "ckey": {
          "fieldId": 1001,
          "label": "配置键",
          "type": "text",
          "required": true
        },
        "cvalue": {
          "fieldId": 1002,
          "label": "配置值",
          "type": "text",
          "required": false
        },
        "description": {
          "fieldId": 1003,
          "label": "说明",
          "type": "text",
          "required": false
        }
      }
    },
    "ingress2191604583": {
      "appId": 2191603448,
      "ingressId": "Rol6YoyXAl43ynV",
      "entityId": 2191603463,
      "name": "人事经理",
      "actions": [
        "view"
      ],
      "fields": {
        "ckey": {
          "fieldId": 1001,
          "label": "配置键",
          "type": "text",
          "required": true
        },
        "cvalue": {
          "fieldId": 1002,
          "label": "配置值",
          "type": "text",
          "required": false
        },
        "description": {
          "fieldId": 1003,
          "label": "说明",
          "type": "text",
          "required": false
        }
      }
    },
    "ingress2191604584": {
      "appId": 2191603448,
      "ingressId": "GXw6xRBXDKb39B0",
      "entityId": 2191603463,
      "name": "招聘助手",
      "actions": [
        "view"
      ],
      "fields": {
        "ckey": {
          "fieldId": 1001,
          "label": "配置键",
          "type": "text",
          "required": true
        },
        "cvalue": {
          "fieldId": 1002,
          "label": "配置值",
          "type": "text",
          "required": false
        },
        "description": {
          "fieldId": 1003,
          "label": "说明",
          "type": "text",
          "required": false
        }
      }
    },
    "devOperatorFullAccess15": {
      "appId": 2191603448,
      "ingressId": "pxD5mbMr4jW6XOJ",
      "entityId": 2191603462,
      "name": "Dev operator full access",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "type": {
          "fieldId": 1001,
          "label": "类型",
          "type": "select",
          "required": true
        },
        "refType": {
          "fieldId": 1002,
          "label": "关联类型",
          "type": "select",
          "required": false
        },
        "refId": {
          "fieldId": 1003,
          "label": "关联id",
          "type": "text",
          "required": false
        },
        "target": {
          "fieldId": 1004,
          "label": "目标人",
          "type": "member",
          "required": false
        },
        "channel": {
          "fieldId": 1005,
          "label": "通道",
          "type": "select",
          "required": false
        },
        "plannedAt": {
          "fieldId": 1006,
          "label": "计划时间",
          "type": "datetime",
          "required": false
        },
        "status": {
          "fieldId": 1007,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "resendCount": {
          "fieldId": 1008,
          "label": "重发计数",
          "type": "number",
          "required": false
        }
      }
    },
    "ingress2191604579": {
      "appId": 2191603448,
      "ingressId": "Lol5Pg7ZPan34ZV",
      "entityId": 2191603462,
      "name": "人事专员",
      "actions": [
        "view",
        "edit"
      ],
      "fields": {
        "type": {
          "fieldId": 1001,
          "label": "类型",
          "type": "select",
          "required": true
        },
        "refType": {
          "fieldId": 1002,
          "label": "关联类型",
          "type": "select",
          "required": false
        },
        "refId": {
          "fieldId": 1003,
          "label": "关联id",
          "type": "text",
          "required": false
        },
        "target": {
          "fieldId": 1004,
          "label": "目标人",
          "type": "member",
          "required": false
        },
        "channel": {
          "fieldId": 1005,
          "label": "通道",
          "type": "select",
          "required": false
        },
        "plannedAt": {
          "fieldId": 1006,
          "label": "计划时间",
          "type": "datetime",
          "required": false
        },
        "status": {
          "fieldId": 1007,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "resendCount": {
          "fieldId": 1008,
          "label": "重发计数",
          "type": "number",
          "required": false
        }
      }
    },
    "ingress2191604580": {
      "appId": 2191603448,
      "ingressId": "1A76DrbRG8K34N0",
      "entityId": 2191603462,
      "name": "人事经理",
      "actions": [
        "view"
      ],
      "fields": {
        "type": {
          "fieldId": 1001,
          "label": "类型",
          "type": "select",
          "required": true
        },
        "refType": {
          "fieldId": 1002,
          "label": "关联类型",
          "type": "select",
          "required": false
        },
        "refId": {
          "fieldId": 1003,
          "label": "关联id",
          "type": "text",
          "required": false
        },
        "target": {
          "fieldId": 1004,
          "label": "目标人",
          "type": "member",
          "required": false
        },
        "channel": {
          "fieldId": 1005,
          "label": "通道",
          "type": "select",
          "required": false
        },
        "plannedAt": {
          "fieldId": 1006,
          "label": "计划时间",
          "type": "datetime",
          "required": false
        },
        "status": {
          "fieldId": 1007,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "resendCount": {
          "fieldId": 1008,
          "label": "重发计数",
          "type": "number",
          "required": false
        }
      }
    },
    "ingress2191604581": {
      "appId": 2191603448,
      "ingressId": "ExKQ8b9a2Jg5Dkj",
      "entityId": 2191603462,
      "name": "招聘助手",
      "actions": [
        "view",
        "add"
      ],
      "fields": {
        "type": {
          "fieldId": 1001,
          "label": "类型",
          "type": "select",
          "required": true
        },
        "refType": {
          "fieldId": 1002,
          "label": "关联类型",
          "type": "select",
          "required": false
        },
        "refId": {
          "fieldId": 1003,
          "label": "关联id",
          "type": "text",
          "required": false
        },
        "target": {
          "fieldId": 1004,
          "label": "目标人",
          "type": "member",
          "required": false
        },
        "channel": {
          "fieldId": 1005,
          "label": "通道",
          "type": "select",
          "required": false
        },
        "plannedAt": {
          "fieldId": 1006,
          "label": "计划时间",
          "type": "datetime",
          "required": false
        },
        "status": {
          "fieldId": 1007,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "resendCount": {
          "fieldId": 1008,
          "label": "重发计数",
          "type": "number",
          "required": false
        }
      }
    },
    "devOperatorFullAccess14": {
      "appId": 2191603448,
      "ingressId": "9ZN5Bw9OYlE6jwK",
      "entityId": 2191603461,
      "name": "Dev operator full access",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "result": {
          "fieldId": 1002,
          "label": "结果",
          "type": "select",
          "required": true
        },
        "checkedBy": {
          "fieldId": 1003,
          "label": "核验人",
          "type": "member",
          "required": false
        },
        "checkedAt": {
          "fieldId": 1004,
          "label": "核验时间",
          "type": "datetime",
          "required": false
        },
        "remark": {
          "fieldId": 1005,
          "label": "备注",
          "type": "textarea",
          "required": false
        }
      }
    },
    "ingress2191604575": {
      "appId": 2191603448,
      "ingressId": "NqwQnp8y4L45X0o",
      "entityId": 2191603461,
      "name": "人事专员",
      "actions": [
        "view",
        "add",
        "edit"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "result": {
          "fieldId": 1002,
          "label": "结果",
          "type": "select",
          "required": true
        },
        "checkedBy": {
          "fieldId": 1003,
          "label": "核验人",
          "type": "member",
          "required": false
        },
        "checkedAt": {
          "fieldId": 1004,
          "label": "核验时间",
          "type": "datetime",
          "required": false
        },
        "remark": {
          "fieldId": 1005,
          "label": "备注",
          "type": "textarea",
          "required": false
        }
      }
    },
    "ingress2191604576": {
      "appId": 2191603448,
      "ingressId": "1EJ6p9W2Kp7QYVD",
      "entityId": 2191603461,
      "name": "人事经理",
      "actions": [
        "view"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "result": {
          "fieldId": 1002,
          "label": "结果",
          "type": "select",
          "required": true
        },
        "checkedBy": {
          "fieldId": 1003,
          "label": "核验人",
          "type": "member",
          "required": false
        },
        "checkedAt": {
          "fieldId": 1004,
          "label": "核验时间",
          "type": "datetime",
          "required": false
        },
        "remark": {
          "fieldId": 1005,
          "label": "备注",
          "type": "textarea",
          "required": false
        }
      }
    },
    "offer3": {
      "appId": 2191603448,
      "ingressId": "9ZN5Bw9ObnE6jwK",
      "entityId": 2191603461,
      "name": "offer专员",
      "actions": [
        "view"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "result": {
          "fieldId": 1002,
          "label": "结果",
          "type": "select",
          "required": true
        },
        "checkedBy": {
          "fieldId": 1003,
          "label": "核验人",
          "type": "member",
          "required": false
        },
        "checkedAt": {
          "fieldId": 1004,
          "label": "核验时间",
          "type": "datetime",
          "required": false
        },
        "remark": {
          "fieldId": 1005,
          "label": "备注",
          "type": "textarea",
          "required": false
        }
      }
    },
    "ingress2191604578": {
      "appId": 2191603448,
      "ingressId": "pxD5mbMreJW6XOJ",
      "entityId": 2191603461,
      "name": "招聘助手",
      "actions": [
        "view"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "result": {
          "fieldId": 1002,
          "label": "结果",
          "type": "select",
          "required": true
        },
        "checkedBy": {
          "fieldId": 1003,
          "label": "核验人",
          "type": "member",
          "required": false
        },
        "checkedAt": {
          "fieldId": 1004,
          "label": "核验时间",
          "type": "datetime",
          "required": false
        },
        "remark": {
          "fieldId": 1005,
          "label": "备注",
          "type": "textarea",
          "required": false
        }
      }
    },
    "devOperatorFullAccess13": {
      "appId": 2191603448,
      "ingressId": "1EJ6p9W2R87QYVD",
      "entityId": 2191603460,
      "name": "Dev operator full access",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "status": {
          "fieldId": 1002,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "markedBy": {
          "fieldId": 1003,
          "label": "标记人",
          "type": "member",
          "required": false
        },
        "markedAt": {
          "fieldId": 1004,
          "label": "标记时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604571": {
      "appId": 2191603448,
      "ingressId": "lA03OwpymOM3eKJ",
      "entityId": 2191603460,
      "name": "人事专员",
      "actions": [
        "view"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "status": {
          "fieldId": 1002,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "markedBy": {
          "fieldId": 1003,
          "label": "标记人",
          "type": "member",
          "required": false
        },
        "markedAt": {
          "fieldId": 1004,
          "label": "标记时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604572": {
      "appId": 2191603448,
      "ingressId": "8WR5KzKAkmx3K20",
      "entityId": 2191603460,
      "name": "人事经理",
      "actions": [
        "view"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "status": {
          "fieldId": 1002,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "markedBy": {
          "fieldId": 1003,
          "label": "标记人",
          "type": "member",
          "required": false
        },
        "markedAt": {
          "fieldId": 1004,
          "label": "标记时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "offer2": {
      "appId": 2191603448,
      "ingressId": "n095RyzN8Og3yNA",
      "entityId": 2191603460,
      "name": "offer专员",
      "actions": [
        "view",
        "add",
        "edit"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "status": {
          "fieldId": 1002,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "markedBy": {
          "fieldId": 1003,
          "label": "标记人",
          "type": "member",
          "required": false
        },
        "markedAt": {
          "fieldId": 1004,
          "label": "标记时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604574": {
      "appId": 2191603448,
      "ingressId": "delQkeWwG215BXD",
      "entityId": 2191603460,
      "name": "招聘助手",
      "actions": [
        "view"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "status": {
          "fieldId": 1002,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "markedBy": {
          "fieldId": 1003,
          "label": "标记人",
          "type": "member",
          "required": false
        },
        "markedAt": {
          "fieldId": 1004,
          "label": "标记时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "devOperatorFullAccess12": {
      "appId": 2191603448,
      "ingressId": "NqwQnp8yOG45X0o",
      "entityId": 2191603459,
      "name": "Dev operator full access",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "amount": {
          "fieldId": 1002,
          "label": "拟薪金额",
          "type": "number",
          "required": false
        },
        "note": {
          "fieldId": 1003,
          "label": "说明",
          "type": "textarea",
          "required": false
        },
        "status": {
          "fieldId": 1004,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "finalAmount": {
          "fieldId": 1005,
          "label": "最终金额",
          "type": "number",
          "required": false
        },
        "approver": {
          "fieldId": 1006,
          "label": "审批人",
          "type": "member",
          "required": false
        },
        "approvedAt": {
          "fieldId": 1007,
          "label": "审批时间",
          "type": "datetime",
          "required": false
        },
        "approvalComment": {
          "fieldId": 1008,
          "label": "审批意见",
          "type": "textarea",
          "required": false
        }
      }
    },
    "ingress2191604569": {
      "appId": 2191603448,
      "ingressId": "zE93eOY7aBp62Vv",
      "entityId": 2191603459,
      "name": "人事专员",
      "actions": [
        "view",
        "add",
        "edit"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "amount": {
          "fieldId": 1002,
          "label": "拟薪金额",
          "type": "number",
          "required": false
        },
        "note": {
          "fieldId": 1003,
          "label": "说明",
          "type": "textarea",
          "required": false
        },
        "status": {
          "fieldId": 1004,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "finalAmount": {
          "fieldId": 1005,
          "label": "最终金额",
          "type": "number",
          "required": false
        },
        "approver": {
          "fieldId": 1006,
          "label": "审批人",
          "type": "member",
          "required": false
        },
        "approvedAt": {
          "fieldId": 1007,
          "label": "审批时间",
          "type": "datetime",
          "required": false
        },
        "approvalComment": {
          "fieldId": 1008,
          "label": "审批意见",
          "type": "textarea",
          "required": false
        }
      }
    },
    "ingress2191604570": {
      "appId": 2191603448,
      "ingressId": "gWr34brLgjy6v1y",
      "entityId": 2191603459,
      "name": "人事经理",
      "actions": [
        "view",
        "edit"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "amount": {
          "fieldId": 1002,
          "label": "拟薪金额",
          "type": "number",
          "required": false
        },
        "note": {
          "fieldId": 1003,
          "label": "说明",
          "type": "textarea",
          "required": false
        },
        "status": {
          "fieldId": 1004,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "finalAmount": {
          "fieldId": 1005,
          "label": "最终金额",
          "type": "number",
          "required": false
        },
        "approver": {
          "fieldId": 1006,
          "label": "审批人",
          "type": "member",
          "required": false
        },
        "approvedAt": {
          "fieldId": 1007,
          "label": "审批时间",
          "type": "datetime",
          "required": false
        },
        "approvalComment": {
          "fieldId": 1008,
          "label": "审批意见",
          "type": "textarea",
          "required": false
        }
      }
    },
    "devOperatorFullAccess11": {
      "appId": 2191603448,
      "ingressId": "delQkeWw1v15BXD",
      "entityId": 2191603458,
      "name": "Dev operator full access",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "mtype": {
          "fieldId": 1002,
          "label": "材料类型",
          "type": "select",
          "required": false
        },
        "attachment": {
          "fieldId": 1003,
          "label": "附件",
          "type": "file",
          "required": true
        },
        "uploadedBy": {
          "fieldId": 1004,
          "label": "上传人",
          "type": "member",
          "required": false
        },
        "uploadedAt": {
          "fieldId": 1005,
          "label": "上传时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604567": {
      "appId": 2191603448,
      "ingressId": "Yog3G2bE4VEQZO1",
      "entityId": 2191603458,
      "name": "人事专员",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "mtype": {
          "fieldId": 1002,
          "label": "材料类型",
          "type": "select",
          "required": false
        },
        "attachment": {
          "fieldId": 1003,
          "label": "附件",
          "type": "file",
          "required": true
        },
        "uploadedBy": {
          "fieldId": 1004,
          "label": "上传人",
          "type": "member",
          "required": false
        },
        "uploadedAt": {
          "fieldId": 1005,
          "label": "上传时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604568": {
      "appId": 2191603448,
      "ingressId": "qORQ1bAZlJG3jmp",
      "entityId": 2191603458,
      "name": "人事经理",
      "actions": [
        "view"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "mtype": {
          "fieldId": 1002,
          "label": "材料类型",
          "type": "select",
          "required": false
        },
        "attachment": {
          "fieldId": 1003,
          "label": "附件",
          "type": "file",
          "required": true
        },
        "uploadedBy": {
          "fieldId": 1004,
          "label": "上传人",
          "type": "member",
          "required": false
        },
        "uploadedAt": {
          "fieldId": 1005,
          "label": "上传时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "devOperatorFullAccess10": {
      "appId": 2191603448,
      "ingressId": "n095RyzNYvg3yNA",
      "entityId": 2191603457,
      "name": "Dev operator full access",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "interviewId": {
          "fieldId": 1001,
          "label": "预约id",
          "type": "text",
          "required": true
        },
        "content": {
          "fieldId": 1002,
          "label": "文字内容",
          "type": "textarea",
          "required": false
        },
        "attachment": {
          "fieldId": 1003,
          "label": "附件",
          "type": "file",
          "required": false
        },
        "uploadedBy": {
          "fieldId": 1004,
          "label": "上传人",
          "type": "member",
          "required": false
        },
        "uploadedAt": {
          "fieldId": 1005,
          "label": "上传时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604564": {
      "appId": 2191603448,
      "ingressId": "mRj3vBoamE9398w",
      "entityId": 2191603457,
      "name": "人事专员",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "interviewId": {
          "fieldId": 1001,
          "label": "预约id",
          "type": "text",
          "required": true
        },
        "content": {
          "fieldId": 1002,
          "label": "文字内容",
          "type": "textarea",
          "required": false
        },
        "attachment": {
          "fieldId": 1003,
          "label": "附件",
          "type": "file",
          "required": false
        },
        "uploadedBy": {
          "fieldId": 1004,
          "label": "上传人",
          "type": "member",
          "required": false
        },
        "uploadedAt": {
          "fieldId": 1005,
          "label": "上传时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604565": {
      "appId": 2191603448,
      "ingressId": "98L5bJOK9Mm5DgZ",
      "entityId": 2191603457,
      "name": "部门领导",
      "actions": [
        "view"
      ],
      "fields": {
        "interviewId": {
          "fieldId": 1001,
          "label": "预约id",
          "type": "text",
          "required": true
        },
        "content": {
          "fieldId": 1002,
          "label": "文字内容",
          "type": "textarea",
          "required": false
        },
        "attachment": {
          "fieldId": 1003,
          "label": "附件",
          "type": "file",
          "required": false
        },
        "uploadedBy": {
          "fieldId": 1004,
          "label": "上传人",
          "type": "member",
          "required": false
        },
        "uploadedAt": {
          "fieldId": 1005,
          "label": "上传时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604566": {
      "appId": 2191603448,
      "ingressId": "lg46jPpAj4N3OZ9",
      "entityId": 2191603457,
      "name": "招聘助手",
      "actions": [
        "view"
      ],
      "fields": {
        "interviewId": {
          "fieldId": 1001,
          "label": "预约id",
          "type": "text",
          "required": true
        },
        "content": {
          "fieldId": 1002,
          "label": "文字内容",
          "type": "textarea",
          "required": false
        },
        "attachment": {
          "fieldId": 1003,
          "label": "附件",
          "type": "file",
          "required": false
        },
        "uploadedBy": {
          "fieldId": 1004,
          "label": "上传人",
          "type": "member",
          "required": false
        },
        "uploadedAt": {
          "fieldId": 1005,
          "label": "上传时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "devOperatorFullAccess9": {
      "appId": 2191603448,
      "ingressId": "8WR5KzKAYLx3K20",
      "entityId": 2191603456,
      "name": "Dev operator full access",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "interviewId": {
          "fieldId": 1001,
          "label": "预约id",
          "type": "text",
          "required": true
        },
        "result": {
          "fieldId": 1002,
          "label": "结论",
          "type": "select",
          "required": true
        },
        "comment": {
          "fieldId": 1003,
          "label": "评价",
          "type": "textarea",
          "required": false
        },
        "submittedBy": {
          "fieldId": 1004,
          "label": "提交人",
          "type": "member",
          "required": false
        },
        "submittedAt": {
          "fieldId": 1005,
          "label": "提交时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604560": {
      "appId": 2191603448,
      "ingressId": "Dr25WWga0vn50nR",
      "entityId": 2191603456,
      "name": "人事专员",
      "actions": [
        "view",
        "add",
        "edit"
      ],
      "fields": {
        "interviewId": {
          "fieldId": 1001,
          "label": "预约id",
          "type": "text",
          "required": true
        },
        "result": {
          "fieldId": 1002,
          "label": "结论",
          "type": "select",
          "required": true
        },
        "comment": {
          "fieldId": 1003,
          "label": "评价",
          "type": "textarea",
          "required": false
        },
        "submittedBy": {
          "fieldId": 1004,
          "label": "提交人",
          "type": "member",
          "required": false
        },
        "submittedAt": {
          "fieldId": 1005,
          "label": "提交时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604561": {
      "appId": 2191603448,
      "ingressId": "91d3aoaOLMZ6WZr",
      "entityId": 2191603456,
      "name": "人事经理",
      "actions": [
        "view"
      ],
      "fields": {
        "interviewId": {
          "fieldId": 1001,
          "label": "预约id",
          "type": "text",
          "required": true
        },
        "result": {
          "fieldId": 1002,
          "label": "结论",
          "type": "select",
          "required": true
        },
        "comment": {
          "fieldId": 1003,
          "label": "评价",
          "type": "textarea",
          "required": false
        },
        "submittedBy": {
          "fieldId": 1004,
          "label": "提交人",
          "type": "member",
          "required": false
        },
        "submittedAt": {
          "fieldId": 1005,
          "label": "提交时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604562": {
      "appId": 2191603448,
      "ingressId": "oaq6VowWzOBQ2xL",
      "entityId": 2191603456,
      "name": "部门领导",
      "actions": [
        "view",
        "add",
        "edit"
      ],
      "fields": {
        "interviewId": {
          "fieldId": 1001,
          "label": "预约id",
          "type": "text",
          "required": true
        },
        "result": {
          "fieldId": 1002,
          "label": "结论",
          "type": "select",
          "required": true
        },
        "comment": {
          "fieldId": 1003,
          "label": "评价",
          "type": "textarea",
          "required": false
        },
        "submittedBy": {
          "fieldId": 1004,
          "label": "提交人",
          "type": "member",
          "required": false
        },
        "submittedAt": {
          "fieldId": 1005,
          "label": "提交时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604563": {
      "appId": 2191603448,
      "ingressId": "Ndn5XorVqKg37BP",
      "entityId": 2191603456,
      "name": "招聘助手",
      "actions": [
        "view",
        "add"
      ],
      "fields": {
        "interviewId": {
          "fieldId": 1001,
          "label": "预约id",
          "type": "text",
          "required": true
        },
        "result": {
          "fieldId": 1002,
          "label": "结论",
          "type": "select",
          "required": true
        },
        "comment": {
          "fieldId": 1003,
          "label": "评价",
          "type": "textarea",
          "required": false
        },
        "submittedBy": {
          "fieldId": 1004,
          "label": "提交人",
          "type": "member",
          "required": false
        },
        "submittedAt": {
          "fieldId": 1005,
          "label": "提交时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "devOperatorFullAccess8": {
      "appId": 2191603448,
      "ingressId": "lA03OwpyYaM3eKJ",
      "entityId": 2191603455,
      "name": "Dev operator full access",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "round": {
          "fieldId": 1002,
          "label": "轮次",
          "type": "number",
          "required": true
        },
        "mode": {
          "fieldId": 1003,
          "label": "方式",
          "type": "select",
          "required": false
        },
        "scheduledAt": {
          "fieldId": 1004,
          "label": "面试时间",
          "type": "datetime",
          "required": false
        },
        "interviewer": {
          "fieldId": 1005,
          "label": "面试官",
          "type": "member",
          "required": false
        },
        "meetingNo": {
          "fieldId": 1006,
          "label": "腾讯会议号",
          "type": "text",
          "required": false
        },
        "status": {
          "fieldId": 1007,
          "label": "状态",
          "type": "select",
          "required": true
        }
      }
    },
    "ingress2191604556": {
      "appId": 2191603448,
      "ingressId": "0yz3NAbrBaXQlGZ",
      "entityId": 2191603455,
      "name": "人事专员",
      "actions": [
        "view",
        "add",
        "edit"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "round": {
          "fieldId": 1002,
          "label": "轮次",
          "type": "number",
          "required": true
        },
        "mode": {
          "fieldId": 1003,
          "label": "方式",
          "type": "select",
          "required": false
        },
        "scheduledAt": {
          "fieldId": 1004,
          "label": "面试时间",
          "type": "datetime",
          "required": false
        },
        "interviewer": {
          "fieldId": 1005,
          "label": "面试官",
          "type": "member",
          "required": false
        },
        "meetingNo": {
          "fieldId": 1006,
          "label": "腾讯会议号",
          "type": "text",
          "required": false
        },
        "status": {
          "fieldId": 1007,
          "label": "状态",
          "type": "select",
          "required": true
        }
      }
    },
    "ingress2191604557": {
      "appId": 2191603448,
      "ingressId": "XWwQL0bwnOrQbl9",
      "entityId": 2191603455,
      "name": "人事经理",
      "actions": [
        "view"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "round": {
          "fieldId": 1002,
          "label": "轮次",
          "type": "number",
          "required": true
        },
        "mode": {
          "fieldId": 1003,
          "label": "方式",
          "type": "select",
          "required": false
        },
        "scheduledAt": {
          "fieldId": 1004,
          "label": "面试时间",
          "type": "datetime",
          "required": false
        },
        "interviewer": {
          "fieldId": 1005,
          "label": "面试官",
          "type": "member",
          "required": false
        },
        "meetingNo": {
          "fieldId": 1006,
          "label": "腾讯会议号",
          "type": "text",
          "required": false
        },
        "status": {
          "fieldId": 1007,
          "label": "状态",
          "type": "select",
          "required": true
        }
      }
    },
    "ingress2191604558": {
      "appId": 2191603448,
      "ingressId": "eyA59dkVN1E3Rxj",
      "entityId": 2191603455,
      "name": "部门领导",
      "actions": [
        "view",
        "add",
        "edit"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "round": {
          "fieldId": 1002,
          "label": "轮次",
          "type": "number",
          "required": true
        },
        "mode": {
          "fieldId": 1003,
          "label": "方式",
          "type": "select",
          "required": false
        },
        "scheduledAt": {
          "fieldId": 1004,
          "label": "面试时间",
          "type": "datetime",
          "required": false
        },
        "interviewer": {
          "fieldId": 1005,
          "label": "面试官",
          "type": "member",
          "required": false
        },
        "meetingNo": {
          "fieldId": 1006,
          "label": "腾讯会议号",
          "type": "text",
          "required": false
        },
        "status": {
          "fieldId": 1007,
          "label": "状态",
          "type": "select",
          "required": true
        }
      }
    },
    "ingress2191604559": {
      "appId": 2191603448,
      "ingressId": "M9R3ov4ZOrjQDzn",
      "entityId": 2191603455,
      "name": "招聘助手",
      "actions": [
        "view",
        "add"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "round": {
          "fieldId": 1002,
          "label": "轮次",
          "type": "number",
          "required": true
        },
        "mode": {
          "fieldId": 1003,
          "label": "方式",
          "type": "select",
          "required": false
        },
        "scheduledAt": {
          "fieldId": 1004,
          "label": "面试时间",
          "type": "datetime",
          "required": false
        },
        "interviewer": {
          "fieldId": 1005,
          "label": "面试官",
          "type": "member",
          "required": false
        },
        "meetingNo": {
          "fieldId": 1006,
          "label": "腾讯会议号",
          "type": "text",
          "required": false
        },
        "status": {
          "fieldId": 1007,
          "label": "状态",
          "type": "select",
          "required": true
        }
      }
    },
    "devOperatorFullAccess7": {
      "appId": 2191603448,
      "ingressId": "gWr34brLYoy6v1y",
      "entityId": 2191603454,
      "name": "Dev operator full access",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "recommender": {
          "fieldId": 1002,
          "label": "推荐人",
          "type": "member",
          "required": false
        },
        "receiver": {
          "fieldId": 1003,
          "label": "接收人",
          "type": "member",
          "required": false
        },
        "aiSummary": {
          "fieldId": 1004,
          "label": "AI摘要快照",
          "type": "textarea",
          "required": false
        },
        "deptFeedback": {
          "fieldId": 1005,
          "label": "部门反馈",
          "type": "select",
          "required": false
        },
        "feedbackChannel": {
          "fieldId": 1006,
          "label": "反馈渠道",
          "type": "select",
          "required": false
        },
        "feedbackAt": {
          "fieldId": 1007,
          "label": "反馈时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604552": {
      "appId": 2191603448,
      "ingressId": "JAy3rjWqkRP30Ya",
      "entityId": 2191603454,
      "name": "人事专员",
      "actions": [
        "view",
        "add",
        "edit"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "recommender": {
          "fieldId": 1002,
          "label": "推荐人",
          "type": "member",
          "required": false
        },
        "receiver": {
          "fieldId": 1003,
          "label": "接收人",
          "type": "member",
          "required": false
        },
        "aiSummary": {
          "fieldId": 1004,
          "label": "AI摘要快照",
          "type": "textarea",
          "required": false
        },
        "deptFeedback": {
          "fieldId": 1005,
          "label": "部门反馈",
          "type": "select",
          "required": false
        },
        "feedbackChannel": {
          "fieldId": 1006,
          "label": "反馈渠道",
          "type": "select",
          "required": false
        },
        "feedbackAt": {
          "fieldId": 1007,
          "label": "反馈时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604553": {
      "appId": 2191603448,
      "ingressId": "WXB3yBRv8lN5veo",
      "entityId": 2191603454,
      "name": "人事经理",
      "actions": [
        "view"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "recommender": {
          "fieldId": 1002,
          "label": "推荐人",
          "type": "member",
          "required": false
        },
        "receiver": {
          "fieldId": 1003,
          "label": "接收人",
          "type": "member",
          "required": false
        },
        "aiSummary": {
          "fieldId": 1004,
          "label": "AI摘要快照",
          "type": "textarea",
          "required": false
        },
        "deptFeedback": {
          "fieldId": 1005,
          "label": "部门反馈",
          "type": "select",
          "required": false
        },
        "feedbackChannel": {
          "fieldId": 1006,
          "label": "反馈渠道",
          "type": "select",
          "required": false
        },
        "feedbackAt": {
          "fieldId": 1007,
          "label": "反馈时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604554": {
      "appId": 2191603448,
      "ingressId": "nMY6ZaZvwqd5Pya",
      "entityId": 2191603454,
      "name": "部门领导",
      "actions": [
        "view",
        "edit"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "recommender": {
          "fieldId": 1002,
          "label": "推荐人",
          "type": "member",
          "required": false
        },
        "receiver": {
          "fieldId": 1003,
          "label": "接收人",
          "type": "member",
          "required": false
        },
        "aiSummary": {
          "fieldId": 1004,
          "label": "AI摘要快照",
          "type": "textarea",
          "required": false
        },
        "deptFeedback": {
          "fieldId": 1005,
          "label": "部门反馈",
          "type": "select",
          "required": false
        },
        "feedbackChannel": {
          "fieldId": 1006,
          "label": "反馈渠道",
          "type": "select",
          "required": false
        },
        "feedbackAt": {
          "fieldId": 1007,
          "label": "反馈时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604555": {
      "appId": 2191603448,
      "ingressId": "7yPQ2bw2AJ7Q9Kv",
      "entityId": 2191603454,
      "name": "招聘助手",
      "actions": [
        "view",
        "add",
        "edit"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "recommender": {
          "fieldId": 1002,
          "label": "推荐人",
          "type": "member",
          "required": false
        },
        "receiver": {
          "fieldId": 1003,
          "label": "接收人",
          "type": "member",
          "required": false
        },
        "aiSummary": {
          "fieldId": 1004,
          "label": "AI摘要快照",
          "type": "textarea",
          "required": false
        },
        "deptFeedback": {
          "fieldId": 1005,
          "label": "部门反馈",
          "type": "select",
          "required": false
        },
        "feedbackChannel": {
          "fieldId": 1006,
          "label": "反馈渠道",
          "type": "select",
          "required": false
        },
        "feedbackAt": {
          "fieldId": 1007,
          "label": "反馈时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "devOperatorFullAccess6": {
      "appId": 2191603448,
      "ingressId": "zE93eOY7V9p62Vv",
      "entityId": 2191603453,
      "name": "Dev operator full access",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "tier": {
          "fieldId": 1002,
          "label": "档位",
          "type": "select",
          "required": true
        },
        "score": {
          "fieldId": 1003,
          "label": "匹配百分比",
          "type": "number",
          "required": false
        },
        "details": {
          "fieldId": 1004,
          "label": "命中明细",
          "type": "textarea",
          "required": false
        },
        "source": {
          "fieldId": 1005,
          "label": "匹配来源",
          "type": "select",
          "required": false
        },
        "matchedAt": {
          "fieldId": 1006,
          "label": "匹配时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604548": {
      "appId": 2191603448,
      "ingressId": "dbg6lvag12a3NaL",
      "entityId": 2191603453,
      "name": "人事专员",
      "actions": [
        "view",
        "delete"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "tier": {
          "fieldId": 1002,
          "label": "档位",
          "type": "select",
          "required": true
        },
        "score": {
          "fieldId": 1003,
          "label": "匹配百分比",
          "type": "number",
          "required": false
        },
        "details": {
          "fieldId": 1004,
          "label": "命中明细",
          "type": "textarea",
          "required": false
        },
        "source": {
          "fieldId": 1005,
          "label": "匹配来源",
          "type": "select",
          "required": false
        },
        "matchedAt": {
          "fieldId": 1006,
          "label": "匹配时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604549": {
      "appId": 2191603448,
      "ingressId": "wVo3AAb4vrA3emJ",
      "entityId": 2191603453,
      "name": "人事经理",
      "actions": [
        "view"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "tier": {
          "fieldId": 1002,
          "label": "档位",
          "type": "select",
          "required": true
        },
        "score": {
          "fieldId": 1003,
          "label": "匹配百分比",
          "type": "number",
          "required": false
        },
        "details": {
          "fieldId": 1004,
          "label": "命中明细",
          "type": "textarea",
          "required": false
        },
        "source": {
          "fieldId": 1005,
          "label": "匹配来源",
          "type": "select",
          "required": false
        },
        "matchedAt": {
          "fieldId": 1006,
          "label": "匹配时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604550": {
      "appId": 2191603448,
      "ingressId": "zRmQwnWVPzq6jlv",
      "entityId": 2191603453,
      "name": "部门领导",
      "actions": [
        "view"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "tier": {
          "fieldId": 1002,
          "label": "档位",
          "type": "select",
          "required": true
        },
        "score": {
          "fieldId": 1003,
          "label": "匹配百分比",
          "type": "number",
          "required": false
        },
        "details": {
          "fieldId": 1004,
          "label": "命中明细",
          "type": "textarea",
          "required": false
        },
        "source": {
          "fieldId": 1005,
          "label": "匹配来源",
          "type": "select",
          "required": false
        },
        "matchedAt": {
          "fieldId": 1006,
          "label": "匹配时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "ingress2191604551": {
      "appId": 2191603448,
      "ingressId": "B9j3gdPzXgD54p7",
      "entityId": 2191603453,
      "name": "招聘助手",
      "actions": [
        "view",
        "add",
        "edit"
      ],
      "fields": {
        "pipelineId": {
          "fieldId": 1001,
          "label": "流程id",
          "type": "text",
          "required": true
        },
        "tier": {
          "fieldId": 1002,
          "label": "档位",
          "type": "select",
          "required": true
        },
        "score": {
          "fieldId": 1003,
          "label": "匹配百分比",
          "type": "number",
          "required": false
        },
        "details": {
          "fieldId": 1004,
          "label": "命中明细",
          "type": "textarea",
          "required": false
        },
        "source": {
          "fieldId": 1005,
          "label": "匹配来源",
          "type": "select",
          "required": false
        },
        "matchedAt": {
          "fieldId": 1006,
          "label": "匹配时间",
          "type": "datetime",
          "required": false
        }
      }
    },
    "devOperatorFullAccess5": {
      "appId": 2191603448,
      "ingressId": "qORQ1bAZYqG3jmp",
      "entityId": 2191603452,
      "name": "Dev operator full access",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "resumeId": {
          "fieldId": 1001,
          "label": "简历id",
          "type": "text",
          "required": true
        },
        "demandId": {
          "fieldId": 1002,
          "label": "需求单id",
          "type": "text",
          "required": true
        },
        "currentStage": {
          "fieldId": 1003,
          "label": "当前阶段",
          "type": "select",
          "required": true
        },
        "stageTs": {
          "fieldId": 1004,
          "label": "阶段时间",
          "type": "datetime",
          "required": false
        },
        "startedAt": {
          "fieldId": 1005,
          "label": "开始时间",
          "type": "datetime",
          "required": true
        }
      }
    },
    "ingress2191604543": {
      "appId": 2191603448,
      "ingressId": "BrW6qMWNRB76ZMm",
      "entityId": 2191603452,
      "name": "人事专员",
      "actions": [
        "view",
        "add",
        "edit"
      ],
      "fields": {
        "resumeId": {
          "fieldId": 1001,
          "label": "简历id",
          "type": "text",
          "required": true
        },
        "demandId": {
          "fieldId": 1002,
          "label": "需求单id",
          "type": "text",
          "required": true
        },
        "currentStage": {
          "fieldId": 1003,
          "label": "当前阶段",
          "type": "select",
          "required": true
        },
        "stageTs": {
          "fieldId": 1004,
          "label": "阶段时间",
          "type": "datetime",
          "required": false
        },
        "startedAt": {
          "fieldId": 1005,
          "label": "开始时间",
          "type": "datetime",
          "required": true
        }
      }
    },
    "ingress2191604544": {
      "appId": 2191603448,
      "ingressId": "mAg57j2WZe73jnx",
      "entityId": 2191603452,
      "name": "人事经理",
      "actions": [
        "view"
      ],
      "fields": {
        "resumeId": {
          "fieldId": 1001,
          "label": "简历id",
          "type": "text",
          "required": true
        },
        "demandId": {
          "fieldId": 1002,
          "label": "需求单id",
          "type": "text",
          "required": true
        },
        "currentStage": {
          "fieldId": 1003,
          "label": "当前阶段",
          "type": "select",
          "required": true
        },
        "stageTs": {
          "fieldId": 1004,
          "label": "阶段时间",
          "type": "datetime",
          "required": false
        },
        "startedAt": {
          "fieldId": 1005,
          "label": "开始时间",
          "type": "datetime",
          "required": true
        }
      }
    },
    "ingress2191604545": {
      "appId": 2191603448,
      "ingressId": "09R3EqKk1Pd3zPo",
      "entityId": 2191603452,
      "name": "部门领导",
      "actions": [
        "view"
      ],
      "fields": {
        "resumeId": {
          "fieldId": 1001,
          "label": "简历id",
          "type": "text",
          "required": true
        },
        "demandId": {
          "fieldId": 1002,
          "label": "需求单id",
          "type": "text",
          "required": true
        },
        "currentStage": {
          "fieldId": 1003,
          "label": "当前阶段",
          "type": "select",
          "required": true
        },
        "stageTs": {
          "fieldId": 1004,
          "label": "阶段时间",
          "type": "datetime",
          "required": false
        },
        "startedAt": {
          "fieldId": 1005,
          "label": "开始时间",
          "type": "datetime",
          "required": true
        }
      }
    },
    "offer": {
      "appId": 2191603448,
      "ingressId": "eDO6zOXbJA1QMdx",
      "entityId": 2191603452,
      "name": "offer专员",
      "actions": [
        "view"
      ],
      "fields": {
        "resumeId": {
          "fieldId": 1001,
          "label": "简历id",
          "type": "text",
          "required": true
        },
        "demandId": {
          "fieldId": 1002,
          "label": "需求单id",
          "type": "text",
          "required": true
        },
        "currentStage": {
          "fieldId": 1003,
          "label": "当前阶段",
          "type": "select",
          "required": true
        },
        "stageTs": {
          "fieldId": 1004,
          "label": "阶段时间",
          "type": "datetime",
          "required": false
        },
        "startedAt": {
          "fieldId": 1005,
          "label": "开始时间",
          "type": "datetime",
          "required": true
        }
      }
    },
    "ingress2191604547": {
      "appId": 2191603448,
      "ingressId": "AqV50Oly0Jv31kG",
      "entityId": 2191603452,
      "name": "招聘助手",
      "actions": [
        "view",
        "add",
        "edit"
      ],
      "fields": {
        "resumeId": {
          "fieldId": 1001,
          "label": "简历id",
          "type": "text",
          "required": true
        },
        "demandId": {
          "fieldId": 1002,
          "label": "需求单id",
          "type": "text",
          "required": true
        },
        "currentStage": {
          "fieldId": 1003,
          "label": "当前阶段",
          "type": "select",
          "required": true
        },
        "stageTs": {
          "fieldId": 1004,
          "label": "阶段时间",
          "type": "datetime",
          "required": false
        },
        "startedAt": {
          "fieldId": 1005,
          "label": "开始时间",
          "type": "datetime",
          "required": true
        }
      }
    },
    "ingress2191753948": {
      "appId": 2191603448,
      "ingressId": "dbg6lvawlvV3NaL",
      "entityId": 2191603451,
      "name": "简历表用户全访问",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "name": {
          "fieldId": 1001,
          "label": "姓名",
          "type": "text",
          "required": true
        },
        "phone": {
          "fieldId": 1002,
          "label": "手机号",
          "type": "text",
          "required": true
        },
        "idCard": {
          "fieldId": 1003,
          "label": "身份证号",
          "type": "text",
          "required": false
        },
        "gender": {
          "fieldId": 1004,
          "label": "性别",
          "type": "select",
          "required": false
        },
        "age": {
          "fieldId": 1005,
          "label": "年龄",
          "type": "number",
          "required": false
        },
        "education": {
          "fieldId": 1006,
          "label": "学历",
          "type": "select",
          "required": false
        },
        "school": {
          "fieldId": 1007,
          "label": "院校",
          "type": "text",
          "required": false
        },
        "workYears": {
          "fieldId": 1008,
          "label": "工作年限",
          "type": "number",
          "required": false
        },
        "skills": {
          "fieldId": 1009,
          "label": "技能",
          "type": "textarea",
          "required": false
        },
        "expectedSalary": {
          "fieldId": 1010,
          "label": "期望薪资",
          "type": "text",
          "required": false
        },
        "availableDate": {
          "fieldId": 1011,
          "label": "到岗时间",
          "type": "datetime",
          "required": false
        },
        "originFile": {
          "fieldId": 1012,
          "label": "原始文件",
          "type": "file",
          "required": false
        },
        "channel": {
          "fieldId": 1013,
          "label": "渠道",
          "type": "select",
          "required": false
        },
        "library": {
          "fieldId": 1014,
          "label": "库归属",
          "type": "select",
          "required": true
        },
        "pipelineStatus": {
          "fieldId": 1015,
          "label": "流程状态",
          "type": "select",
          "required": false
        },
        "parseStatus": {
          "fieldId": 1016,
          "label": "解析状态",
          "type": "select",
          "required": false
        },
        "source": {
          "fieldId": 1017,
          "label": "来源",
          "type": "select",
          "required": false
        },
        "ethnicity": {
          "fieldId": 1018,
          "label": "民族",
          "type": "text",
          "required": false
        },
        "currentCity": {
          "fieldId": 1019,
          "label": "现居地",
          "type": "text",
          "required": false
        },
        "email": {
          "fieldId": 1020,
          "label": "邮箱",
          "type": "text",
          "required": false
        },
        "expectedPosition": {
          "fieldId": 1021,
          "label": "应聘职位",
          "type": "text",
          "required": false
        },
        "expectedCity": {
          "fieldId": 1022,
          "label": "期望城市",
          "type": "text",
          "required": false
        },
        "educationDetail": {
          "fieldId": 1023,
          "label": "教育背景",
          "type": "textarea",
          "required": false
        },
        "workExperience": {
          "fieldId": 1024,
          "label": "工作经历",
          "type": "textarea",
          "required": false
        }
      }
    },
    "devOperatorFullAccess4": {
      "appId": 2191603448,
      "ingressId": "Yog3G2bExyEQZO1",
      "entityId": 2191603451,
      "name": "Dev operator full access",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "name": {
          "fieldId": 1001,
          "label": "姓名",
          "type": "text",
          "required": true
        },
        "phone": {
          "fieldId": 1002,
          "label": "手机号",
          "type": "text",
          "required": true
        },
        "idCard": {
          "fieldId": 1003,
          "label": "身份证号",
          "type": "text",
          "required": false
        },
        "gender": {
          "fieldId": 1004,
          "label": "性别",
          "type": "select",
          "required": false
        },
        "age": {
          "fieldId": 1005,
          "label": "年龄",
          "type": "number",
          "required": false
        },
        "education": {
          "fieldId": 1006,
          "label": "学历",
          "type": "select",
          "required": false
        },
        "school": {
          "fieldId": 1007,
          "label": "院校",
          "type": "text",
          "required": false
        },
        "workYears": {
          "fieldId": 1008,
          "label": "工作年限",
          "type": "number",
          "required": false
        },
        "skills": {
          "fieldId": 1009,
          "label": "技能",
          "type": "textarea",
          "required": false
        },
        "expectedSalary": {
          "fieldId": 1010,
          "label": "期望薪资",
          "type": "text",
          "required": false
        },
        "availableDate": {
          "fieldId": 1011,
          "label": "到岗时间",
          "type": "datetime",
          "required": false
        },
        "originFile": {
          "fieldId": 1012,
          "label": "原始文件",
          "type": "file",
          "required": false
        },
        "channel": {
          "fieldId": 1013,
          "label": "渠道",
          "type": "select",
          "required": false
        },
        "library": {
          "fieldId": 1014,
          "label": "库归属",
          "type": "select",
          "required": true
        },
        "pipelineStatus": {
          "fieldId": 1015,
          "label": "流程状态",
          "type": "select",
          "required": false
        },
        "parseStatus": {
          "fieldId": 1016,
          "label": "解析状态",
          "type": "select",
          "required": false
        },
        "source": {
          "fieldId": 1017,
          "label": "来源",
          "type": "select",
          "required": false
        },
        "ethnicity": {
          "fieldId": 1018,
          "label": "民族",
          "type": "text",
          "required": false
        },
        "currentCity": {
          "fieldId": 1019,
          "label": "现居地",
          "type": "text",
          "required": false
        },
        "email": {
          "fieldId": 1020,
          "label": "邮箱",
          "type": "text",
          "required": false
        },
        "expectedPosition": {
          "fieldId": 1021,
          "label": "应聘职位",
          "type": "text",
          "required": false
        },
        "expectedCity": {
          "fieldId": 1022,
          "label": "期望城市",
          "type": "text",
          "required": false
        },
        "educationDetail": {
          "fieldId": 1023,
          "label": "教育背景",
          "type": "textarea",
          "required": false
        },
        "workExperience": {
          "fieldId": 1024,
          "label": "工作经历",
          "type": "textarea",
          "required": false
        }
      }
    },
    "ingress2191604539": {
      "appId": 2191603448,
      "ingressId": "Rol6YoyXAO43ynV",
      "entityId": 2191603451,
      "name": "人事专员",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "name": {
          "fieldId": 1001,
          "label": "姓名",
          "type": "text",
          "required": true
        },
        "phone": {
          "fieldId": 1002,
          "label": "手机号",
          "type": "text",
          "required": true
        },
        "idCard": {
          "fieldId": 1003,
          "label": "身份证号",
          "type": "text",
          "required": false
        },
        "gender": {
          "fieldId": 1004,
          "label": "性别",
          "type": "select",
          "required": false
        },
        "age": {
          "fieldId": 1005,
          "label": "年龄",
          "type": "number",
          "required": false
        },
        "education": {
          "fieldId": 1006,
          "label": "学历",
          "type": "select",
          "required": false
        },
        "school": {
          "fieldId": 1007,
          "label": "院校",
          "type": "text",
          "required": false
        },
        "workYears": {
          "fieldId": 1008,
          "label": "工作年限",
          "type": "number",
          "required": false
        },
        "skills": {
          "fieldId": 1009,
          "label": "技能",
          "type": "textarea",
          "required": false
        },
        "expectedSalary": {
          "fieldId": 1010,
          "label": "期望薪资",
          "type": "text",
          "required": false
        },
        "availableDate": {
          "fieldId": 1011,
          "label": "到岗时间",
          "type": "datetime",
          "required": false
        },
        "originFile": {
          "fieldId": 1012,
          "label": "原始文件",
          "type": "file",
          "required": false
        },
        "channel": {
          "fieldId": 1013,
          "label": "渠道",
          "type": "select",
          "required": false
        },
        "library": {
          "fieldId": 1014,
          "label": "库归属",
          "type": "select",
          "required": true
        },
        "pipelineStatus": {
          "fieldId": 1015,
          "label": "流程状态",
          "type": "select",
          "required": false
        },
        "parseStatus": {
          "fieldId": 1016,
          "label": "解析状态",
          "type": "select",
          "required": false
        },
        "source": {
          "fieldId": 1017,
          "label": "来源",
          "type": "select",
          "required": false
        },
        "ethnicity": {
          "fieldId": 1018,
          "label": "民族",
          "type": "text",
          "required": false
        },
        "currentCity": {
          "fieldId": 1019,
          "label": "现居地",
          "type": "text",
          "required": false
        },
        "email": {
          "fieldId": 1020,
          "label": "邮箱",
          "type": "text",
          "required": false
        },
        "expectedPosition": {
          "fieldId": 1021,
          "label": "应聘职位",
          "type": "text",
          "required": false
        },
        "expectedCity": {
          "fieldId": 1022,
          "label": "期望城市",
          "type": "text",
          "required": false
        },
        "educationDetail": {
          "fieldId": 1023,
          "label": "教育背景",
          "type": "textarea",
          "required": false
        },
        "workExperience": {
          "fieldId": 1024,
          "label": "工作经历",
          "type": "textarea",
          "required": false
        }
      }
    },
    "ingress2191604540": {
      "appId": 2191603448,
      "ingressId": "GXw6xRBXD0b39B0",
      "entityId": 2191603451,
      "name": "人事经理",
      "actions": [
        "view"
      ],
      "fields": {
        "name": {
          "fieldId": 1001,
          "label": "姓名",
          "type": "text",
          "required": true
        },
        "phone": {
          "fieldId": 1002,
          "label": "手机号",
          "type": "text",
          "required": true
        },
        "idCard": {
          "fieldId": 1003,
          "label": "身份证号",
          "type": "text",
          "required": false
        },
        "gender": {
          "fieldId": 1004,
          "label": "性别",
          "type": "select",
          "required": false
        },
        "age": {
          "fieldId": 1005,
          "label": "年龄",
          "type": "number",
          "required": false
        },
        "education": {
          "fieldId": 1006,
          "label": "学历",
          "type": "select",
          "required": false
        },
        "school": {
          "fieldId": 1007,
          "label": "院校",
          "type": "text",
          "required": false
        },
        "workYears": {
          "fieldId": 1008,
          "label": "工作年限",
          "type": "number",
          "required": false
        },
        "skills": {
          "fieldId": 1009,
          "label": "技能",
          "type": "textarea",
          "required": false
        },
        "expectedSalary": {
          "fieldId": 1010,
          "label": "期望薪资",
          "type": "text",
          "required": false
        },
        "availableDate": {
          "fieldId": 1011,
          "label": "到岗时间",
          "type": "datetime",
          "required": false
        },
        "originFile": {
          "fieldId": 1012,
          "label": "原始文件",
          "type": "file",
          "required": false
        },
        "channel": {
          "fieldId": 1013,
          "label": "渠道",
          "type": "select",
          "required": false
        },
        "library": {
          "fieldId": 1014,
          "label": "库归属",
          "type": "select",
          "required": true
        },
        "pipelineStatus": {
          "fieldId": 1015,
          "label": "流程状态",
          "type": "select",
          "required": false
        },
        "parseStatus": {
          "fieldId": 1016,
          "label": "解析状态",
          "type": "select",
          "required": false
        },
        "source": {
          "fieldId": 1017,
          "label": "来源",
          "type": "select",
          "required": false
        },
        "ethnicity": {
          "fieldId": 1018,
          "label": "民族",
          "type": "text",
          "required": false
        },
        "currentCity": {
          "fieldId": 1019,
          "label": "现居地",
          "type": "text",
          "required": false
        },
        "email": {
          "fieldId": 1020,
          "label": "邮箱",
          "type": "text",
          "required": false
        },
        "expectedPosition": {
          "fieldId": 1021,
          "label": "应聘职位",
          "type": "text",
          "required": false
        },
        "expectedCity": {
          "fieldId": 1022,
          "label": "期望城市",
          "type": "text",
          "required": false
        },
        "educationDetail": {
          "fieldId": 1023,
          "label": "教育背景",
          "type": "textarea",
          "required": false
        },
        "workExperience": {
          "fieldId": 1024,
          "label": "工作经历",
          "type": "textarea",
          "required": false
        }
      }
    },
    "ingress2191604541": {
      "appId": 2191603448,
      "ingressId": "qRBQdvJkWM05yxk",
      "entityId": 2191603451,
      "name": "部门领导",
      "actions": [
        "view"
      ],
      "fields": {
        "name": {
          "fieldId": 1001,
          "label": "姓名",
          "type": "text",
          "required": true
        },
        "phone": {
          "fieldId": 1002,
          "label": "手机号",
          "type": "text",
          "required": true
        },
        "idCard": {
          "fieldId": 1003,
          "label": "身份证号",
          "type": "text",
          "required": false
        },
        "gender": {
          "fieldId": 1004,
          "label": "性别",
          "type": "select",
          "required": false
        },
        "age": {
          "fieldId": 1005,
          "label": "年龄",
          "type": "number",
          "required": false
        },
        "education": {
          "fieldId": 1006,
          "label": "学历",
          "type": "select",
          "required": false
        },
        "school": {
          "fieldId": 1007,
          "label": "院校",
          "type": "text",
          "required": false
        },
        "workYears": {
          "fieldId": 1008,
          "label": "工作年限",
          "type": "number",
          "required": false
        },
        "skills": {
          "fieldId": 1009,
          "label": "技能",
          "type": "textarea",
          "required": false
        },
        "expectedSalary": {
          "fieldId": 1010,
          "label": "期望薪资",
          "type": "text",
          "required": false
        },
        "availableDate": {
          "fieldId": 1011,
          "label": "到岗时间",
          "type": "datetime",
          "required": false
        },
        "originFile": {
          "fieldId": 1012,
          "label": "原始文件",
          "type": "file",
          "required": false
        },
        "channel": {
          "fieldId": 1013,
          "label": "渠道",
          "type": "select",
          "required": false
        },
        "library": {
          "fieldId": 1014,
          "label": "库归属",
          "type": "select",
          "required": true
        },
        "pipelineStatus": {
          "fieldId": 1015,
          "label": "流程状态",
          "type": "select",
          "required": false
        },
        "parseStatus": {
          "fieldId": 1016,
          "label": "解析状态",
          "type": "select",
          "required": false
        },
        "source": {
          "fieldId": 1017,
          "label": "来源",
          "type": "select",
          "required": false
        },
        "ethnicity": {
          "fieldId": 1018,
          "label": "民族",
          "type": "text",
          "required": false
        },
        "currentCity": {
          "fieldId": 1019,
          "label": "现居地",
          "type": "text",
          "required": false
        },
        "email": {
          "fieldId": 1020,
          "label": "邮箱",
          "type": "text",
          "required": false
        },
        "expectedPosition": {
          "fieldId": 1021,
          "label": "应聘职位",
          "type": "text",
          "required": false
        },
        "expectedCity": {
          "fieldId": 1022,
          "label": "期望城市",
          "type": "text",
          "required": false
        },
        "educationDetail": {
          "fieldId": 1023,
          "label": "教育背景",
          "type": "textarea",
          "required": false
        },
        "workExperience": {
          "fieldId": 1024,
          "label": "工作经历",
          "type": "textarea",
          "required": false
        }
      }
    },
    "ingress2191604542": {
      "appId": 2191603448,
      "ingressId": "naE5Mljgpaa3J0Y",
      "entityId": 2191603451,
      "name": "招聘助手",
      "actions": [
        "view",
        "add",
        "edit"
      ],
      "fields": {
        "name": {
          "fieldId": 1001,
          "label": "姓名",
          "type": "text",
          "required": true
        },
        "phone": {
          "fieldId": 1002,
          "label": "手机号",
          "type": "text",
          "required": true
        },
        "idCard": {
          "fieldId": 1003,
          "label": "身份证号",
          "type": "text",
          "required": false
        },
        "gender": {
          "fieldId": 1004,
          "label": "性别",
          "type": "select",
          "required": false
        },
        "age": {
          "fieldId": 1005,
          "label": "年龄",
          "type": "number",
          "required": false
        },
        "education": {
          "fieldId": 1006,
          "label": "学历",
          "type": "select",
          "required": false
        },
        "school": {
          "fieldId": 1007,
          "label": "院校",
          "type": "text",
          "required": false
        },
        "workYears": {
          "fieldId": 1008,
          "label": "工作年限",
          "type": "number",
          "required": false
        },
        "skills": {
          "fieldId": 1009,
          "label": "技能",
          "type": "textarea",
          "required": false
        },
        "expectedSalary": {
          "fieldId": 1010,
          "label": "期望薪资",
          "type": "text",
          "required": false
        },
        "availableDate": {
          "fieldId": 1011,
          "label": "到岗时间",
          "type": "datetime",
          "required": false
        },
        "originFile": {
          "fieldId": 1012,
          "label": "原始文件",
          "type": "file",
          "required": false
        },
        "channel": {
          "fieldId": 1013,
          "label": "渠道",
          "type": "select",
          "required": false
        },
        "library": {
          "fieldId": 1014,
          "label": "库归属",
          "type": "select",
          "required": true
        },
        "pipelineStatus": {
          "fieldId": 1015,
          "label": "流程状态",
          "type": "select",
          "required": false
        },
        "parseStatus": {
          "fieldId": 1016,
          "label": "解析状态",
          "type": "select",
          "required": false
        },
        "source": {
          "fieldId": 1017,
          "label": "来源",
          "type": "select",
          "required": false
        },
        "ethnicity": {
          "fieldId": 1018,
          "label": "民族",
          "type": "text",
          "required": false
        },
        "currentCity": {
          "fieldId": 1019,
          "label": "现居地",
          "type": "text",
          "required": false
        },
        "email": {
          "fieldId": 1020,
          "label": "邮箱",
          "type": "text",
          "required": false
        },
        "expectedPosition": {
          "fieldId": 1021,
          "label": "应聘职位",
          "type": "text",
          "required": false
        },
        "expectedCity": {
          "fieldId": 1022,
          "label": "期望城市",
          "type": "text",
          "required": false
        },
        "educationDetail": {
          "fieldId": 1023,
          "label": "教育背景",
          "type": "textarea",
          "required": false
        },
        "workExperience": {
          "fieldId": 1024,
          "label": "工作经历",
          "type": "textarea",
          "required": false
        }
      }
    },
    "devOperatorFullAccess3": {
      "appId": 2191603448,
      "ingressId": "lg46jPpAGXN3OZ9",
      "entityId": 2191603450,
      "name": "Dev operator full access",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "name": {
          "fieldId": 1001,
          "label": "岗位名",
          "type": "text",
          "required": true
        },
        "department": {
          "fieldId": 1002,
          "label": "部门",
          "type": "text",
          "required": false
        },
        "jd": {
          "fieldId": 1003,
          "label": "岗位描述",
          "type": "textarea",
          "required": false
        },
        "owner": {
          "fieldId": 1006,
          "label": "岗位负责人",
          "type": "member",
          "required": false
        },
        "status": {
          "fieldId": 1007,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "grade": {
          "fieldId": 1008,
          "label": "岗位等级",
          "type": "text",
          "required": false
        },
        "headcount": {
          "fieldId": 1009,
          "label": "招聘人数",
          "type": "text",
          "required": false
        },
        "educationRequirement": {
          "fieldId": 1011,
          "label": "学历要求",
          "type": "text",
          "required": false
        },
        "experienceRequirement": {
          "fieldId": 1013,
          "label": "经验要求",
          "type": "text",
          "required": false
        },
        "remark": {
          "fieldId": 1015,
          "label": "备注",
          "type": "textarea",
          "required": false
        },
        "ageMin": {
          "fieldId": 1016,
          "label": "年龄下限",
          "type": "text",
          "required": false
        },
        "ageMax": {
          "fieldId": 1017,
          "label": "年龄上限",
          "type": "text",
          "required": false
        },
        "salaryMin": {
          "fieldId": 1018,
          "label": "薪资下限(K)",
          "type": "text",
          "required": false
        },
        "salaryMax": {
          "fieldId": 1019,
          "label": "薪资上限(K)",
          "type": "text",
          "required": false
        },
        "skillItems": {
          "fieldId": 1020,
          "label": "技能要求",
          "type": "subform",
          "required": false
        },
        "skillName": {
          "fieldId": 1021,
          "label": "技能名",
          "type": "text",
          "required": false
        }
      }
    },
    "ingress2191604535": {
      "appId": 2191603448,
      "ingressId": "Lol5Pg7ZPJn34ZV",
      "entityId": 2191603450,
      "name": "人事专员",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "name": {
          "fieldId": 1001,
          "label": "岗位名",
          "type": "text",
          "required": true
        },
        "department": {
          "fieldId": 1002,
          "label": "部门",
          "type": "text",
          "required": false
        },
        "jd": {
          "fieldId": 1003,
          "label": "岗位描述",
          "type": "textarea",
          "required": false
        },
        "owner": {
          "fieldId": 1006,
          "label": "岗位负责人",
          "type": "member",
          "required": false
        },
        "status": {
          "fieldId": 1007,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "grade": {
          "fieldId": 1008,
          "label": "岗位等级",
          "type": "text",
          "required": false
        },
        "headcount": {
          "fieldId": 1009,
          "label": "招聘人数",
          "type": "text",
          "required": false
        },
        "educationRequirement": {
          "fieldId": 1011,
          "label": "学历要求",
          "type": "text",
          "required": false
        },
        "experienceRequirement": {
          "fieldId": 1013,
          "label": "经验要求",
          "type": "text",
          "required": false
        },
        "remark": {
          "fieldId": 1015,
          "label": "备注",
          "type": "textarea",
          "required": false
        },
        "ageMin": {
          "fieldId": 1016,
          "label": "年龄下限",
          "type": "text",
          "required": false
        },
        "ageMax": {
          "fieldId": 1017,
          "label": "年龄上限",
          "type": "text",
          "required": false
        },
        "salaryMin": {
          "fieldId": 1018,
          "label": "薪资下限(K)",
          "type": "text",
          "required": false
        },
        "salaryMax": {
          "fieldId": 1019,
          "label": "薪资上限(K)",
          "type": "text",
          "required": false
        },
        "skillItems": {
          "fieldId": 1020,
          "label": "技能要求",
          "type": "subform",
          "required": false
        },
        "skillName": {
          "fieldId": 1021,
          "label": "技能名",
          "type": "text",
          "required": false
        }
      }
    },
    "ingress2191604537": {
      "appId": 2191603448,
      "ingressId": "ExKQ8b9a28g5Dkj",
      "entityId": 2191603450,
      "name": "部门领导",
      "actions": [
        "view"
      ],
      "fields": {
        "name": {
          "fieldId": 1001,
          "label": "岗位名",
          "type": "text",
          "required": true
        },
        "department": {
          "fieldId": 1002,
          "label": "部门",
          "type": "text",
          "required": false
        },
        "jd": {
          "fieldId": 1003,
          "label": "岗位描述",
          "type": "textarea",
          "required": false
        },
        "owner": {
          "fieldId": 1006,
          "label": "岗位负责人",
          "type": "member",
          "required": false
        },
        "status": {
          "fieldId": 1007,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "grade": {
          "fieldId": 1008,
          "label": "岗位等级",
          "type": "text",
          "required": false
        },
        "headcount": {
          "fieldId": 1009,
          "label": "招聘人数",
          "type": "text",
          "required": false
        },
        "educationRequirement": {
          "fieldId": 1011,
          "label": "学历要求",
          "type": "text",
          "required": false
        },
        "experienceRequirement": {
          "fieldId": 1013,
          "label": "经验要求",
          "type": "text",
          "required": false
        },
        "remark": {
          "fieldId": 1015,
          "label": "备注",
          "type": "textarea",
          "required": false
        },
        "ageMin": {
          "fieldId": 1016,
          "label": "年龄下限",
          "type": "text",
          "required": false
        },
        "ageMax": {
          "fieldId": 1017,
          "label": "年龄上限",
          "type": "text",
          "required": false
        },
        "salaryMin": {
          "fieldId": 1018,
          "label": "薪资下限(K)",
          "type": "text",
          "required": false
        },
        "salaryMax": {
          "fieldId": 1019,
          "label": "薪资上限(K)",
          "type": "text",
          "required": false
        },
        "skillItems": {
          "fieldId": 1020,
          "label": "技能要求",
          "type": "subform",
          "required": false
        },
        "skillName": {
          "fieldId": 1021,
          "label": "技能名",
          "type": "text",
          "required": false
        }
      }
    },
    "ingress2191604538": {
      "appId": 2191603448,
      "ingressId": "Rmn6JEblRj95AMY",
      "entityId": 2191603450,
      "name": "招聘助手",
      "actions": [
        "view"
      ],
      "fields": {
        "name": {
          "fieldId": 1001,
          "label": "岗位名",
          "type": "text",
          "required": true
        },
        "department": {
          "fieldId": 1002,
          "label": "部门",
          "type": "text",
          "required": false
        },
        "jd": {
          "fieldId": 1003,
          "label": "岗位描述",
          "type": "textarea",
          "required": false
        },
        "owner": {
          "fieldId": 1006,
          "label": "岗位负责人",
          "type": "member",
          "required": false
        },
        "status": {
          "fieldId": 1007,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "grade": {
          "fieldId": 1008,
          "label": "岗位等级",
          "type": "text",
          "required": false
        },
        "headcount": {
          "fieldId": 1009,
          "label": "招聘人数",
          "type": "text",
          "required": false
        },
        "educationRequirement": {
          "fieldId": 1011,
          "label": "学历要求",
          "type": "text",
          "required": false
        },
        "experienceRequirement": {
          "fieldId": 1013,
          "label": "经验要求",
          "type": "text",
          "required": false
        },
        "remark": {
          "fieldId": 1015,
          "label": "备注",
          "type": "textarea",
          "required": false
        },
        "ageMin": {
          "fieldId": 1016,
          "label": "年龄下限",
          "type": "text",
          "required": false
        },
        "ageMax": {
          "fieldId": 1017,
          "label": "年龄上限",
          "type": "text",
          "required": false
        },
        "salaryMin": {
          "fieldId": 1018,
          "label": "薪资下限(K)",
          "type": "text",
          "required": false
        },
        "salaryMax": {
          "fieldId": 1019,
          "label": "薪资上限(K)",
          "type": "text",
          "required": false
        },
        "skillItems": {
          "fieldId": 1020,
          "label": "技能要求",
          "type": "subform",
          "required": false
        },
        "skillName": {
          "fieldId": 1021,
          "label": "技能名",
          "type": "text",
          "required": false
        }
      }
    },
    "ingress2191604536": {
      "appId": 2191603448,
      "ingressId": "1A76DrbRGLK34N0",
      "entityId": 2191603450,
      "name": "人事经理",
      "actions": [
        "view"
      ],
      "fields": {
        "name": {
          "fieldId": 1001,
          "label": "岗位名",
          "type": "text",
          "required": true
        },
        "department": {
          "fieldId": 1002,
          "label": "部门",
          "type": "text",
          "required": false
        },
        "jd": {
          "fieldId": 1003,
          "label": "岗位描述",
          "type": "textarea",
          "required": false
        },
        "owner": {
          "fieldId": 1006,
          "label": "岗位负责人",
          "type": "member",
          "required": false
        },
        "status": {
          "fieldId": 1007,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "grade": {
          "fieldId": 1008,
          "label": "岗位等级",
          "type": "text",
          "required": false
        },
        "headcount": {
          "fieldId": 1009,
          "label": "招聘人数",
          "type": "text",
          "required": false
        },
        "educationRequirement": {
          "fieldId": 1011,
          "label": "学历要求",
          "type": "text",
          "required": false
        },
        "experienceRequirement": {
          "fieldId": 1013,
          "label": "经验要求",
          "type": "text",
          "required": false
        },
        "remark": {
          "fieldId": 1015,
          "label": "备注",
          "type": "textarea",
          "required": false
        },
        "ageMin": {
          "fieldId": 1016,
          "label": "年龄下限",
          "type": "text",
          "required": false
        },
        "ageMax": {
          "fieldId": 1017,
          "label": "年龄上限",
          "type": "text",
          "required": false
        },
        "salaryMin": {
          "fieldId": 1018,
          "label": "薪资下限(K)",
          "type": "text",
          "required": false
        },
        "salaryMax": {
          "fieldId": 1019,
          "label": "薪资上限(K)",
          "type": "text",
          "required": false
        },
        "skillItems": {
          "fieldId": 1020,
          "label": "技能要求",
          "type": "subform",
          "required": false
        },
        "skillName": {
          "fieldId": 1021,
          "label": "技能名",
          "type": "text",
          "required": false
        }
      }
    },
    "devOperatorFullAccess2": {
      "appId": 2191603448,
      "ingressId": "98L5bJOKo2m5DgZ",
      "entityId": 2191603449,
      "name": "Dev operator full access",
      "actions": [
        "view",
        "add",
        "edit",
        "delete"
      ],
      "fields": {
        "proposer": {
          "fieldId": 1001,
          "label": "提出人",
          "type": "member",
          "required": true
        },
        "proposerRole": {
          "fieldId": 1002,
          "label": "提出人角色",
          "type": "select",
          "required": true
        },
        "department": {
          "fieldId": 1003,
          "label": "部门",
          "type": "text",
          "required": false
        },
        "jobTitle": {
          "fieldId": 1004,
          "label": "岗位",
          "type": "text",
          "required": true
        },
        "headcount": {
          "fieldId": 1005,
          "label": "招聘人数",
          "type": "number",
          "required": true
        },
        "expectedMonth": {
          "fieldId": 1006,
          "label": "期望到岗月",
          "type": "text",
          "required": false
        },
        "isKeyPosition": {
          "fieldId": 1007,
          "label": "关键岗位",
          "type": "boolean",
          "required": false
        },
        "status": {
          "fieldId": 1008,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "approver": {
          "fieldId": 1009,
          "label": "审批人",
          "type": "member",
          "required": false
        },
        "approvedAt": {
          "fieldId": 1010,
          "label": "审批时间",
          "type": "datetime",
          "required": false
        },
        "approvalComment": {
          "fieldId": 1011,
          "label": "审批意见",
          "type": "textarea",
          "required": false
        },
        "remark": {
          "fieldId": 1012,
          "label": "备注",
          "type": "textarea",
          "required": false
        },
        "departmentOwner": {
          "fieldId": 1013,
          "label": "部门负责人",
          "type": "member",
          "required": false
        }
      }
    },
    "ingress2191604531": {
      "appId": 2191603448,
      "ingressId": "NqwQnp8y4X45X0o",
      "entityId": 2191603449,
      "name": "人事专员",
      "actions": [
        "view",
        "add",
        "edit"
      ],
      "fields": {
        "proposer": {
          "fieldId": 1001,
          "label": "提出人",
          "type": "member",
          "required": true
        },
        "proposerRole": {
          "fieldId": 1002,
          "label": "提出人角色",
          "type": "select",
          "required": true
        },
        "department": {
          "fieldId": 1003,
          "label": "部门",
          "type": "text",
          "required": false
        },
        "jobTitle": {
          "fieldId": 1004,
          "label": "岗位",
          "type": "text",
          "required": true
        },
        "headcount": {
          "fieldId": 1005,
          "label": "招聘人数",
          "type": "number",
          "required": true
        },
        "expectedMonth": {
          "fieldId": 1006,
          "label": "期望到岗月",
          "type": "text",
          "required": false
        },
        "isKeyPosition": {
          "fieldId": 1007,
          "label": "关键岗位",
          "type": "boolean",
          "required": false
        },
        "status": {
          "fieldId": 1008,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "approver": {
          "fieldId": 1009,
          "label": "审批人",
          "type": "member",
          "required": false
        },
        "approvedAt": {
          "fieldId": 1010,
          "label": "审批时间",
          "type": "datetime",
          "required": false
        },
        "approvalComment": {
          "fieldId": 1011,
          "label": "审批意见",
          "type": "textarea",
          "required": false
        },
        "remark": {
          "fieldId": 1012,
          "label": "备注",
          "type": "textarea",
          "required": false
        },
        "departmentOwner": {
          "fieldId": 1013,
          "label": "部门负责人",
          "type": "member",
          "required": false
        }
      }
    },
    "ingress2191604532": {
      "appId": 2191603448,
      "ingressId": "1EJ6p9W2Kv7QYVD",
      "entityId": 2191603449,
      "name": "人事经理",
      "actions": [
        "view",
        "edit"
      ],
      "fields": {
        "proposer": {
          "fieldId": 1001,
          "label": "提出人",
          "type": "member",
          "required": true
        },
        "proposerRole": {
          "fieldId": 1002,
          "label": "提出人角色",
          "type": "select",
          "required": true
        },
        "department": {
          "fieldId": 1003,
          "label": "部门",
          "type": "text",
          "required": false
        },
        "jobTitle": {
          "fieldId": 1004,
          "label": "岗位",
          "type": "text",
          "required": true
        },
        "headcount": {
          "fieldId": 1005,
          "label": "招聘人数",
          "type": "number",
          "required": true
        },
        "expectedMonth": {
          "fieldId": 1006,
          "label": "期望到岗月",
          "type": "text",
          "required": false
        },
        "isKeyPosition": {
          "fieldId": 1007,
          "label": "关键岗位",
          "type": "boolean",
          "required": false
        },
        "status": {
          "fieldId": 1008,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "approver": {
          "fieldId": 1009,
          "label": "审批人",
          "type": "member",
          "required": false
        },
        "approvedAt": {
          "fieldId": 1010,
          "label": "审批时间",
          "type": "datetime",
          "required": false
        },
        "approvalComment": {
          "fieldId": 1011,
          "label": "审批意见",
          "type": "textarea",
          "required": false
        },
        "remark": {
          "fieldId": 1012,
          "label": "备注",
          "type": "textarea",
          "required": false
        },
        "departmentOwner": {
          "fieldId": 1013,
          "label": "部门负责人",
          "type": "member",
          "required": false
        }
      }
    },
    "ingress2191604533": {
      "appId": 2191603448,
      "ingressId": "9ZN5Bw9ObeE6jwK",
      "entityId": 2191603449,
      "name": "部门领导",
      "actions": [
        "view",
        "add",
        "edit"
      ],
      "fields": {
        "proposer": {
          "fieldId": 1001,
          "label": "提出人",
          "type": "member",
          "required": true
        },
        "proposerRole": {
          "fieldId": 1002,
          "label": "提出人角色",
          "type": "select",
          "required": true
        },
        "department": {
          "fieldId": 1003,
          "label": "部门",
          "type": "text",
          "required": false
        },
        "jobTitle": {
          "fieldId": 1004,
          "label": "岗位",
          "type": "text",
          "required": true
        },
        "headcount": {
          "fieldId": 1005,
          "label": "招聘人数",
          "type": "number",
          "required": true
        },
        "expectedMonth": {
          "fieldId": 1006,
          "label": "期望到岗月",
          "type": "text",
          "required": false
        },
        "isKeyPosition": {
          "fieldId": 1007,
          "label": "关键岗位",
          "type": "boolean",
          "required": false
        },
        "status": {
          "fieldId": 1008,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "approver": {
          "fieldId": 1009,
          "label": "审批人",
          "type": "member",
          "required": false
        },
        "approvedAt": {
          "fieldId": 1010,
          "label": "审批时间",
          "type": "datetime",
          "required": false
        },
        "approvalComment": {
          "fieldId": 1011,
          "label": "审批意见",
          "type": "textarea",
          "required": false
        },
        "remark": {
          "fieldId": 1012,
          "label": "备注",
          "type": "textarea",
          "required": false
        },
        "departmentOwner": {
          "fieldId": 1013,
          "label": "部门负责人",
          "type": "member",
          "required": false
        }
      }
    },
    "ingress2191604534": {
      "appId": 2191603448,
      "ingressId": "pxD5mbMrexW6XOJ",
      "entityId": 2191603449,
      "name": "招聘助手",
      "actions": [
        "view"
      ],
      "fields": {
        "proposer": {
          "fieldId": 1001,
          "label": "提出人",
          "type": "member",
          "required": true
        },
        "proposerRole": {
          "fieldId": 1002,
          "label": "提出人角色",
          "type": "select",
          "required": true
        },
        "department": {
          "fieldId": 1003,
          "label": "部门",
          "type": "text",
          "required": false
        },
        "jobTitle": {
          "fieldId": 1004,
          "label": "岗位",
          "type": "text",
          "required": true
        },
        "headcount": {
          "fieldId": 1005,
          "label": "招聘人数",
          "type": "number",
          "required": true
        },
        "expectedMonth": {
          "fieldId": 1006,
          "label": "期望到岗月",
          "type": "text",
          "required": false
        },
        "isKeyPosition": {
          "fieldId": 1007,
          "label": "关键岗位",
          "type": "boolean",
          "required": false
        },
        "status": {
          "fieldId": 1008,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "approver": {
          "fieldId": 1009,
          "label": "审批人",
          "type": "member",
          "required": false
        },
        "approvedAt": {
          "fieldId": 1010,
          "label": "审批时间",
          "type": "datetime",
          "required": false
        },
        "approvalComment": {
          "fieldId": 1011,
          "label": "审批意见",
          "type": "textarea",
          "required": false
        },
        "remark": {
          "fieldId": 1012,
          "label": "备注",
          "type": "textarea",
          "required": false
        },
        "departmentOwner": {
          "fieldId": 1013,
          "label": "部门负责人",
          "type": "member",
          "required": false
        }
      }
    },
    "ingress2191605111": {
      "appId": 2191603448,
      "ingressId": "7yPQ2bw2A7EQ9Kv",
      "entityId": 2191603449,
      "name": "招聘需求-管理员全权限",
      "actions": [
        "view",
        "add",
        "edit",
        "delete",
        "bulk_update",
        "archive"
      ],
      "fields": {
        "proposer": {
          "fieldId": 1001,
          "label": "提出人",
          "type": "member",
          "required": true
        },
        "proposerRole": {
          "fieldId": 1002,
          "label": "提出人角色",
          "type": "select",
          "required": true
        },
        "department": {
          "fieldId": 1003,
          "label": "部门",
          "type": "text",
          "required": false
        },
        "jobTitle": {
          "fieldId": 1004,
          "label": "岗位",
          "type": "text",
          "required": true
        },
        "headcount": {
          "fieldId": 1005,
          "label": "招聘人数",
          "type": "number",
          "required": true
        },
        "expectedMonth": {
          "fieldId": 1006,
          "label": "期望到岗月",
          "type": "text",
          "required": false
        },
        "isKeyPosition": {
          "fieldId": 1007,
          "label": "关键岗位",
          "type": "boolean",
          "required": false
        },
        "status": {
          "fieldId": 1008,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "approver": {
          "fieldId": 1009,
          "label": "审批人",
          "type": "member",
          "required": false
        },
        "approvedAt": {
          "fieldId": 1010,
          "label": "审批时间",
          "type": "datetime",
          "required": false
        },
        "approvalComment": {
          "fieldId": 1011,
          "label": "审批意见",
          "type": "textarea",
          "required": false
        },
        "remark": {
          "fieldId": 1012,
          "label": "备注",
          "type": "textarea",
          "required": false
        },
        "departmentOwner": {
          "fieldId": 1013,
          "label": "部门负责人",
          "type": "member",
          "required": false
        }
      }
    },
    "ingress2191605112": {
      "appId": 2191603448,
      "ingressId": "0yz3NAbrB4kQlGZ",
      "entityId": 2191603449,
      "name": "招聘专家-用人需求单读写权限",
      "actions": [
        "view",
        "add",
        "edit",
        "delete",
        "bulk_update"
      ],
      "fields": {
        "proposer": {
          "fieldId": 1001,
          "label": "提出人",
          "type": "member",
          "required": true
        },
        "proposerRole": {
          "fieldId": 1002,
          "label": "提出人角色",
          "type": "select",
          "required": true
        },
        "department": {
          "fieldId": 1003,
          "label": "部门",
          "type": "text",
          "required": false
        },
        "jobTitle": {
          "fieldId": 1004,
          "label": "岗位",
          "type": "text",
          "required": true
        },
        "headcount": {
          "fieldId": 1005,
          "label": "招聘人数",
          "type": "number",
          "required": true
        },
        "expectedMonth": {
          "fieldId": 1006,
          "label": "期望到岗月",
          "type": "text",
          "required": false
        },
        "isKeyPosition": {
          "fieldId": 1007,
          "label": "关键岗位",
          "type": "boolean",
          "required": false
        },
        "status": {
          "fieldId": 1008,
          "label": "状态",
          "type": "select",
          "required": true
        },
        "approver": {
          "fieldId": 1009,
          "label": "审批人",
          "type": "member",
          "required": false
        },
        "approvedAt": {
          "fieldId": 1010,
          "label": "审批时间",
          "type": "datetime",
          "required": false
        },
        "approvalComment": {
          "fieldId": 1011,
          "label": "审批意见",
          "type": "textarea",
          "required": false
        },
        "remark": {
          "fieldId": 1012,
          "label": "备注",
          "type": "textarea",
          "required": false
        },
        "departmentOwner": {
          "fieldId": 1013,
          "label": "部门负责人",
          "type": "member",
          "required": false
        }
      }
    }
  }
} as const

export type ArcubaseIngressKey = keyof typeof arcubaseSchema.ingresses
