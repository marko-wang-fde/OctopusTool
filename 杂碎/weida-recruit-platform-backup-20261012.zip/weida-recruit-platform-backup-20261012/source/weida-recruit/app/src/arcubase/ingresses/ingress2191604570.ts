import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604570FieldKey = 'pipelineId' | 'amount' | 'note' | 'status' | 'finalAmount' | 'approver' | 'approvedAt' | 'approvalComment'

export type Ingress2191604570Fields = {
  pipelineId: string
  amount?: number
  note?: string
  status: number | string
  finalAmount?: number
  approver?: unknown
  approvedAt?: string
  approvalComment?: string
}

export type Ingress2191604570CreateInput = Ingress2191604570Fields
export type Ingress2191604570UpdateInput = Partial<Ingress2191604570Fields>
export type Ingress2191604570Action = 'view' | 'edit'
export type Ingress2191604570CustomAction = never

export type Ingress2191604570Sort = {
  column: Ingress2191604570FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604570QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604570Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604570Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604570Sort[]
}

export type Ingress2191604570BulkUpdateField = {
  key: Ingress2191604570FieldKey
  action: Record<string, any>
}

export type Ingress2191604570ExportOptions = {
  fields?: Ingress2191604570FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "gWr34brLgjy6v1y"
const fieldIds = {
  pipelineId: 1001,
  amount: 1002,
  note: 1003,
  status: 1004,
  finalAmount: 1005,
  approver: 1006,
  approvedAt: 1007,
  approvalComment: 1008,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604570Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604570Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604570Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604570Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604570QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604570Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603459/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604570Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603459/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async update(rowId: string | number, fields: Ingress2191604570UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603459/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },
  }
}
