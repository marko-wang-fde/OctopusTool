import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type DevOperatorFullAccess9FieldKey = 'interviewId' | 'result' | 'comment' | 'submittedBy' | 'submittedAt'

export type DevOperatorFullAccess9Fields = {
  interviewId: string
  result: number | string
  comment?: string
  submittedBy?: unknown
  submittedAt?: string
}

export type DevOperatorFullAccess9CreateInput = DevOperatorFullAccess9Fields
export type DevOperatorFullAccess9UpdateInput = Partial<DevOperatorFullAccess9Fields>
export type DevOperatorFullAccess9Action = 'view' | 'add' | 'edit' | 'delete'
export type DevOperatorFullAccess9CustomAction = never

export type DevOperatorFullAccess9Sort = {
  column: DevOperatorFullAccess9FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type DevOperatorFullAccess9QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: DevOperatorFullAccess9Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type DevOperatorFullAccess9Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: DevOperatorFullAccess9Sort[]
}

export type DevOperatorFullAccess9BulkUpdateField = {
  key: DevOperatorFullAccess9FieldKey
  action: Record<string, any>
}

export type DevOperatorFullAccess9ExportOptions = {
  fields?: DevOperatorFullAccess9FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "8WR5KzKAYLx3K20"
const fieldIds = {
  interviewId: 1001,
  result: 1002,
  comment: 1003,
  submittedBy: 1004,
  submittedAt: 1005,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<DevOperatorFullAccess9Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<DevOperatorFullAccess9Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: DevOperatorFullAccess9Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createDevOperatorFullAccess9Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: DevOperatorFullAccess9QueryParams = {}): Promise<{ items: ArcubaseRow<DevOperatorFullAccess9Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603456/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<DevOperatorFullAccess9Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603456/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603456/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: DevOperatorFullAccess9CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603456/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: DevOperatorFullAccess9UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603456/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },

    async delete(selection: DevOperatorFullAccess9Selection): Promise<{ deleted?: number } | boolean> {
      return runtime.request<{ deleted?: number } | boolean>('POST', `/entity/2191603448/2191603456/delete-item`, {
        policy_id: ingressId,
        selection: toArcubaseSelection(selection),
      })
    },
  }
}
