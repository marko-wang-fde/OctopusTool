import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604579FieldKey = 'type' | 'refType' | 'refId' | 'target' | 'channel' | 'plannedAt' | 'status' | 'resendCount'

export type Ingress2191604579Fields = {
  type: number | string
  refType?: number | string
  refId?: string
  target?: unknown
  channel?: number | string
  plannedAt?: string
  status: number | string
  resendCount?: number
}

export type Ingress2191604579CreateInput = Ingress2191604579Fields
export type Ingress2191604579UpdateInput = Partial<Ingress2191604579Fields>
export type Ingress2191604579Action = 'view' | 'edit'
export type Ingress2191604579CustomAction = never

export type Ingress2191604579Sort = {
  column: Ingress2191604579FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604579QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604579Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604579Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604579Sort[]
}

export type Ingress2191604579BulkUpdateField = {
  key: Ingress2191604579FieldKey
  action: Record<string, any>
}

export type Ingress2191604579ExportOptions = {
  fields?: Ingress2191604579FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "Lol5Pg7ZPan34ZV"
const fieldIds = {
  type: 1001,
  refType: 1002,
  refId: 1003,
  target: 1004,
  channel: 1005,
  plannedAt: 1006,
  status: 1007,
  resendCount: 1008,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604579Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604579Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604579Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604579Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604579QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604579Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603462/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604579Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603462/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async update(rowId: string | number, fields: Ingress2191604579UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603462/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },
  }
}
