import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604576FieldKey = 'pipelineId' | 'result' | 'checkedBy' | 'checkedAt' | 'remark'

export type Ingress2191604576Fields = {
  pipelineId: string
  result: number | string
  checkedBy?: unknown
  checkedAt?: string
  remark?: string
}

export type Ingress2191604576CreateInput = Ingress2191604576Fields
export type Ingress2191604576UpdateInput = Partial<Ingress2191604576Fields>
export type Ingress2191604576Action = 'view'
export type Ingress2191604576CustomAction = never

export type Ingress2191604576Sort = {
  column: Ingress2191604576FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604576QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604576Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604576Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604576Sort[]
}

export type Ingress2191604576BulkUpdateField = {
  key: Ingress2191604576FieldKey
  action: Record<string, any>
}

export type Ingress2191604576ExportOptions = {
  fields?: Ingress2191604576FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "1EJ6p9W2Kp7QYVD"
const fieldIds = {
  pipelineId: 1001,
  result: 1002,
  checkedBy: 1003,
  checkedAt: 1004,
  remark: 1005,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604576Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604576Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604576Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604576Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604576QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604576Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603461/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604576Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603461/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },
  }
}
