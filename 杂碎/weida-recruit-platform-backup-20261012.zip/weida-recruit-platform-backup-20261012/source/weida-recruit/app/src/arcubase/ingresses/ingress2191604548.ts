import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604548FieldKey = 'pipelineId' | 'tier' | 'score' | 'details' | 'source' | 'matchedAt'

export type Ingress2191604548Fields = {
  pipelineId: string
  tier: number | string
  score?: number
  details?: string
  source?: number | string
  matchedAt?: string
}

export type Ingress2191604548CreateInput = Ingress2191604548Fields
export type Ingress2191604548UpdateInput = Partial<Ingress2191604548Fields>
export type Ingress2191604548Action = 'view' | 'delete'
export type Ingress2191604548CustomAction = never

export type Ingress2191604548Sort = {
  column: Ingress2191604548FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604548QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604548Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604548Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604548Sort[]
}

export type Ingress2191604548BulkUpdateField = {
  key: Ingress2191604548FieldKey
  action: Record<string, any>
}

export type Ingress2191604548ExportOptions = {
  fields?: Ingress2191604548FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "dbg6lvag12a3NaL"
const fieldIds = {
  pipelineId: 1001,
  tier: 1002,
  score: 1003,
  details: 1004,
  source: 1005,
  matchedAt: 1006,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604548Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604548Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604548Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604548Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604548QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604548Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603453/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604548Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603453/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async delete(selection: Ingress2191604548Selection): Promise<{ deleted?: number } | boolean> {
      return runtime.request<{ deleted?: number } | boolean>('POST', `/entity/2191603448/2191603453/delete-item`, {
        policy_id: ingressId,
        selection: toArcubaseSelection(selection),
      })
    },
  }
}
