import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604572FieldKey = 'pipelineId' | 'status' | 'markedBy' | 'markedAt'

export type Ingress2191604572Fields = {
  pipelineId: string
  status: number | string
  markedBy?: unknown
  markedAt?: string
}

export type Ingress2191604572CreateInput = Ingress2191604572Fields
export type Ingress2191604572UpdateInput = Partial<Ingress2191604572Fields>
export type Ingress2191604572Action = 'view'
export type Ingress2191604572CustomAction = never

export type Ingress2191604572Sort = {
  column: Ingress2191604572FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604572QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604572Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604572Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604572Sort[]
}

export type Ingress2191604572BulkUpdateField = {
  key: Ingress2191604572FieldKey
  action: Record<string, any>
}

export type Ingress2191604572ExportOptions = {
  fields?: Ingress2191604572FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "8WR5KzKAkmx3K20"
const fieldIds = {
  pipelineId: 1001,
  status: 1002,
  markedBy: 1003,
  markedAt: 1004,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604572Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604572Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604572Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604572Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604572QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604572Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603460/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604572Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603460/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },
  }
}
