import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type OfferFieldKey = 'resumeId' | 'demandId' | 'currentStage' | 'stageTs' | 'startedAt'

export type OfferFields = {
  resumeId: string
  demandId: string
  currentStage: number | string
  stageTs?: string
  startedAt: string
}

export type OfferCreateInput = OfferFields
export type OfferUpdateInput = Partial<OfferFields>
export type OfferAction = 'view'
export type OfferCustomAction = never

export type OfferSort = {
  column: OfferFieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type OfferQueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: OfferSort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type OfferSelection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: OfferSort[]
}

export type OfferBulkUpdateField = {
  key: OfferFieldKey
  action: Record<string, any>
}

export type OfferExportOptions = {
  fields?: OfferFieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "eDO6zOXbJA1QMdx"
const fieldIds = {
  resumeId: 1001,
  demandId: 1002,
  currentStage: 1003,
  stageTs: 1004,
  startedAt: 1005,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<OfferFields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<OfferFields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: OfferSelection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createOfferIngress(runtime: ArcubaseRuntime) {
  return {
    async query(params: OfferQueryParams = {}): Promise<{ items: ArcubaseRow<OfferFields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603452/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<OfferFields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603452/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },
  }
}
