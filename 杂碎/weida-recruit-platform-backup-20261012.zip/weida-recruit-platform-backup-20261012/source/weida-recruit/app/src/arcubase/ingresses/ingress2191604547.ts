import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604547FieldKey = 'resumeId' | 'demandId' | 'currentStage' | 'stageTs' | 'startedAt'

export type Ingress2191604547Fields = {
  resumeId: string
  demandId: string
  currentStage: number | string
  stageTs?: string
  startedAt: string
}

export type Ingress2191604547CreateInput = Ingress2191604547Fields
export type Ingress2191604547UpdateInput = Partial<Ingress2191604547Fields>
export type Ingress2191604547Action = 'view' | 'add' | 'edit'
export type Ingress2191604547CustomAction = never

export type Ingress2191604547Sort = {
  column: Ingress2191604547FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604547QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604547Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604547Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604547Sort[]
}

export type Ingress2191604547BulkUpdateField = {
  key: Ingress2191604547FieldKey
  action: Record<string, any>
}

export type Ingress2191604547ExportOptions = {
  fields?: Ingress2191604547FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "AqV50Oly0Jv31kG"
const fieldIds = {
  resumeId: 1001,
  demandId: 1002,
  currentStage: 1003,
  stageTs: 1004,
  startedAt: 1005,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604547Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604547Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604547Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604547Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604547QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604547Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603452/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604547Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603452/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603452/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: Ingress2191604547CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603452/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: Ingress2191604547UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603452/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },
  }
}
