import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type DevOperatorFullAccess2FieldKey = 'proposer' | 'proposerRole' | 'department' | 'jobTitle' | 'headcount' | 'expectedMonth' | 'isKeyPosition' | 'status' | 'approver' | 'approvedAt' | 'approvalComment' | 'remark' | 'departmentOwner'

export type DevOperatorFullAccess2Fields = {
  proposer: unknown
  proposerRole: number | string
  department?: string
  jobTitle: string
  headcount: number
  expectedMonth?: string
  isKeyPosition?: boolean
  status: number | string
  approver?: unknown
  approvedAt?: string
  approvalComment?: string
  remark?: string
  departmentOwner?: unknown
}

export type DevOperatorFullAccess2CreateInput = DevOperatorFullAccess2Fields
export type DevOperatorFullAccess2UpdateInput = Partial<DevOperatorFullAccess2Fields>
export type DevOperatorFullAccess2Action = 'view' | 'add' | 'edit' | 'delete'
export type DevOperatorFullAccess2CustomAction = never

export type DevOperatorFullAccess2Sort = {
  column: DevOperatorFullAccess2FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type DevOperatorFullAccess2QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: DevOperatorFullAccess2Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type DevOperatorFullAccess2Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: DevOperatorFullAccess2Sort[]
}

export type DevOperatorFullAccess2BulkUpdateField = {
  key: DevOperatorFullAccess2FieldKey
  action: Record<string, any>
}

export type DevOperatorFullAccess2ExportOptions = {
  fields?: DevOperatorFullAccess2FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "98L5bJOKo2m5DgZ"
const fieldIds = {
  proposer: 1001,
  proposerRole: 1002,
  department: 1003,
  jobTitle: 1004,
  headcount: 1005,
  expectedMonth: 1006,
  isKeyPosition: 1007,
  status: 1008,
  approver: 1009,
  approvedAt: 1010,
  approvalComment: 1011,
  remark: 1012,
  departmentOwner: 1013,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<DevOperatorFullAccess2Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<DevOperatorFullAccess2Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: DevOperatorFullAccess2Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createDevOperatorFullAccess2Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: DevOperatorFullAccess2QueryParams = {}): Promise<{ items: ArcubaseRow<DevOperatorFullAccess2Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603449/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<DevOperatorFullAccess2Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603449/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603449/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: DevOperatorFullAccess2CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603449/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: DevOperatorFullAccess2UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603449/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },

    async delete(selection: DevOperatorFullAccess2Selection): Promise<{ deleted?: number } | boolean> {
      return runtime.request<{ deleted?: number } | boolean>('POST', `/entity/2191603448/2191603449/delete-item`, {
        policy_id: ingressId,
        selection: toArcubaseSelection(selection),
      })
    },
  }
}
