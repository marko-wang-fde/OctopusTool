import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type DevOperatorFullAccess7FieldKey = 'pipelineId' | 'recommender' | 'receiver' | 'aiSummary' | 'deptFeedback' | 'feedbackChannel' | 'feedbackAt'

export type DevOperatorFullAccess7Fields = {
  pipelineId: string
  recommender?: unknown
  receiver?: unknown
  aiSummary?: string
  deptFeedback?: number | string
  feedbackChannel?: number | string
  feedbackAt?: string
}

export type DevOperatorFullAccess7CreateInput = DevOperatorFullAccess7Fields
export type DevOperatorFullAccess7UpdateInput = Partial<DevOperatorFullAccess7Fields>
export type DevOperatorFullAccess7Action = 'view' | 'add' | 'edit' | 'delete'
export type DevOperatorFullAccess7CustomAction = never

export type DevOperatorFullAccess7Sort = {
  column: DevOperatorFullAccess7FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type DevOperatorFullAccess7QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: DevOperatorFullAccess7Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type DevOperatorFullAccess7Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: DevOperatorFullAccess7Sort[]
}

export type DevOperatorFullAccess7BulkUpdateField = {
  key: DevOperatorFullAccess7FieldKey
  action: Record<string, any>
}

export type DevOperatorFullAccess7ExportOptions = {
  fields?: DevOperatorFullAccess7FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "gWr34brLYoy6v1y"
const fieldIds = {
  pipelineId: 1001,
  recommender: 1002,
  receiver: 1003,
  aiSummary: 1004,
  deptFeedback: 1005,
  feedbackChannel: 1006,
  feedbackAt: 1007,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<DevOperatorFullAccess7Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<DevOperatorFullAccess7Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: DevOperatorFullAccess7Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createDevOperatorFullAccess7Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: DevOperatorFullAccess7QueryParams = {}): Promise<{ items: ArcubaseRow<DevOperatorFullAccess7Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603454/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<DevOperatorFullAccess7Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603454/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603454/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: DevOperatorFullAccess7CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603454/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: DevOperatorFullAccess7UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603454/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },

    async delete(selection: DevOperatorFullAccess7Selection): Promise<{ deleted?: number } | boolean> {
      return runtime.request<{ deleted?: number } | boolean>('POST', `/entity/2191603448/2191603454/delete-item`, {
        policy_id: ingressId,
        selection: toArcubaseSelection(selection),
      })
    },
  }
}
