import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type DevOperatorFullAccess14FieldKey = 'pipelineId' | 'result' | 'checkedBy' | 'checkedAt' | 'remark'

export type DevOperatorFullAccess14Fields = {
  pipelineId: string
  result: number | string
  checkedBy?: unknown
  checkedAt?: string
  remark?: string
}

export type DevOperatorFullAccess14CreateInput = DevOperatorFullAccess14Fields
export type DevOperatorFullAccess14UpdateInput = Partial<DevOperatorFullAccess14Fields>
export type DevOperatorFullAccess14Action = 'view' | 'add' | 'edit' | 'delete'
export type DevOperatorFullAccess14CustomAction = never

export type DevOperatorFullAccess14Sort = {
  column: DevOperatorFullAccess14FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type DevOperatorFullAccess14QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: DevOperatorFullAccess14Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type DevOperatorFullAccess14Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: DevOperatorFullAccess14Sort[]
}

export type DevOperatorFullAccess14BulkUpdateField = {
  key: DevOperatorFullAccess14FieldKey
  action: Record<string, any>
}

export type DevOperatorFullAccess14ExportOptions = {
  fields?: DevOperatorFullAccess14FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "9ZN5Bw9OYlE6jwK"
const fieldIds = {
  pipelineId: 1001,
  result: 1002,
  checkedBy: 1003,
  checkedAt: 1004,
  remark: 1005,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<DevOperatorFullAccess14Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<DevOperatorFullAccess14Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: DevOperatorFullAccess14Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createDevOperatorFullAccess14Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: DevOperatorFullAccess14QueryParams = {}): Promise<{ items: ArcubaseRow<DevOperatorFullAccess14Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603461/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<DevOperatorFullAccess14Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603461/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603461/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: DevOperatorFullAccess14CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603461/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: DevOperatorFullAccess14UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603461/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },

    async delete(selection: DevOperatorFullAccess14Selection): Promise<{ deleted?: number } | boolean> {
      return runtime.request<{ deleted?: number } | boolean>('POST', `/entity/2191603448/2191603461/delete-item`, {
        policy_id: ingressId,
        selection: toArcubaseSelection(selection),
      })
    },
  }
}
