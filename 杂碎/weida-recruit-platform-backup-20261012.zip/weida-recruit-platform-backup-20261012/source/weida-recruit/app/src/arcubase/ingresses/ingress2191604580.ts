import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604580FieldKey = 'type' | 'refType' | 'refId' | 'target' | 'channel' | 'plannedAt' | 'status' | 'resendCount'

export type Ingress2191604580Fields = {
  type: number | string
  refType?: number | string
  refId?: string
  target?: unknown
  channel?: number | string
  plannedAt?: string
  status: number | string
  resendCount?: number
}

export type Ingress2191604580CreateInput = Ingress2191604580Fields
export type Ingress2191604580UpdateInput = Partial<Ingress2191604580Fields>
export type Ingress2191604580Action = 'view'
export type Ingress2191604580CustomAction = never

export type Ingress2191604580Sort = {
  column: Ingress2191604580FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604580QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604580Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604580Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604580Sort[]
}

export type Ingress2191604580BulkUpdateField = {
  key: Ingress2191604580FieldKey
  action: Record<string, any>
}

export type Ingress2191604580ExportOptions = {
  fields?: Ingress2191604580FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "1A76DrbRG8K34N0"
const fieldIds = {
  type: 1001,
  refType: 1002,
  refId: 1003,
  target: 1004,
  channel: 1005,
  plannedAt: 1006,
  status: 1007,
  resendCount: 1008,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604580Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604580Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604580Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604580Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604580QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604580Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603462/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604580Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603462/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },
  }
}
