import { createRuntime, type ArcubaseClientConfig, type ArcubaseRuntime } from './runtime.js'
import { createIngress2191605786Ingress } from './ingresses/ingress2191605786.js'
import { createIngress2191605787Ingress } from './ingresses/ingress2191605787.js'
import { createIngress2191605788Ingress } from './ingresses/ingress2191605788.js'
import { createIngress2191605789Ingress } from './ingresses/ingress2191605789.js'
import { createDevOperatorFullAccess16Ingress } from './ingresses/devOperatorFullAccess16.js'
import { createDevOperatorFullAccessIngress } from './ingresses/devOperatorFullAccess.js'
import { createIngress2191604582Ingress } from './ingresses/ingress2191604582.js'
import { createIngress2191604583Ingress } from './ingresses/ingress2191604583.js'
import { createIngress2191604584Ingress } from './ingresses/ingress2191604584.js'
import { createDevOperatorFullAccess15Ingress } from './ingresses/devOperatorFullAccess15.js'
import { createIngress2191604579Ingress } from './ingresses/ingress2191604579.js'
import { createIngress2191604580Ingress } from './ingresses/ingress2191604580.js'
import { createIngress2191604581Ingress } from './ingresses/ingress2191604581.js'
import { createDevOperatorFullAccess14Ingress } from './ingresses/devOperatorFullAccess14.js'
import { createIngress2191604575Ingress } from './ingresses/ingress2191604575.js'
import { createIngress2191604576Ingress } from './ingresses/ingress2191604576.js'
import { createOffer3Ingress } from './ingresses/offer3.js'
import { createIngress2191604578Ingress } from './ingresses/ingress2191604578.js'
import { createDevOperatorFullAccess13Ingress } from './ingresses/devOperatorFullAccess13.js'
import { createIngress2191604571Ingress } from './ingresses/ingress2191604571.js'
import { createIngress2191604572Ingress } from './ingresses/ingress2191604572.js'
import { createOffer2Ingress } from './ingresses/offer2.js'
import { createIngress2191604574Ingress } from './ingresses/ingress2191604574.js'
import { createDevOperatorFullAccess12Ingress } from './ingresses/devOperatorFullAccess12.js'
import { createIngress2191604569Ingress } from './ingresses/ingress2191604569.js'
import { createIngress2191604570Ingress } from './ingresses/ingress2191604570.js'
import { createDevOperatorFullAccess11Ingress } from './ingresses/devOperatorFullAccess11.js'
import { createIngress2191604567Ingress } from './ingresses/ingress2191604567.js'
import { createIngress2191604568Ingress } from './ingresses/ingress2191604568.js'
import { createDevOperatorFullAccess10Ingress } from './ingresses/devOperatorFullAccess10.js'
import { createIngress2191604564Ingress } from './ingresses/ingress2191604564.js'
import { createIngress2191604565Ingress } from './ingresses/ingress2191604565.js'
import { createIngress2191604566Ingress } from './ingresses/ingress2191604566.js'
import { createDevOperatorFullAccess9Ingress } from './ingresses/devOperatorFullAccess9.js'
import { createIngress2191604560Ingress } from './ingresses/ingress2191604560.js'
import { createIngress2191604561Ingress } from './ingresses/ingress2191604561.js'
import { createIngress2191604562Ingress } from './ingresses/ingress2191604562.js'
import { createIngress2191604563Ingress } from './ingresses/ingress2191604563.js'
import { createDevOperatorFullAccess8Ingress } from './ingresses/devOperatorFullAccess8.js'
import { createIngress2191604556Ingress } from './ingresses/ingress2191604556.js'
import { createIngress2191604557Ingress } from './ingresses/ingress2191604557.js'
import { createIngress2191604558Ingress } from './ingresses/ingress2191604558.js'
import { createIngress2191604559Ingress } from './ingresses/ingress2191604559.js'
import { createDevOperatorFullAccess7Ingress } from './ingresses/devOperatorFullAccess7.js'
import { createIngress2191604552Ingress } from './ingresses/ingress2191604552.js'
import { createIngress2191604553Ingress } from './ingresses/ingress2191604553.js'
import { createIngress2191604554Ingress } from './ingresses/ingress2191604554.js'
import { createIngress2191604555Ingress } from './ingresses/ingress2191604555.js'
import { createDevOperatorFullAccess6Ingress } from './ingresses/devOperatorFullAccess6.js'
import { createIngress2191604548Ingress } from './ingresses/ingress2191604548.js'
import { createIngress2191604549Ingress } from './ingresses/ingress2191604549.js'
import { createIngress2191604550Ingress } from './ingresses/ingress2191604550.js'
import { createIngress2191604551Ingress } from './ingresses/ingress2191604551.js'
import { createDevOperatorFullAccess5Ingress } from './ingresses/devOperatorFullAccess5.js'
import { createIngress2191604543Ingress } from './ingresses/ingress2191604543.js'
import { createIngress2191604544Ingress } from './ingresses/ingress2191604544.js'
import { createIngress2191604545Ingress } from './ingresses/ingress2191604545.js'
import { createOfferIngress } from './ingresses/offer.js'
import { createIngress2191604547Ingress } from './ingresses/ingress2191604547.js'
import { createIngress2191753948Ingress } from './ingresses/ingress2191753948.js'
import { createDevOperatorFullAccess4Ingress } from './ingresses/devOperatorFullAccess4.js'
import { createIngress2191604539Ingress } from './ingresses/ingress2191604539.js'
import { createIngress2191604540Ingress } from './ingresses/ingress2191604540.js'
import { createIngress2191604541Ingress } from './ingresses/ingress2191604541.js'
import { createIngress2191604542Ingress } from './ingresses/ingress2191604542.js'
import { createDevOperatorFullAccess3Ingress } from './ingresses/devOperatorFullAccess3.js'
import { createIngress2191604535Ingress } from './ingresses/ingress2191604535.js'
import { createIngress2191604537Ingress } from './ingresses/ingress2191604537.js'
import { createIngress2191604538Ingress } from './ingresses/ingress2191604538.js'
import { createIngress2191604536Ingress } from './ingresses/ingress2191604536.js'
import { createDevOperatorFullAccess2Ingress } from './ingresses/devOperatorFullAccess2.js'
import { createIngress2191604531Ingress } from './ingresses/ingress2191604531.js'
import { createIngress2191604532Ingress } from './ingresses/ingress2191604532.js'
import { createIngress2191604533Ingress } from './ingresses/ingress2191604533.js'
import { createIngress2191604534Ingress } from './ingresses/ingress2191604534.js'
import { createIngress2191605111Ingress } from './ingresses/ingress2191605111.js'
import { createIngress2191605112Ingress } from './ingresses/ingress2191605112.js'

export type ArcubaseIngressMap = {
  "ingress2191605786": ReturnType<typeof createIngress2191605786Ingress>
  "ingress2191605787": ReturnType<typeof createIngress2191605787Ingress>
  "ingress2191605788": ReturnType<typeof createIngress2191605788Ingress>
  "ingress2191605789": ReturnType<typeof createIngress2191605789Ingress>
  "devOperatorFullAccess16": ReturnType<typeof createDevOperatorFullAccess16Ingress>
  "devOperatorFullAccess": ReturnType<typeof createDevOperatorFullAccessIngress>
  "ingress2191604582": ReturnType<typeof createIngress2191604582Ingress>
  "ingress2191604583": ReturnType<typeof createIngress2191604583Ingress>
  "ingress2191604584": ReturnType<typeof createIngress2191604584Ingress>
  "devOperatorFullAccess15": ReturnType<typeof createDevOperatorFullAccess15Ingress>
  "ingress2191604579": ReturnType<typeof createIngress2191604579Ingress>
  "ingress2191604580": ReturnType<typeof createIngress2191604580Ingress>
  "ingress2191604581": ReturnType<typeof createIngress2191604581Ingress>
  "devOperatorFullAccess14": ReturnType<typeof createDevOperatorFullAccess14Ingress>
  "ingress2191604575": ReturnType<typeof createIngress2191604575Ingress>
  "ingress2191604576": ReturnType<typeof createIngress2191604576Ingress>
  "offer3": ReturnType<typeof createOffer3Ingress>
  "ingress2191604578": ReturnType<typeof createIngress2191604578Ingress>
  "devOperatorFullAccess13": ReturnType<typeof createDevOperatorFullAccess13Ingress>
  "ingress2191604571": ReturnType<typeof createIngress2191604571Ingress>
  "ingress2191604572": ReturnType<typeof createIngress2191604572Ingress>
  "offer2": ReturnType<typeof createOffer2Ingress>
  "ingress2191604574": ReturnType<typeof createIngress2191604574Ingress>
  "devOperatorFullAccess12": ReturnType<typeof createDevOperatorFullAccess12Ingress>
  "ingress2191604569": ReturnType<typeof createIngress2191604569Ingress>
  "ingress2191604570": ReturnType<typeof createIngress2191604570Ingress>
  "devOperatorFullAccess11": ReturnType<typeof createDevOperatorFullAccess11Ingress>
  "ingress2191604567": ReturnType<typeof createIngress2191604567Ingress>
  "ingress2191604568": ReturnType<typeof createIngress2191604568Ingress>
  "devOperatorFullAccess10": ReturnType<typeof createDevOperatorFullAccess10Ingress>
  "ingress2191604564": ReturnType<typeof createIngress2191604564Ingress>
  "ingress2191604565": ReturnType<typeof createIngress2191604565Ingress>
  "ingress2191604566": ReturnType<typeof createIngress2191604566Ingress>
  "devOperatorFullAccess9": ReturnType<typeof createDevOperatorFullAccess9Ingress>
  "ingress2191604560": ReturnType<typeof createIngress2191604560Ingress>
  "ingress2191604561": ReturnType<typeof createIngress2191604561Ingress>
  "ingress2191604562": ReturnType<typeof createIngress2191604562Ingress>
  "ingress2191604563": ReturnType<typeof createIngress2191604563Ingress>
  "devOperatorFullAccess8": ReturnType<typeof createDevOperatorFullAccess8Ingress>
  "ingress2191604556": ReturnType<typeof createIngress2191604556Ingress>
  "ingress2191604557": ReturnType<typeof createIngress2191604557Ingress>
  "ingress2191604558": ReturnType<typeof createIngress2191604558Ingress>
  "ingress2191604559": ReturnType<typeof createIngress2191604559Ingress>
  "devOperatorFullAccess7": ReturnType<typeof createDevOperatorFullAccess7Ingress>
  "ingress2191604552": ReturnType<typeof createIngress2191604552Ingress>
  "ingress2191604553": ReturnType<typeof createIngress2191604553Ingress>
  "ingress2191604554": ReturnType<typeof createIngress2191604554Ingress>
  "ingress2191604555": ReturnType<typeof createIngress2191604555Ingress>
  "devOperatorFullAccess6": ReturnType<typeof createDevOperatorFullAccess6Ingress>
  "ingress2191604548": ReturnType<typeof createIngress2191604548Ingress>
  "ingress2191604549": ReturnType<typeof createIngress2191604549Ingress>
  "ingress2191604550": ReturnType<typeof createIngress2191604550Ingress>
  "ingress2191604551": ReturnType<typeof createIngress2191604551Ingress>
  "devOperatorFullAccess5": ReturnType<typeof createDevOperatorFullAccess5Ingress>
  "ingress2191604543": ReturnType<typeof createIngress2191604543Ingress>
  "ingress2191604544": ReturnType<typeof createIngress2191604544Ingress>
  "ingress2191604545": ReturnType<typeof createIngress2191604545Ingress>
  "offer": ReturnType<typeof createOfferIngress>
  "ingress2191604547": ReturnType<typeof createIngress2191604547Ingress>
  "ingress2191753948": ReturnType<typeof createIngress2191753948Ingress>
  "devOperatorFullAccess4": ReturnType<typeof createDevOperatorFullAccess4Ingress>
  "ingress2191604539": ReturnType<typeof createIngress2191604539Ingress>
  "ingress2191604540": ReturnType<typeof createIngress2191604540Ingress>
  "ingress2191604541": ReturnType<typeof createIngress2191604541Ingress>
  "ingress2191604542": ReturnType<typeof createIngress2191604542Ingress>
  "devOperatorFullAccess3": ReturnType<typeof createDevOperatorFullAccess3Ingress>
  "ingress2191604535": ReturnType<typeof createIngress2191604535Ingress>
  "ingress2191604537": ReturnType<typeof createIngress2191604537Ingress>
  "ingress2191604538": ReturnType<typeof createIngress2191604538Ingress>
  "ingress2191604536": ReturnType<typeof createIngress2191604536Ingress>
  "devOperatorFullAccess2": ReturnType<typeof createDevOperatorFullAccess2Ingress>
  "ingress2191604531": ReturnType<typeof createIngress2191604531Ingress>
  "ingress2191604532": ReturnType<typeof createIngress2191604532Ingress>
  "ingress2191604533": ReturnType<typeof createIngress2191604533Ingress>
  "ingress2191604534": ReturnType<typeof createIngress2191604534Ingress>
  "ingress2191605111": ReturnType<typeof createIngress2191605111Ingress>
  "ingress2191605112": ReturnType<typeof createIngress2191605112Ingress>
}

export type ArcubaseIngressKey = keyof ArcubaseIngressMap

export function createArcubaseClientFromRuntime(runtime: ArcubaseRuntime) {
  return {
    ingress<K extends ArcubaseIngressKey>(key: K): ArcubaseIngressMap[K] {
      switch (key) {
        case "ingress2191605786":
          return createIngress2191605786Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191605787":
          return createIngress2191605787Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191605788":
          return createIngress2191605788Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191605789":
          return createIngress2191605789Ingress(runtime) as ArcubaseIngressMap[K]
        case "devOperatorFullAccess16":
          return createDevOperatorFullAccess16Ingress(runtime) as ArcubaseIngressMap[K]
        case "devOperatorFullAccess":
          return createDevOperatorFullAccessIngress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604582":
          return createIngress2191604582Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604583":
          return createIngress2191604583Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604584":
          return createIngress2191604584Ingress(runtime) as ArcubaseIngressMap[K]
        case "devOperatorFullAccess15":
          return createDevOperatorFullAccess15Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604579":
          return createIngress2191604579Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604580":
          return createIngress2191604580Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604581":
          return createIngress2191604581Ingress(runtime) as ArcubaseIngressMap[K]
        case "devOperatorFullAccess14":
          return createDevOperatorFullAccess14Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604575":
          return createIngress2191604575Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604576":
          return createIngress2191604576Ingress(runtime) as ArcubaseIngressMap[K]
        case "offer3":
          return createOffer3Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604578":
          return createIngress2191604578Ingress(runtime) as ArcubaseIngressMap[K]
        case "devOperatorFullAccess13":
          return createDevOperatorFullAccess13Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604571":
          return createIngress2191604571Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604572":
          return createIngress2191604572Ingress(runtime) as ArcubaseIngressMap[K]
        case "offer2":
          return createOffer2Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604574":
          return createIngress2191604574Ingress(runtime) as ArcubaseIngressMap[K]
        case "devOperatorFullAccess12":
          return createDevOperatorFullAccess12Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604569":
          return createIngress2191604569Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604570":
          return createIngress2191604570Ingress(runtime) as ArcubaseIngressMap[K]
        case "devOperatorFullAccess11":
          return createDevOperatorFullAccess11Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604567":
          return createIngress2191604567Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604568":
          return createIngress2191604568Ingress(runtime) as ArcubaseIngressMap[K]
        case "devOperatorFullAccess10":
          return createDevOperatorFullAccess10Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604564":
          return createIngress2191604564Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604565":
          return createIngress2191604565Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604566":
          return createIngress2191604566Ingress(runtime) as ArcubaseIngressMap[K]
        case "devOperatorFullAccess9":
          return createDevOperatorFullAccess9Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604560":
          return createIngress2191604560Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604561":
          return createIngress2191604561Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604562":
          return createIngress2191604562Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604563":
          return createIngress2191604563Ingress(runtime) as ArcubaseIngressMap[K]
        case "devOperatorFullAccess8":
          return createDevOperatorFullAccess8Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604556":
          return createIngress2191604556Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604557":
          return createIngress2191604557Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604558":
          return createIngress2191604558Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604559":
          return createIngress2191604559Ingress(runtime) as ArcubaseIngressMap[K]
        case "devOperatorFullAccess7":
          return createDevOperatorFullAccess7Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604552":
          return createIngress2191604552Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604553":
          return createIngress2191604553Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604554":
          return createIngress2191604554Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604555":
          return createIngress2191604555Ingress(runtime) as ArcubaseIngressMap[K]
        case "devOperatorFullAccess6":
          return createDevOperatorFullAccess6Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604548":
          return createIngress2191604548Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604549":
          return createIngress2191604549Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604550":
          return createIngress2191604550Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604551":
          return createIngress2191604551Ingress(runtime) as ArcubaseIngressMap[K]
        case "devOperatorFullAccess5":
          return createDevOperatorFullAccess5Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604543":
          return createIngress2191604543Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604544":
          return createIngress2191604544Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604545":
          return createIngress2191604545Ingress(runtime) as ArcubaseIngressMap[K]
        case "offer":
          return createOfferIngress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604547":
          return createIngress2191604547Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191753948":
          return createIngress2191753948Ingress(runtime) as ArcubaseIngressMap[K]
        case "devOperatorFullAccess4":
          return createDevOperatorFullAccess4Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604539":
          return createIngress2191604539Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604540":
          return createIngress2191604540Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604541":
          return createIngress2191604541Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604542":
          return createIngress2191604542Ingress(runtime) as ArcubaseIngressMap[K]
        case "devOperatorFullAccess3":
          return createDevOperatorFullAccess3Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604535":
          return createIngress2191604535Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604537":
          return createIngress2191604537Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604538":
          return createIngress2191604538Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604536":
          return createIngress2191604536Ingress(runtime) as ArcubaseIngressMap[K]
        case "devOperatorFullAccess2":
          return createDevOperatorFullAccess2Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604531":
          return createIngress2191604531Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604532":
          return createIngress2191604532Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604533":
          return createIngress2191604533Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191604534":
          return createIngress2191604534Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191605111":
          return createIngress2191605111Ingress(runtime) as ArcubaseIngressMap[K]
        case "ingress2191605112":
          return createIngress2191605112Ingress(runtime) as ArcubaseIngressMap[K]
        default:
          throw new Error(`Unknown Arcubase ingress: ${String(key)}`)
      }
    },
  }
}

export function createArcubaseClient(config: ArcubaseClientConfig) {
  return createArcubaseClientFromRuntime(createRuntime(config))
}
