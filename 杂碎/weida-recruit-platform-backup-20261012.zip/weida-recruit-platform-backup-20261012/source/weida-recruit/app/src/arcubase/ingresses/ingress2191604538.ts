import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604538FieldKey = 'name' | 'department' | 'jd' | 'owner' | 'status' | 'grade' | 'headcount' | 'educationRequirement' | 'experienceRequirement' | 'remark' | 'ageMin' | 'ageMax' | 'salaryMin' | 'salaryMax' | 'skillItems' | 'skillName'

export type Ingress2191604538Fields = {
  name: string
  department?: string
  jd?: string
  owner?: unknown
  status: number | string
  grade?: string
  headcount?: string
  educationRequirement?: string
  experienceRequirement?: string
  remark?: string
  ageMin?: string
  ageMax?: string
  salaryMin?: string
  salaryMax?: string
  skillItems?: unknown
  skillName?: string
}

export type Ingress2191604538CreateInput = Ingress2191604538Fields
export type Ingress2191604538UpdateInput = Partial<Ingress2191604538Fields>
export type Ingress2191604538Action = 'view'
export type Ingress2191604538CustomAction = never

export type Ingress2191604538Sort = {
  column: Ingress2191604538FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604538QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604538Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604538Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604538Sort[]
}

export type Ingress2191604538BulkUpdateField = {
  key: Ingress2191604538FieldKey
  action: Record<string, any>
}

export type Ingress2191604538ExportOptions = {
  fields?: Ingress2191604538FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "Rmn6JEblRj95AMY"
const fieldIds = {
  name: 1001,
  department: 1002,
  jd: 1003,
  owner: 1006,
  status: 1007,
  grade: 1008,
  headcount: 1009,
  educationRequirement: 1011,
  experienceRequirement: 1013,
  remark: 1015,
  ageMin: 1016,
  ageMax: 1017,
  salaryMin: 1018,
  salaryMax: 1019,
  skillItems: 1020,
  skillName: 1021,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604538Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604538Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604538Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604538Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604538QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604538Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603450/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604538Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603450/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },
  }
}
