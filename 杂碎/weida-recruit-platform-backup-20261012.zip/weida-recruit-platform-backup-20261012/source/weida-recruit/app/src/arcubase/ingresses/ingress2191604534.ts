import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604534FieldKey = 'proposer' | 'proposerRole' | 'department' | 'jobTitle' | 'headcount' | 'expectedMonth' | 'isKeyPosition' | 'status' | 'approver' | 'approvedAt' | 'approvalComment' | 'remark' | 'departmentOwner'

export type Ingress2191604534Fields = {
  proposer: unknown
  proposerRole: number | string
  department?: string
  jobTitle: string
  headcount: number
  expectedMonth?: string
  isKeyPosition?: boolean
  status: number | string
  approver?: unknown
  approvedAt?: string
  approvalComment?: string
  remark?: string
  departmentOwner?: unknown
}

export type Ingress2191604534CreateInput = Ingress2191604534Fields
export type Ingress2191604534UpdateInput = Partial<Ingress2191604534Fields>
export type Ingress2191604534Action = 'view'
export type Ingress2191604534CustomAction = never

export type Ingress2191604534Sort = {
  column: Ingress2191604534FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604534QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604534Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604534Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604534Sort[]
}

export type Ingress2191604534BulkUpdateField = {
  key: Ingress2191604534FieldKey
  action: Record<string, any>
}

export type Ingress2191604534ExportOptions = {
  fields?: Ingress2191604534FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "pxD5mbMrexW6XOJ"
const fieldIds = {
  proposer: 1001,
  proposerRole: 1002,
  department: 1003,
  jobTitle: 1004,
  headcount: 1005,
  expectedMonth: 1006,
  isKeyPosition: 1007,
  status: 1008,
  approver: 1009,
  approvedAt: 1010,
  approvalComment: 1011,
  remark: 1012,
  departmentOwner: 1013,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604534Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604534Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604534Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604534Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604534QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604534Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603449/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604534Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603449/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },
  }
}
