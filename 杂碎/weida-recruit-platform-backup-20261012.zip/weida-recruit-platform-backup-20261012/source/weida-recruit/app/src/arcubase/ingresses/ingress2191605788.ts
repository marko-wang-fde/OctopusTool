import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191605788FieldKey = 'fileName' | 'logicalPath' | 'sizeBytes' | 'sha256' | 'batchId' | 'contentType' | 'status' | 'parseError' | 'resumeId' | 'uploadedBy' | 'uploadedAt'

export type Ingress2191605788Fields = {
  fileName: string
  logicalPath: string
  sizeBytes?: number
  sha256?: string
  batchId?: string
  contentType?: string
  status?: number | string
  parseError?: string
  resumeId?: string
  uploadedBy?: unknown
  uploadedAt?: string
}

export type Ingress2191605788CreateInput = Ingress2191605788Fields
export type Ingress2191605788UpdateInput = Partial<Ingress2191605788Fields>
export type Ingress2191605788Action = 'view'
export type Ingress2191605788CustomAction = never

export type Ingress2191605788Sort = {
  column: Ingress2191605788FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191605788QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191605788Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191605788Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191605788Sort[]
}

export type Ingress2191605788BulkUpdateField = {
  key: Ingress2191605788FieldKey
  action: Record<string, any>
}

export type Ingress2191605788ExportOptions = {
  fields?: Ingress2191605788FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "mAg57j2WZNd3jnx"
const fieldIds = {
  fileName: 1001,
  logicalPath: 1002,
  sizeBytes: 1003,
  sha256: 1004,
  batchId: 1005,
  contentType: 1006,
  status: 1007,
  parseError: 1008,
  resumeId: 1009,
  uploadedBy: 1010,
  uploadedAt: 1011,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191605788Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191605788Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191605788Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191605788Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191605788QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191605788Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191605785/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191605788Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191605785/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },
  }
}
