import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604571FieldKey = 'pipelineId' | 'status' | 'markedBy' | 'markedAt'

export type Ingress2191604571Fields = {
  pipelineId: string
  status: number | string
  markedBy?: unknown
  markedAt?: string
}

export type Ingress2191604571CreateInput = Ingress2191604571Fields
export type Ingress2191604571UpdateInput = Partial<Ingress2191604571Fields>
export type Ingress2191604571Action = 'view'
export type Ingress2191604571CustomAction = never

export type Ingress2191604571Sort = {
  column: Ingress2191604571FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604571QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604571Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604571Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604571Sort[]
}

export type Ingress2191604571BulkUpdateField = {
  key: Ingress2191604571FieldKey
  action: Record<string, any>
}

export type Ingress2191604571ExportOptions = {
  fields?: Ingress2191604571FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "lA03OwpymOM3eKJ"
const fieldIds = {
  pipelineId: 1001,
  status: 1002,
  markedBy: 1003,
  markedAt: 1004,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604571Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604571Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604571Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604571Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604571QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604571Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603460/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604571Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603460/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },
  }
}
