import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604575FieldKey = 'pipelineId' | 'result' | 'checkedBy' | 'checkedAt' | 'remark'

export type Ingress2191604575Fields = {
  pipelineId: string
  result: number | string
  checkedBy?: unknown
  checkedAt?: string
  remark?: string
}

export type Ingress2191604575CreateInput = Ingress2191604575Fields
export type Ingress2191604575UpdateInput = Partial<Ingress2191604575Fields>
export type Ingress2191604575Action = 'view' | 'add' | 'edit'
export type Ingress2191604575CustomAction = never

export type Ingress2191604575Sort = {
  column: Ingress2191604575FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604575QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604575Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604575Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604575Sort[]
}

export type Ingress2191604575BulkUpdateField = {
  key: Ingress2191604575FieldKey
  action: Record<string, any>
}

export type Ingress2191604575ExportOptions = {
  fields?: Ingress2191604575FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "NqwQnp8y4L45X0o"
const fieldIds = {
  pipelineId: 1001,
  result: 1002,
  checkedBy: 1003,
  checkedAt: 1004,
  remark: 1005,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604575Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604575Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604575Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604575Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604575QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604575Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603461/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604575Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603461/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603461/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: Ingress2191604575CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603461/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: Ingress2191604575UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603461/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },
  }
}
