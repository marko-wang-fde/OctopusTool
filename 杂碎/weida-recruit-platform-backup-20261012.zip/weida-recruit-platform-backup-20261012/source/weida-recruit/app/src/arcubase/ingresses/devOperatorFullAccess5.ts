import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type DevOperatorFullAccess5FieldKey = 'resumeId' | 'demandId' | 'currentStage' | 'stageTs' | 'startedAt'

export type DevOperatorFullAccess5Fields = {
  resumeId: string
  demandId: string
  currentStage: number | string
  stageTs?: string
  startedAt: string
}

export type DevOperatorFullAccess5CreateInput = DevOperatorFullAccess5Fields
export type DevOperatorFullAccess5UpdateInput = Partial<DevOperatorFullAccess5Fields>
export type DevOperatorFullAccess5Action = 'view' | 'add' | 'edit' | 'delete'
export type DevOperatorFullAccess5CustomAction = never

export type DevOperatorFullAccess5Sort = {
  column: DevOperatorFullAccess5FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type DevOperatorFullAccess5QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: DevOperatorFullAccess5Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type DevOperatorFullAccess5Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: DevOperatorFullAccess5Sort[]
}

export type DevOperatorFullAccess5BulkUpdateField = {
  key: DevOperatorFullAccess5FieldKey
  action: Record<string, any>
}

export type DevOperatorFullAccess5ExportOptions = {
  fields?: DevOperatorFullAccess5FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "qORQ1bAZYqG3jmp"
const fieldIds = {
  resumeId: 1001,
  demandId: 1002,
  currentStage: 1003,
  stageTs: 1004,
  startedAt: 1005,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<DevOperatorFullAccess5Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<DevOperatorFullAccess5Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: DevOperatorFullAccess5Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createDevOperatorFullAccess5Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: DevOperatorFullAccess5QueryParams = {}): Promise<{ items: ArcubaseRow<DevOperatorFullAccess5Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603452/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<DevOperatorFullAccess5Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603452/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603452/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: DevOperatorFullAccess5CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603452/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: DevOperatorFullAccess5UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603452/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },

    async delete(selection: DevOperatorFullAccess5Selection): Promise<{ deleted?: number } | boolean> {
      return runtime.request<{ deleted?: number } | boolean>('POST', `/entity/2191603448/2191603452/delete-item`, {
        policy_id: ingressId,
        selection: toArcubaseSelection(selection),
      })
    },
  }
}
