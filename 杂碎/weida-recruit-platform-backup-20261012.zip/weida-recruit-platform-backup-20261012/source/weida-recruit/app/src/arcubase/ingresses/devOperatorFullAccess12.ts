import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type DevOperatorFullAccess12FieldKey = 'pipelineId' | 'amount' | 'note' | 'status' | 'finalAmount' | 'approver' | 'approvedAt' | 'approvalComment'

export type DevOperatorFullAccess12Fields = {
  pipelineId: string
  amount?: number
  note?: string
  status: number | string
  finalAmount?: number
  approver?: unknown
  approvedAt?: string
  approvalComment?: string
}

export type DevOperatorFullAccess12CreateInput = DevOperatorFullAccess12Fields
export type DevOperatorFullAccess12UpdateInput = Partial<DevOperatorFullAccess12Fields>
export type DevOperatorFullAccess12Action = 'view' | 'add' | 'edit' | 'delete'
export type DevOperatorFullAccess12CustomAction = never

export type DevOperatorFullAccess12Sort = {
  column: DevOperatorFullAccess12FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type DevOperatorFullAccess12QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: DevOperatorFullAccess12Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type DevOperatorFullAccess12Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: DevOperatorFullAccess12Sort[]
}

export type DevOperatorFullAccess12BulkUpdateField = {
  key: DevOperatorFullAccess12FieldKey
  action: Record<string, any>
}

export type DevOperatorFullAccess12ExportOptions = {
  fields?: DevOperatorFullAccess12FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "NqwQnp8yOG45X0o"
const fieldIds = {
  pipelineId: 1001,
  amount: 1002,
  note: 1003,
  status: 1004,
  finalAmount: 1005,
  approver: 1006,
  approvedAt: 1007,
  approvalComment: 1008,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<DevOperatorFullAccess12Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<DevOperatorFullAccess12Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: DevOperatorFullAccess12Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createDevOperatorFullAccess12Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: DevOperatorFullAccess12QueryParams = {}): Promise<{ items: ArcubaseRow<DevOperatorFullAccess12Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603459/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<DevOperatorFullAccess12Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603459/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603459/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: DevOperatorFullAccess12CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603459/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: DevOperatorFullAccess12UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603459/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },

    async delete(selection: DevOperatorFullAccess12Selection): Promise<{ deleted?: number } | boolean> {
      return runtime.request<{ deleted?: number } | boolean>('POST', `/entity/2191603448/2191603459/delete-item`, {
        policy_id: ingressId,
        selection: toArcubaseSelection(selection),
      })
    },
  }
}
