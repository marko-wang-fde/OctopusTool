import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604569FieldKey = 'pipelineId' | 'amount' | 'note' | 'status' | 'finalAmount' | 'approver' | 'approvedAt' | 'approvalComment'

export type Ingress2191604569Fields = {
  pipelineId: string
  amount?: number
  note?: string
  status: number | string
  finalAmount?: number
  approver?: unknown
  approvedAt?: string
  approvalComment?: string
}

export type Ingress2191604569CreateInput = Ingress2191604569Fields
export type Ingress2191604569UpdateInput = Partial<Ingress2191604569Fields>
export type Ingress2191604569Action = 'view' | 'add' | 'edit'
export type Ingress2191604569CustomAction = never

export type Ingress2191604569Sort = {
  column: Ingress2191604569FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604569QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604569Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604569Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604569Sort[]
}

export type Ingress2191604569BulkUpdateField = {
  key: Ingress2191604569FieldKey
  action: Record<string, any>
}

export type Ingress2191604569ExportOptions = {
  fields?: Ingress2191604569FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "zE93eOY7aBp62Vv"
const fieldIds = {
  pipelineId: 1001,
  amount: 1002,
  note: 1003,
  status: 1004,
  finalAmount: 1005,
  approver: 1006,
  approvedAt: 1007,
  approvalComment: 1008,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604569Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604569Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604569Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604569Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604569QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604569Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603459/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604569Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603459/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603459/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: Ingress2191604569CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603459/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: Ingress2191604569UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603459/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },
  }
}
