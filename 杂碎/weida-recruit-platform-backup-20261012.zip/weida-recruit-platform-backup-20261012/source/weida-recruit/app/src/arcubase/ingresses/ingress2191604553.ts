import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604553FieldKey = 'pipelineId' | 'recommender' | 'receiver' | 'aiSummary' | 'deptFeedback' | 'feedbackChannel' | 'feedbackAt'

export type Ingress2191604553Fields = {
  pipelineId: string
  recommender?: unknown
  receiver?: unknown
  aiSummary?: string
  deptFeedback?: number | string
  feedbackChannel?: number | string
  feedbackAt?: string
}

export type Ingress2191604553CreateInput = Ingress2191604553Fields
export type Ingress2191604553UpdateInput = Partial<Ingress2191604553Fields>
export type Ingress2191604553Action = 'view'
export type Ingress2191604553CustomAction = never

export type Ingress2191604553Sort = {
  column: Ingress2191604553FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604553QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604553Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604553Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604553Sort[]
}

export type Ingress2191604553BulkUpdateField = {
  key: Ingress2191604553FieldKey
  action: Record<string, any>
}

export type Ingress2191604553ExportOptions = {
  fields?: Ingress2191604553FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "WXB3yBRv8lN5veo"
const fieldIds = {
  pipelineId: 1001,
  recommender: 1002,
  receiver: 1003,
  aiSummary: 1004,
  deptFeedback: 1005,
  feedbackChannel: 1006,
  feedbackAt: 1007,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604553Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604553Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604553Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604553Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604553QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604553Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603454/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604553Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603454/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },
  }
}
