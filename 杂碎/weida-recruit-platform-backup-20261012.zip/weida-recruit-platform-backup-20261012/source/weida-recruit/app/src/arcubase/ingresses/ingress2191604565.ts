import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604565FieldKey = 'interviewId' | 'content' | 'attachment' | 'uploadedBy' | 'uploadedAt'

export type Ingress2191604565Fields = {
  interviewId: string
  content?: string
  attachment?: unknown
  uploadedBy?: unknown
  uploadedAt?: string
}

export type Ingress2191604565CreateInput = Ingress2191604565Fields
export type Ingress2191604565UpdateInput = Partial<Ingress2191604565Fields>
export type Ingress2191604565Action = 'view'
export type Ingress2191604565CustomAction = never

export type Ingress2191604565Sort = {
  column: Ingress2191604565FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604565QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604565Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604565Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604565Sort[]
}

export type Ingress2191604565BulkUpdateField = {
  key: Ingress2191604565FieldKey
  action: Record<string, any>
}

export type Ingress2191604565ExportOptions = {
  fields?: Ingress2191604565FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "98L5bJOK9Mm5DgZ"
const fieldIds = {
  interviewId: 1001,
  content: 1002,
  attachment: 1003,
  uploadedBy: 1004,
  uploadedAt: 1005,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604565Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604565Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604565Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604565Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604565QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604565Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603457/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604565Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603457/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },
  }
}
