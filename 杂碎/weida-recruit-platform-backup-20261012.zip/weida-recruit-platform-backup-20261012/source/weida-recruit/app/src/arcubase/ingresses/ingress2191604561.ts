import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604561FieldKey = 'interviewId' | 'result' | 'comment' | 'submittedBy' | 'submittedAt'

export type Ingress2191604561Fields = {
  interviewId: string
  result: number | string
  comment?: string
  submittedBy?: unknown
  submittedAt?: string
}

export type Ingress2191604561CreateInput = Ingress2191604561Fields
export type Ingress2191604561UpdateInput = Partial<Ingress2191604561Fields>
export type Ingress2191604561Action = 'view'
export type Ingress2191604561CustomAction = never

export type Ingress2191604561Sort = {
  column: Ingress2191604561FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604561QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604561Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604561Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604561Sort[]
}

export type Ingress2191604561BulkUpdateField = {
  key: Ingress2191604561FieldKey
  action: Record<string, any>
}

export type Ingress2191604561ExportOptions = {
  fields?: Ingress2191604561FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "91d3aoaOLMZ6WZr"
const fieldIds = {
  interviewId: 1001,
  result: 1002,
  comment: 1003,
  submittedBy: 1004,
  submittedAt: 1005,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604561Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604561Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604561Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604561Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604561QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604561Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603456/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604561Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603456/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },
  }
}
