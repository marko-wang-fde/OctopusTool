import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type DevOperatorFullAccess3FieldKey = 'name' | 'department' | 'jd' | 'hardRequirements' | 'pendingRule' | 'owner' | 'status'

export type DevOperatorFullAccess3Fields = {
  name: string
  department?: string
  jd?: string
  owner?: unknown
  status: number | string
  salaryMax?: string
  skillItems?: unknown
  skillName?: string
}

export type DevOperatorFullAccess3CreateInput = DevOperatorFullAccess3Fields
export type DevOperatorFullAccess3UpdateInput = Partial<DevOperatorFullAccess3Fields>
export type DevOperatorFullAccess3Action = 'view' | 'add' | 'edit' | 'delete'
export type DevOperatorFullAccess3CustomAction = never

export type DevOperatorFullAccess3Sort = {
  column: DevOperatorFullAccess3FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type DevOperatorFullAccess3QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: DevOperatorFullAccess3Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type DevOperatorFullAccess3Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: DevOperatorFullAccess3Sort[]
}

export type DevOperatorFullAccess3BulkUpdateField = {
  key: DevOperatorFullAccess3FieldKey
  action: Record<string, any>
}

export type DevOperatorFullAccess3ExportOptions = {
  fields?: DevOperatorFullAccess3FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "lg46jPpAGXN3OZ9"
const fieldIds = {
  name: 1001,
  department: 1002,
  jd: 1003,
  owner: 1006,
  status: 1007,
  grade: 1008,
  headcount: 1009,
  educationRequirement: 1011,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<DevOperatorFullAccess3Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<DevOperatorFullAccess3Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: DevOperatorFullAccess3Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createDevOperatorFullAccess3Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: DevOperatorFullAccess3QueryParams = {}): Promise<{ items: ArcubaseRow<DevOperatorFullAccess3Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603450/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<DevOperatorFullAccess3Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603450/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603450/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: DevOperatorFullAccess3CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603450/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: DevOperatorFullAccess3UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603450/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },

    async delete(selection: DevOperatorFullAccess3Selection): Promise<{ deleted?: number } | boolean> {
      return runtime.request<{ deleted?: number } | boolean>('POST', `/entity/2191603448/2191603450/delete-item`, {
        policy_id: ingressId,
        selection: toArcubaseSelection(selection),
      })
    },
  }
}
