import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type DevOperatorFullAccess6FieldKey = 'pipelineId' | 'tier' | 'score' | 'details' | 'source' | 'matchedAt'

export type DevOperatorFullAccess6Fields = {
  pipelineId: string
  tier: number | string
  score?: number
  details?: string
  source?: number | string
  matchedAt?: string
}

export type DevOperatorFullAccess6CreateInput = DevOperatorFullAccess6Fields
export type DevOperatorFullAccess6UpdateInput = Partial<DevOperatorFullAccess6Fields>
export type DevOperatorFullAccess6Action = 'view' | 'add' | 'edit' | 'delete'
export type DevOperatorFullAccess6CustomAction = never

export type DevOperatorFullAccess6Sort = {
  column: DevOperatorFullAccess6FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type DevOperatorFullAccess6QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: DevOperatorFullAccess6Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type DevOperatorFullAccess6Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: DevOperatorFullAccess6Sort[]
}

export type DevOperatorFullAccess6BulkUpdateField = {
  key: DevOperatorFullAccess6FieldKey
  action: Record<string, any>
}

export type DevOperatorFullAccess6ExportOptions = {
  fields?: DevOperatorFullAccess6FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "zE93eOY7V9p62Vv"
const fieldIds = {
  pipelineId: 1001,
  tier: 1002,
  score: 1003,
  details: 1004,
  source: 1005,
  matchedAt: 1006,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<DevOperatorFullAccess6Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<DevOperatorFullAccess6Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: DevOperatorFullAccess6Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createDevOperatorFullAccess6Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: DevOperatorFullAccess6QueryParams = {}): Promise<{ items: ArcubaseRow<DevOperatorFullAccess6Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603453/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<DevOperatorFullAccess6Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603453/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603453/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: DevOperatorFullAccess6CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603453/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: DevOperatorFullAccess6UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603453/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },

    async delete(selection: DevOperatorFullAccess6Selection): Promise<{ deleted?: number } | boolean> {
      return runtime.request<{ deleted?: number } | boolean>('POST', `/entity/2191603448/2191603453/delete-item`, {
        policy_id: ingressId,
        selection: toArcubaseSelection(selection),
      })
    },
  }
}
