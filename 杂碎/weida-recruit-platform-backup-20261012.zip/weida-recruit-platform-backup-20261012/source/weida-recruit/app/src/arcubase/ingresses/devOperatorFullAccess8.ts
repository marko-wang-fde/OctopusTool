import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type DevOperatorFullAccess8FieldKey = 'pipelineId' | 'round' | 'mode' | 'scheduledAt' | 'interviewer' | 'meetingNo' | 'status'

export type DevOperatorFullAccess8Fields = {
  pipelineId: string
  round: number
  mode?: number | string
  scheduledAt?: string
  interviewer?: unknown
  meetingNo?: string
  status: number | string
}

export type DevOperatorFullAccess8CreateInput = DevOperatorFullAccess8Fields
export type DevOperatorFullAccess8UpdateInput = Partial<DevOperatorFullAccess8Fields>
export type DevOperatorFullAccess8Action = 'view' | 'add' | 'edit' | 'delete'
export type DevOperatorFullAccess8CustomAction = never

export type DevOperatorFullAccess8Sort = {
  column: DevOperatorFullAccess8FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type DevOperatorFullAccess8QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: DevOperatorFullAccess8Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type DevOperatorFullAccess8Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: DevOperatorFullAccess8Sort[]
}

export type DevOperatorFullAccess8BulkUpdateField = {
  key: DevOperatorFullAccess8FieldKey
  action: Record<string, any>
}

export type DevOperatorFullAccess8ExportOptions = {
  fields?: DevOperatorFullAccess8FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "lA03OwpyYaM3eKJ"
const fieldIds = {
  pipelineId: 1001,
  round: 1002,
  mode: 1003,
  scheduledAt: 1004,
  interviewer: 1005,
  meetingNo: 1006,
  status: 1007,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<DevOperatorFullAccess8Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<DevOperatorFullAccess8Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: DevOperatorFullAccess8Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createDevOperatorFullAccess8Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: DevOperatorFullAccess8QueryParams = {}): Promise<{ items: ArcubaseRow<DevOperatorFullAccess8Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603455/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<DevOperatorFullAccess8Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603455/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603455/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: DevOperatorFullAccess8CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603455/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: DevOperatorFullAccess8UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603455/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },

    async delete(selection: DevOperatorFullAccess8Selection): Promise<{ deleted?: number } | boolean> {
      return runtime.request<{ deleted?: number } | boolean>('POST', `/entity/2191603448/2191603455/delete-item`, {
        policy_id: ingressId,
        selection: toArcubaseSelection(selection),
      })
    },
  }
}
