import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type DevOperatorFullAccess15FieldKey = 'type' | 'refType' | 'refId' | 'target' | 'channel' | 'plannedAt' | 'status' | 'resendCount'

export type DevOperatorFullAccess15Fields = {
  type: number | string
  refType?: number | string
  refId?: string
  target?: unknown
  channel?: number | string
  plannedAt?: string
  status: number | string
  resendCount?: number
}

export type DevOperatorFullAccess15CreateInput = DevOperatorFullAccess15Fields
export type DevOperatorFullAccess15UpdateInput = Partial<DevOperatorFullAccess15Fields>
export type DevOperatorFullAccess15Action = 'view' | 'add' | 'edit' | 'delete'
export type DevOperatorFullAccess15CustomAction = never

export type DevOperatorFullAccess15Sort = {
  column: DevOperatorFullAccess15FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type DevOperatorFullAccess15QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: DevOperatorFullAccess15Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type DevOperatorFullAccess15Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: DevOperatorFullAccess15Sort[]
}

export type DevOperatorFullAccess15BulkUpdateField = {
  key: DevOperatorFullAccess15FieldKey
  action: Record<string, any>
}

export type DevOperatorFullAccess15ExportOptions = {
  fields?: DevOperatorFullAccess15FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "pxD5mbMr4jW6XOJ"
const fieldIds = {
  type: 1001,
  refType: 1002,
  refId: 1003,
  target: 1004,
  channel: 1005,
  plannedAt: 1006,
  status: 1007,
  resendCount: 1008,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<DevOperatorFullAccess15Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<DevOperatorFullAccess15Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: DevOperatorFullAccess15Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createDevOperatorFullAccess15Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: DevOperatorFullAccess15QueryParams = {}): Promise<{ items: ArcubaseRow<DevOperatorFullAccess15Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603462/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<DevOperatorFullAccess15Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603462/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603462/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: DevOperatorFullAccess15CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603462/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: DevOperatorFullAccess15UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603462/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },

    async delete(selection: DevOperatorFullAccess15Selection): Promise<{ deleted?: number } | boolean> {
      return runtime.request<{ deleted?: number } | boolean>('POST', `/entity/2191603448/2191603462/delete-item`, {
        policy_id: ingressId,
        selection: toArcubaseSelection(selection),
      })
    },
  }
}
