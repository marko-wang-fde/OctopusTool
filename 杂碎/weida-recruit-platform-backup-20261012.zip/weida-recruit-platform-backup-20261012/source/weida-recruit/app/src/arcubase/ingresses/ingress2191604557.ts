import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604557FieldKey = 'pipelineId' | 'round' | 'mode' | 'scheduledAt' | 'interviewer' | 'meetingNo' | 'status'

export type Ingress2191604557Fields = {
  pipelineId: string
  round: number
  mode?: number | string
  scheduledAt?: string
  interviewer?: unknown
  meetingNo?: string
  status: number | string
}

export type Ingress2191604557CreateInput = Ingress2191604557Fields
export type Ingress2191604557UpdateInput = Partial<Ingress2191604557Fields>
export type Ingress2191604557Action = 'view'
export type Ingress2191604557CustomAction = never

export type Ingress2191604557Sort = {
  column: Ingress2191604557FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604557QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604557Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604557Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604557Sort[]
}

export type Ingress2191604557BulkUpdateField = {
  key: Ingress2191604557FieldKey
  action: Record<string, any>
}

export type Ingress2191604557ExportOptions = {
  fields?: Ingress2191604557FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "XWwQL0bwnOrQbl9"
const fieldIds = {
  pipelineId: 1001,
  round: 1002,
  mode: 1003,
  scheduledAt: 1004,
  interviewer: 1005,
  meetingNo: 1006,
  status: 1007,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604557Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604557Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604557Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604557Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604557QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604557Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603455/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604557Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603455/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },
  }
}
