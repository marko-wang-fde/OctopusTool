import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type DevOperatorFullAccess10FieldKey = 'interviewId' | 'content' | 'attachment' | 'uploadedBy' | 'uploadedAt'

export type DevOperatorFullAccess10Fields = {
  interviewId: string
  content?: string
  attachment?: unknown
  uploadedBy?: unknown
  uploadedAt?: string
}

export type DevOperatorFullAccess10CreateInput = DevOperatorFullAccess10Fields
export type DevOperatorFullAccess10UpdateInput = Partial<DevOperatorFullAccess10Fields>
export type DevOperatorFullAccess10Action = 'view' | 'add' | 'edit' | 'delete'
export type DevOperatorFullAccess10CustomAction = never

export type DevOperatorFullAccess10Sort = {
  column: DevOperatorFullAccess10FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type DevOperatorFullAccess10QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: DevOperatorFullAccess10Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type DevOperatorFullAccess10Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: DevOperatorFullAccess10Sort[]
}

export type DevOperatorFullAccess10BulkUpdateField = {
  key: DevOperatorFullAccess10FieldKey
  action: Record<string, any>
}

export type DevOperatorFullAccess10ExportOptions = {
  fields?: DevOperatorFullAccess10FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "n095RyzNYvg3yNA"
const fieldIds = {
  interviewId: 1001,
  content: 1002,
  attachment: 1003,
  uploadedBy: 1004,
  uploadedAt: 1005,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<DevOperatorFullAccess10Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<DevOperatorFullAccess10Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: DevOperatorFullAccess10Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createDevOperatorFullAccess10Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: DevOperatorFullAccess10QueryParams = {}): Promise<{ items: ArcubaseRow<DevOperatorFullAccess10Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603457/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<DevOperatorFullAccess10Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603457/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603457/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: DevOperatorFullAccess10CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603457/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: DevOperatorFullAccess10UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603457/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },

    async delete(selection: DevOperatorFullAccess10Selection): Promise<{ deleted?: number } | boolean> {
      return runtime.request<{ deleted?: number } | boolean>('POST', `/entity/2191603448/2191603457/delete-item`, {
        policy_id: ingressId,
        selection: toArcubaseSelection(selection),
      })
    },
  }
}
