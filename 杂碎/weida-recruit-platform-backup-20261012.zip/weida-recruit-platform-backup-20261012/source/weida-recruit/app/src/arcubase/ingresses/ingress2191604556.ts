import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604556FieldKey = 'pipelineId' | 'round' | 'mode' | 'scheduledAt' | 'interviewer' | 'meetingNo' | 'status'

export type Ingress2191604556Fields = {
  pipelineId: string
  round: number
  mode?: number | string
  scheduledAt?: string
  interviewer?: unknown
  meetingNo?: string
  status: number | string
}

export type Ingress2191604556CreateInput = Ingress2191604556Fields
export type Ingress2191604556UpdateInput = Partial<Ingress2191604556Fields>
export type Ingress2191604556Action = 'view' | 'add' | 'edit'
export type Ingress2191604556CustomAction = never

export type Ingress2191604556Sort = {
  column: Ingress2191604556FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604556QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604556Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604556Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604556Sort[]
}

export type Ingress2191604556BulkUpdateField = {
  key: Ingress2191604556FieldKey
  action: Record<string, any>
}

export type Ingress2191604556ExportOptions = {
  fields?: Ingress2191604556FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "0yz3NAbrBaXQlGZ"
const fieldIds = {
  pipelineId: 1001,
  round: 1002,
  mode: 1003,
  scheduledAt: 1004,
  interviewer: 1005,
  meetingNo: 1006,
  status: 1007,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604556Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604556Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604556Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604556Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604556QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604556Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603455/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604556Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603455/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603455/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: Ingress2191604556CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603455/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: Ingress2191604556UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603455/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },
  }
}
