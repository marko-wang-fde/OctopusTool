import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604552FieldKey = 'pipelineId' | 'recommender' | 'receiver' | 'aiSummary' | 'deptFeedback' | 'feedbackChannel' | 'feedbackAt'

export type Ingress2191604552Fields = {
  pipelineId: string
  recommender?: unknown
  receiver?: unknown
  aiSummary?: string
  deptFeedback?: number | string
  feedbackChannel?: number | string
  feedbackAt?: string
}

export type Ingress2191604552CreateInput = Ingress2191604552Fields
export type Ingress2191604552UpdateInput = Partial<Ingress2191604552Fields>
export type Ingress2191604552Action = 'view' | 'add' | 'edit'
export type Ingress2191604552CustomAction = never

export type Ingress2191604552Sort = {
  column: Ingress2191604552FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604552QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604552Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604552Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604552Sort[]
}

export type Ingress2191604552BulkUpdateField = {
  key: Ingress2191604552FieldKey
  action: Record<string, any>
}

export type Ingress2191604552ExportOptions = {
  fields?: Ingress2191604552FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "JAy3rjWqkRP30Ya"
const fieldIds = {
  pipelineId: 1001,
  recommender: 1002,
  receiver: 1003,
  aiSummary: 1004,
  deptFeedback: 1005,
  feedbackChannel: 1006,
  feedbackAt: 1007,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604552Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604552Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604552Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604552Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604552QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604552Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603454/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604552Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603454/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603454/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: Ingress2191604552CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603454/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: Ingress2191604552UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603454/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },
  }
}
