import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type DevOperatorFullAccess16FieldKey = 'fileName' | 'logicalPath' | 'sizeBytes' | 'sha256' | 'batchId' | 'contentType' | 'status' | 'parseError' | 'resumeId' | 'uploadedBy' | 'uploadedAt'

export type DevOperatorFullAccess16Fields = {
  fileName: string
  logicalPath: string
  sizeBytes?: number
  sha256?: string
  batchId?: string
  contentType?: string
  status?: number | string
  parseError?: string
  resumeId?: string
  uploadedBy?: unknown
  uploadedAt?: string
}

export type DevOperatorFullAccess16CreateInput = DevOperatorFullAccess16Fields
export type DevOperatorFullAccess16UpdateInput = Partial<DevOperatorFullAccess16Fields>
export type DevOperatorFullAccess16Action = 'view' | 'add' | 'edit' | 'delete'
export type DevOperatorFullAccess16CustomAction = never

export type DevOperatorFullAccess16Sort = {
  column: DevOperatorFullAccess16FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type DevOperatorFullAccess16QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: DevOperatorFullAccess16Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type DevOperatorFullAccess16Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: DevOperatorFullAccess16Sort[]
}

export type DevOperatorFullAccess16BulkUpdateField = {
  key: DevOperatorFullAccess16FieldKey
  action: Record<string, any>
}

export type DevOperatorFullAccess16ExportOptions = {
  fields?: DevOperatorFullAccess16FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "eDO6zOXbJ2pQMdx"
const fieldIds = {
  fileName: 1001,
  logicalPath: 1002,
  sizeBytes: 1003,
  sha256: 1004,
  batchId: 1005,
  contentType: 1006,
  status: 1007,
  parseError: 1008,
  resumeId: 1009,
  uploadedBy: 1010,
  uploadedAt: 1011,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<DevOperatorFullAccess16Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<DevOperatorFullAccess16Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: DevOperatorFullAccess16Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createDevOperatorFullAccess16Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: DevOperatorFullAccess16QueryParams = {}): Promise<{ items: ArcubaseRow<DevOperatorFullAccess16Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191605785/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<DevOperatorFullAccess16Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191605785/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191605785/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: DevOperatorFullAccess16CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191605785/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: DevOperatorFullAccess16UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191605785/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },

    async delete(selection: DevOperatorFullAccess16Selection): Promise<{ deleted?: number } | boolean> {
      return runtime.request<{ deleted?: number } | boolean>('POST', `/entity/2191603448/2191605785/delete-item`, {
        policy_id: ingressId,
        selection: toArcubaseSelection(selection),
      })
    },
  }
}
