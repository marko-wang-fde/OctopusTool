import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191605112FieldKey = 'proposer' | 'proposerRole' | 'department' | 'jobTitle' | 'headcount' | 'expectedMonth' | 'isKeyPosition' | 'status' | 'approver' | 'approvedAt' | 'approvalComment' | 'remark' | 'departmentOwner'

export type Ingress2191605112Fields = {
  proposer: unknown
  proposerRole: number | string
  department?: string
  jobTitle: string
  headcount: number
  expectedMonth?: string
  isKeyPosition?: boolean
  status: number | string
  approver?: unknown
  approvedAt?: string
  approvalComment?: string
  remark?: string
  departmentOwner?: unknown
}

export type Ingress2191605112CreateInput = Ingress2191605112Fields
export type Ingress2191605112UpdateInput = Partial<Ingress2191605112Fields>
export type Ingress2191605112Action = 'view' | 'add' | 'edit' | 'delete' | 'bulk_update'
export type Ingress2191605112CustomAction = never

export type Ingress2191605112Sort = {
  column: Ingress2191605112FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191605112QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191605112Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191605112Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191605112Sort[]
}

export type Ingress2191605112BulkUpdateField = {
  key: Ingress2191605112FieldKey
  action: Record<string, any>
}

export type Ingress2191605112ExportOptions = {
  fields?: Ingress2191605112FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "0yz3NAbrB4kQlGZ"
const fieldIds = {
  proposer: 1001,
  proposerRole: 1002,
  department: 1003,
  jobTitle: 1004,
  headcount: 1005,
  expectedMonth: 1006,
  isKeyPosition: 1007,
  status: 1008,
  approver: 1009,
  approvedAt: 1010,
  approvalComment: 1011,
  remark: 1012,
  departmentOwner: 1013,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191605112Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191605112Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191605112Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191605112Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191605112QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191605112Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603449/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191605112Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603449/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603449/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: Ingress2191605112CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603449/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: Ingress2191605112UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603449/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },

    async delete(selection: Ingress2191605112Selection): Promise<{ deleted?: number } | boolean> {
      return runtime.request<{ deleted?: number } | boolean>('POST', `/entity/2191603448/2191603449/delete-item`, {
        policy_id: ingressId,
        selection: toArcubaseSelection(selection),
      })
    },

    async bulkUpdate(selection: Ingress2191605112Selection, fields: Ingress2191605112BulkUpdateField[]): Promise<{ updated: number }> {
      return runtime.request<{ updated: number }>('POST', `/entity/2191603448/2191603449/bulk-update`, {
        policy_id: ingressId,
        selection: toArcubaseSelection(selection),
        fields: fields.map((field) => ({
          id: fieldIds[field.key],
          action: field.action,
        })),
      })
    },

    async saveBulkUpdate(input: { name: string; subject: string; fields: Ingress2191605112BulkUpdateField[] }): Promise<string> {
      return runtime.request<string>('POST', `/ingress/2191603448/0yz3NAbrB4kQlGZ/bulk-update/save-as`, {
        name: input.name,
        subject: input.subject,
        fields: input.fields.map((field) => ({
          id: fieldIds[field.key],
          action: field.action,
        })),
      })
    },
  }
}
