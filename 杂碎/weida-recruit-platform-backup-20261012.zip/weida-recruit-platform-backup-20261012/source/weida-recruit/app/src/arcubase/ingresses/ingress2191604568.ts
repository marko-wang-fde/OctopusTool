import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604568FieldKey = 'pipelineId' | 'mtype' | 'attachment' | 'uploadedBy' | 'uploadedAt'

export type Ingress2191604568Fields = {
  pipelineId: string
  mtype?: number | string
  attachment: unknown
  uploadedBy?: unknown
  uploadedAt?: string
}

export type Ingress2191604568CreateInput = Ingress2191604568Fields
export type Ingress2191604568UpdateInput = Partial<Ingress2191604568Fields>
export type Ingress2191604568Action = 'view'
export type Ingress2191604568CustomAction = never

export type Ingress2191604568Sort = {
  column: Ingress2191604568FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604568QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604568Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604568Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604568Sort[]
}

export type Ingress2191604568BulkUpdateField = {
  key: Ingress2191604568FieldKey
  action: Record<string, any>
}

export type Ingress2191604568ExportOptions = {
  fields?: Ingress2191604568FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "qORQ1bAZlJG3jmp"
const fieldIds = {
  pipelineId: 1001,
  mtype: 1002,
  attachment: 1003,
  uploadedBy: 1004,
  uploadedAt: 1005,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604568Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604568Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604568Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604568Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604568QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604568Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603458/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604568Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603458/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },
  }
}
