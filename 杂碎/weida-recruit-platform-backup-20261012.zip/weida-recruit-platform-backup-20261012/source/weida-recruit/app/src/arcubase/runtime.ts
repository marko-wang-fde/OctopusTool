export type ArcubaseClientConfig = {
  baseURL: string
  accessToken?: string
  refreshToken?: string
}

export type ArcubaseRow<TFields> = {
  id: number
  title?: string
  fields: TFields
  raw: Record<string, any>
}

export type ArcubaseRuntime = {
  request<T>(method: string, endpoint: string, body?: unknown): Promise<T>
}

type ArcubaseEnvelope<T> = {
  data?: T
  error?: { message?: string; key?: string; type?: string }
}

export function createRuntime(config: ArcubaseClientConfig): ArcubaseRuntime {
  let accessToken = config.accessToken ?? ''
  let refreshToken = config.refreshToken ?? ''

  async function request<T>(method: string, endpoint: string, body?: unknown): Promise<T> {
    const baseURL = config.baseURL.endsWith('/') ? config.baseURL : `${config.baseURL}/`
    const response = await fetch(new URL(endpoint.replace(/^\/+/, ''), baseURL).toString(), {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
        ...(refreshToken ? { 'X-Arcubase-Refresh-Token': refreshToken } : {}),
      },
      body: body === undefined ? undefined : JSON.stringify(body),
    })
    const payload = await response.json().catch(() => null) as ArcubaseEnvelope<T> | null
    if (!response.ok || payload?.error) {
      throw new Error(payload?.error?.message ?? `Arcubase request failed: ${response.status}`)
    }
    return payload?.data as T
  }

  return { request }
}

export function toArcubaseFields<T extends Record<string, any>>(fields: Partial<T>, fieldIds: Record<string, number>): Record<string, any> {
  const out: Record<string, any> = {}
  for (const [key, value] of Object.entries(fields)) {
    if (value === undefined) continue
    const fieldId = fieldIds[key]
    if (!fieldId) {
      throw new Error(`Unknown Arcubase field: ${key}`)
    }
    out[String(fieldId)] = value
  }
  return out
}

export function fromArcubaseFields<T>(raw: Record<string, any> | undefined, fieldIds: Record<string, number>): T {
  const out: Record<string, any> = {}
  const source = raw ?? {}
  for (const [key, fieldId] of Object.entries(fieldIds)) {
    if (String(fieldId) in source) {
      out[key] = source[String(fieldId)]
    }
  }
  return out as T
}

export function toArcubaseColumn(column: string, fieldIds: Record<string, number>): string {
  return fieldIds[column] ? `:${fieldIds[column]}` : column
}

export function mapArcubaseCondition(value: unknown, fieldIds: Record<string, number>): unknown {
  if (Array.isArray(value)) {
    return value.map((item) => mapArcubaseCondition(item, fieldIds))
  }
  if (!value || typeof value !== 'object') {
    return value
  }
  const out: Record<string, unknown> = {}
  for (const [key, child] of Object.entries(value as Record<string, unknown>)) {
    if (key === 'column' && typeof child === 'string') {
      out[key] = toArcubaseColumn(child, fieldIds)
    } else {
      const mappedKey = fieldIds[key] ? `:${fieldIds[key]}` : key
      out[mappedKey] = mapArcubaseCondition(child, fieldIds)
    }
  }
  return out
}

export function mapArcubaseSorts<T extends { column: string; order?: string }>(sorts: T[] | undefined, fieldIds: Record<string, number>): T[] | undefined {
  return sorts?.map((sort) => ({ ...sort, column: toArcubaseColumn(sort.column, fieldIds) }))
}
