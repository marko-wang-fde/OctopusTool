import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Offer3FieldKey = 'pipelineId' | 'result' | 'checkedBy' | 'checkedAt' | 'remark'

export type Offer3Fields = {
  pipelineId: string
  result: number | string
  checkedBy?: unknown
  checkedAt?: string
  remark?: string
}

export type Offer3CreateInput = Offer3Fields
export type Offer3UpdateInput = Partial<Offer3Fields>
export type Offer3Action = 'view'
export type Offer3CustomAction = never

export type Offer3Sort = {
  column: Offer3FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Offer3QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Offer3Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Offer3Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Offer3Sort[]
}

export type Offer3BulkUpdateField = {
  key: Offer3FieldKey
  action: Record<string, any>
}

export type Offer3ExportOptions = {
  fields?: Offer3FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "9ZN5Bw9ObnE6jwK"
const fieldIds = {
  pipelineId: 1001,
  result: 1002,
  checkedBy: 1003,
  checkedAt: 1004,
  remark: 1005,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Offer3Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Offer3Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Offer3Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createOffer3Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Offer3QueryParams = {}): Promise<{ items: ArcubaseRow<Offer3Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603461/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Offer3Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603461/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },
  }
}
