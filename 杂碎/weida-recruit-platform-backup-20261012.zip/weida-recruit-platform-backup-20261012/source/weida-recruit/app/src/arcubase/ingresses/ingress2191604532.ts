import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604532FieldKey = 'proposer' | 'proposerRole' | 'department' | 'jobTitle' | 'headcount' | 'expectedMonth' | 'isKeyPosition' | 'status' | 'approver' | 'approvedAt' | 'approvalComment' | 'remark' | 'departmentOwner'

export type Ingress2191604532Fields = {
  proposer: unknown
  proposerRole: number | string
  department?: string
  jobTitle: string
  headcount: number
  expectedMonth?: string
  isKeyPosition?: boolean
  status: number | string
  approver?: unknown
  approvedAt?: string
  approvalComment?: string
  remark?: string
  departmentOwner?: unknown
}

export type Ingress2191604532CreateInput = Ingress2191604532Fields
export type Ingress2191604532UpdateInput = Partial<Ingress2191604532Fields>
export type Ingress2191604532Action = 'view' | 'edit'
export type Ingress2191604532CustomAction = never

export type Ingress2191604532Sort = {
  column: Ingress2191604532FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604532QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604532Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604532Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604532Sort[]
}

export type Ingress2191604532BulkUpdateField = {
  key: Ingress2191604532FieldKey
  action: Record<string, any>
}

export type Ingress2191604532ExportOptions = {
  fields?: Ingress2191604532FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "1EJ6p9W2Kv7QYVD"
const fieldIds = {
  proposer: 1001,
  proposerRole: 1002,
  department: 1003,
  jobTitle: 1004,
  headcount: 1005,
  expectedMonth: 1006,
  isKeyPosition: 1007,
  status: 1008,
  approver: 1009,
  approvedAt: 1010,
  approvalComment: 1011,
  remark: 1012,
  departmentOwner: 1013,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604532Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604532Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604532Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604532Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604532QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604532Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603449/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604532Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603449/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async update(rowId: string | number, fields: Ingress2191604532UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603449/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },
  }
}
