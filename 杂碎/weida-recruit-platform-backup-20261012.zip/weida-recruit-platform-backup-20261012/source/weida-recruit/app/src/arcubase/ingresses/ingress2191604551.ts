import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604551FieldKey = 'pipelineId' | 'tier' | 'score' | 'details' | 'source' | 'matchedAt'

export type Ingress2191604551Fields = {
  pipelineId: string
  tier: number | string
  score?: number
  details?: string
  source?: number | string
  matchedAt?: string
}

export type Ingress2191604551CreateInput = Ingress2191604551Fields
export type Ingress2191604551UpdateInput = Partial<Ingress2191604551Fields>
export type Ingress2191604551Action = 'view' | 'add' | 'edit'
export type Ingress2191604551CustomAction = never

export type Ingress2191604551Sort = {
  column: Ingress2191604551FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604551QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604551Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604551Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604551Sort[]
}

export type Ingress2191604551BulkUpdateField = {
  key: Ingress2191604551FieldKey
  action: Record<string, any>
}

export type Ingress2191604551ExportOptions = {
  fields?: Ingress2191604551FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "B9j3gdPzXgD54p7"
const fieldIds = {
  pipelineId: 1001,
  tier: 1002,
  score: 1003,
  details: 1004,
  source: 1005,
  matchedAt: 1006,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604551Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604551Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604551Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604551Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604551QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604551Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603453/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604551Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603453/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603453/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: Ingress2191604551CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603453/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: Ingress2191604551UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603453/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },
  }
}
