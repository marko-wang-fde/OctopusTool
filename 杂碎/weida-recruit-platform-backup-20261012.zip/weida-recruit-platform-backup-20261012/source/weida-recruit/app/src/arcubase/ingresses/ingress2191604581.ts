import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604581FieldKey = 'type' | 'refType' | 'refId' | 'target' | 'channel' | 'plannedAt' | 'status' | 'resendCount'

export type Ingress2191604581Fields = {
  type: number | string
  refType?: number | string
  refId?: string
  target?: unknown
  channel?: number | string
  plannedAt?: string
  status: number | string
  resendCount?: number
}

export type Ingress2191604581CreateInput = Ingress2191604581Fields
export type Ingress2191604581UpdateInput = Partial<Ingress2191604581Fields>
export type Ingress2191604581Action = 'view' | 'add'
export type Ingress2191604581CustomAction = never

export type Ingress2191604581Sort = {
  column: Ingress2191604581FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604581QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604581Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604581Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604581Sort[]
}

export type Ingress2191604581BulkUpdateField = {
  key: Ingress2191604581FieldKey
  action: Record<string, any>
}

export type Ingress2191604581ExportOptions = {
  fields?: Ingress2191604581FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "ExKQ8b9a2Jg5Dkj"
const fieldIds = {
  type: 1001,
  refType: 1002,
  refId: 1003,
  target: 1004,
  channel: 1005,
  plannedAt: 1006,
  status: 1007,
  resendCount: 1008,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604581Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604581Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604581Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604581Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604581QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604581Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603462/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604581Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603462/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603462/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: Ingress2191604581CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603462/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },
  }
}
