import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type DevOperatorFullAccessFieldKey = 'ckey' | 'cvalue' | 'description'

export type DevOperatorFullAccessFields = {
  ckey: string
  cvalue?: string
  description?: string
}

export type DevOperatorFullAccessCreateInput = DevOperatorFullAccessFields
export type DevOperatorFullAccessUpdateInput = Partial<DevOperatorFullAccessFields>
export type DevOperatorFullAccessAction = 'view' | 'add' | 'edit' | 'delete'
export type DevOperatorFullAccessCustomAction = never

export type DevOperatorFullAccessSort = {
  column: DevOperatorFullAccessFieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type DevOperatorFullAccessQueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: DevOperatorFullAccessSort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type DevOperatorFullAccessSelection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: DevOperatorFullAccessSort[]
}

export type DevOperatorFullAccessBulkUpdateField = {
  key: DevOperatorFullAccessFieldKey
  action: Record<string, any>
}

export type DevOperatorFullAccessExportOptions = {
  fields?: DevOperatorFullAccessFieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "mRj3vBoaP89398w"
const fieldIds = {
  ckey: 1001,
  cvalue: 1002,
  description: 1003,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<DevOperatorFullAccessFields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<DevOperatorFullAccessFields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: DevOperatorFullAccessSelection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createDevOperatorFullAccessIngress(runtime: ArcubaseRuntime) {
  return {
    async query(params: DevOperatorFullAccessQueryParams = {}): Promise<{ items: ArcubaseRow<DevOperatorFullAccessFields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603463/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<DevOperatorFullAccessFields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603463/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603463/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: DevOperatorFullAccessCreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603463/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: DevOperatorFullAccessUpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603463/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },

    async delete(selection: DevOperatorFullAccessSelection): Promise<{ deleted?: number } | boolean> {
      return runtime.request<{ deleted?: number } | boolean>('POST', `/entity/2191603448/2191603463/delete-item`, {
        policy_id: ingressId,
        selection: toArcubaseSelection(selection),
      })
    },
  }
}
