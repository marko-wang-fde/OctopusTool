import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type DevOperatorFullAccess13FieldKey = 'pipelineId' | 'status' | 'markedBy' | 'markedAt'

export type DevOperatorFullAccess13Fields = {
  pipelineId: string
  status: number | string
  markedBy?: unknown
  markedAt?: string
}

export type DevOperatorFullAccess13CreateInput = DevOperatorFullAccess13Fields
export type DevOperatorFullAccess13UpdateInput = Partial<DevOperatorFullAccess13Fields>
export type DevOperatorFullAccess13Action = 'view' | 'add' | 'edit' | 'delete'
export type DevOperatorFullAccess13CustomAction = never

export type DevOperatorFullAccess13Sort = {
  column: DevOperatorFullAccess13FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type DevOperatorFullAccess13QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: DevOperatorFullAccess13Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type DevOperatorFullAccess13Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: DevOperatorFullAccess13Sort[]
}

export type DevOperatorFullAccess13BulkUpdateField = {
  key: DevOperatorFullAccess13FieldKey
  action: Record<string, any>
}

export type DevOperatorFullAccess13ExportOptions = {
  fields?: DevOperatorFullAccess13FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "1EJ6p9W2R87QYVD"
const fieldIds = {
  pipelineId: 1001,
  status: 1002,
  markedBy: 1003,
  markedAt: 1004,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<DevOperatorFullAccess13Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<DevOperatorFullAccess13Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: DevOperatorFullAccess13Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createDevOperatorFullAccess13Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: DevOperatorFullAccess13QueryParams = {}): Promise<{ items: ArcubaseRow<DevOperatorFullAccess13Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603460/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<DevOperatorFullAccess13Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603460/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603460/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: DevOperatorFullAccess13CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603460/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: DevOperatorFullAccess13UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603460/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },

    async delete(selection: DevOperatorFullAccess13Selection): Promise<{ deleted?: number } | boolean> {
      return runtime.request<{ deleted?: number } | boolean>('POST', `/entity/2191603448/2191603460/delete-item`, {
        policy_id: ingressId,
        selection: toArcubaseSelection(selection),
      })
    },
  }
}
