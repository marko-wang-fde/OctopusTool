import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type Ingress2191604541FieldKey = 'name' | 'phone' | 'idCard' | 'gender' | 'age' | 'education' | 'school' | 'workYears' | 'skills' | 'expectedSalary' | 'availableDate' | 'originFile' | 'channel' | 'library' | 'pipelineStatus' | 'parseStatus' | 'source' | 'ethnicity' | 'currentCity' | 'email' | 'expectedPosition' | 'expectedCity' | 'educationDetail' | 'workExperience'

export type Ingress2191604541Fields = {
  name: string
  phone: string
  idCard?: string
  gender?: number | string
  age?: number
  education?: number | string
  school?: string
  workYears?: number
  skills?: string
  expectedSalary?: string
  availableDate?: string
  originFile?: unknown
  channel?: number | string
  library: number | string
  pipelineStatus?: number | string
  parseStatus?: number | string
  source?: number | string
  ethnicity?: string
  currentCity?: string
  email?: string
  expectedPosition?: string
  expectedCity?: string
  educationDetail?: string
  workExperience?: string
}

export type Ingress2191604541CreateInput = Ingress2191604541Fields
export type Ingress2191604541UpdateInput = Partial<Ingress2191604541Fields>
export type Ingress2191604541Action = 'view'
export type Ingress2191604541CustomAction = never

export type Ingress2191604541Sort = {
  column: Ingress2191604541FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type Ingress2191604541QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: Ingress2191604541Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type Ingress2191604541Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: Ingress2191604541Sort[]
}

export type Ingress2191604541BulkUpdateField = {
  key: Ingress2191604541FieldKey
  action: Record<string, any>
}

export type Ingress2191604541ExportOptions = {
  fields?: Ingress2191604541FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "qRBQdvJkWM05yxk"
const fieldIds = {
  name: 1001,
  phone: 1002,
  idCard: 1003,
  gender: 1004,
  age: 1005,
  education: 1006,
  school: 1007,
  workYears: 1008,
  skills: 1009,
  expectedSalary: 1010,
  availableDate: 1011,
  originFile: 1012,
  channel: 1013,
  library: 1014,
  pipelineStatus: 1015,
  parseStatus: 1016,
  source: 1017,
  ethnicity: 1018,
  currentCity: 1019,
  email: 1020,
  expectedPosition: 1021,
  expectedCity: 1022,
  educationDetail: 1023,
  workExperience: 1024,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<Ingress2191604541Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<Ingress2191604541Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: Ingress2191604541Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createIngress2191604541Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: Ingress2191604541QueryParams = {}): Promise<{ items: ArcubaseRow<Ingress2191604541Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603451/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<Ingress2191604541Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603451/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },
  }
}
