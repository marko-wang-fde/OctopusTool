import {
  fromArcubaseFields,
  mapArcubaseCondition,
  mapArcubaseSorts,
  toArcubaseFields,
  type ArcubaseRow,
  type ArcubaseRuntime,
} from '../runtime.js'

export type DevOperatorFullAccess4FieldKey = 'name' | 'phone' | 'idCard' | 'gender' | 'age' | 'education' | 'school' | 'workYears' | 'skills' | 'expectedSalary' | 'availableDate' | 'originFile' | 'channel' | 'library' | 'pipelineStatus' | 'parseStatus' | 'source' | 'ethnicity' | 'currentCity' | 'email' | 'expectedPosition' | 'expectedCity' | 'educationDetail' | 'workExperience'

export type DevOperatorFullAccess4Fields = {
  name: string
  phone: string
  idCard?: string
  gender?: number | string
  age?: number
  education?: number | string
  school?: string
  workYears?: number
  skills?: string
  expectedSalary?: string
  availableDate?: string
  originFile?: unknown
  channel?: number | string
  library: number | string
  pipelineStatus?: number | string
  parseStatus?: number | string
  source?: number | string
  ethnicity?: string
  currentCity?: string
  email?: string
  expectedPosition?: string
  expectedCity?: string
  educationDetail?: string
  workExperience?: string
}

export type DevOperatorFullAccess4CreateInput = DevOperatorFullAccess4Fields
export type DevOperatorFullAccess4UpdateInput = Partial<DevOperatorFullAccess4Fields>
export type DevOperatorFullAccess4Action = 'view' | 'add' | 'edit' | 'delete'
export type DevOperatorFullAccess4CustomAction = never

export type DevOperatorFullAccess4Sort = {
  column: DevOperatorFullAccess4FieldKey | 'id' | 'created_at' | 'updated_at' | 'creator' | string
  order: 'asc' | 'desc'
}

export type DevOperatorFullAccess4QueryParams = {
  limit?: number
  offset?: number
  search?: Record<string, any>
  sorts?: DevOperatorFullAccess4Sort[]
  view_mode?: 'normal' | 'deleted' | 'archived'
  withSubForm?: boolean
}

export type DevOperatorFullAccess4Selection = {
  type: 'ids' | 'condition'
  length?: number
  ids?: Array<number | string>
  condition?: Record<string, any>
  sorts?: DevOperatorFullAccess4Sort[]
}

export type DevOperatorFullAccess4BulkUpdateField = {
  key: DevOperatorFullAccess4FieldKey
  action: Record<string, any>
}

export type DevOperatorFullAccess4ExportOptions = {
  fields?: DevOperatorFullAccess4FieldKey[]
  props?: string[]
  propNames?: Record<string, string>
  hasIdField?: boolean
}

const ingressId = "Yog3G2bExyEQZO1"
const fieldIds = {
  name: 1001,
  phone: 1002,
  idCard: 1003,
  gender: 1004,
  age: 1005,
  education: 1006,
  school: 1007,
  workYears: 1008,
  skills: 1009,
  expectedSalary: 1010,
  availableDate: 1011,
  originFile: 1012,
  channel: 1013,
  library: 1014,
  pipelineStatus: 1015,
  parseStatus: 1016,
  source: 1017,
  ethnicity: 1018,
  currentCity: 1019,
  email: 1020,
  expectedPosition: 1021,
  expectedCity: 1022,
  educationDetail: 1023,
  workExperience: 1024,
} as const
const allowedActions = [] as const

function mapRow(raw: Record<string, any>): ArcubaseRow<DevOperatorFullAccess4Fields> {
  return {
    id: Number(raw.id),
    title: typeof raw.title === 'string' ? raw.title : undefined,
    fields: fromArcubaseFields<DevOperatorFullAccess4Fields>(raw.fields, fieldIds),
    raw,
  }
}

function toArcubaseSelection(selection: DevOperatorFullAccess4Selection): Record<string, any> {
  return {
    ...selection,
    condition: mapArcubaseCondition(selection.condition ?? {}, fieldIds),
    sorts: mapArcubaseSorts(selection.sorts, fieldIds),
  }
}

export function createDevOperatorFullAccess4Ingress(runtime: ArcubaseRuntime) {
  return {
    async query(params: DevOperatorFullAccess4QueryParams = {}): Promise<{ items: ArcubaseRow<DevOperatorFullAccess4Fields>[]; total?: number; offset?: number; limit?: number }> {
      const data = await runtime.request<{ items?: Record<string, any>[]; total?: number; offset?: number; limit?: number }>('POST', `/entity/2191603448/2191603451/data-query`, {
        ...params,
        policy_id: ingressId,
        search: mapArcubaseCondition(params.search, fieldIds),
        sorts: mapArcubaseSorts(params.sorts, fieldIds),
      })
      return {
        items: (data.items ?? []).map(mapRow),
        total: data.total,
        offset: data.offset,
        limit: data.limit,
      }
    },

    async get(rowId: string | number): Promise<ArcubaseRow<DevOperatorFullAccess4Fields>> {
      const data = await runtime.request<{ record?: Record<string, any> }>('GET', `/entity/2191603448/2191603451/row/${rowId}?policy_id=${encodeURIComponent(ingressId)}`)
      return mapRow(data.record ?? {})
    },

    async prepareCreate(): Promise<Record<string, any>> {
      return runtime.request<Record<string, any>>('POST', `/entity/2191603448/2191603451/prepare`, {
        policy_id: ingressId,
      })
    },

    async create(fields: DevOperatorFullAccess4CreateInput): Promise<number> {
      return runtime.request<number>('POST', `/entity/2191603448/2191603451/insert`, {
        fields: toArcubaseFields(fields, fieldIds),
        policy_id: ingressId,
      })
    },

    async update(rowId: string | number, fields: DevOperatorFullAccess4UpdateInput): Promise<boolean> {
      const data = toArcubaseFields(fields, fieldIds)
      return runtime.request<boolean>('PUT', `/entity/2191603448/2191603451/row/${rowId}`, {
        data,
        changed_fields: Object.keys(data).map((fieldId) => Number(fieldId)),
        policy_id: ingressId,
      })
    },

    async delete(selection: DevOperatorFullAccess4Selection): Promise<{ deleted?: number } | boolean> {
      return runtime.request<{ deleted?: number } | boolean>('POST', `/entity/2191603448/2191603451/delete-item`, {
        policy_id: ingressId,
        selection: toArcubaseSelection(selection),
      })
    },
  }
}
