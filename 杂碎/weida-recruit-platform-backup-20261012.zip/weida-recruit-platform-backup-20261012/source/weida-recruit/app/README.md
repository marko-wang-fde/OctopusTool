# app

Syngy React business app.

```bash
npm install
npm run dev
npm run build
```

Local development requires the Workbench team id used for team-scoped local
authorization.

```bash
WORKBENCH_REQUIRED_TEAM_ID=<teamId> npm run dev
```

Arcubase projects can generate local TypeScript source with `npm run arcubase:codegen`.
The first local run creates the Workbench JCode handoff. Later runs reuse the
local Workbench codegen session and refresh it with the stored refresh token.

```bash
npm run arcubase:codegen -- --app-id <appId> --team-id <teamId>
```
