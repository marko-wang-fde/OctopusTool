# 04 站点地图与页面 · 韦达招聘

> 交付渠道：工作台 Web（唯一 UI 端）+ 企微（招聘助手对话/通知卡片）+ 邮件（正式通知，无 UI 页面）。
> 页面编号 P0–P14；菜单分组 M1–M5 与 P 编号并存。

## 1. 菜单与路由树

```text
韦达招聘工作台
├─ M1 招聘驾驶舱            P1  /dashboard           （仅人事专员/人事经理）
├─ M2 今日待办              P2  /today               （全部角色，按角色过滤）
├─ M3 人才库                P3  /talents             （五库 Tab）
│    └─ 简历详情            P4  /talents/:id
├─ M4 招聘管理              P5  /recruit             （= 招聘流程列表，实例按 pipeline 归组）
│    ├─ 4.1 用人需求管理    P6  /recruit/demands     （详情=抽屉、新建=抽屉）
│    ├─ 4.2 简历匹配        P7  /recruit/matching    （含上传简历按钮）
│    ├─ 4.3 面试管理        P8  /recruit/interviews  （面试官企微深链直达 ?focus=:rid）
│    ├─ 4.4 背调与拟薪      P9  /recruit/screening
│    ├─ 4.5 Offer 管理      P10 /recruit/offers
│    └─ 4.6 到岗核验        P11 /recruit/onboard
└─ M5 系统设置              P12 /settings
     ├─ 5.1 岗位管理        P13 /settings/jobs
     └─ 5.2 配置            P14 /settings/config
└─ 登录                     P0  /login               （平台托管，非自建页面）
```

## 2. 页面清单（编号 / 页面 / 路由 / 主要角色 / 主要内容与 shadcn 控件）

| 编号 | 页面 | 路由 | 主要可见角色 | 内容要点（new-york 控件） |
| --- | --- | --- | --- | --- |
| P1 | 招聘驾驶舱 | /dashboard | 人事专员、人事经理 | 7 项指标图表（Chart）、月/周切换（Tabs） |
| P2 | 今日待办 | /today | 全部 | 超时待办/待审批/提醒聚合（Table + Badge 状态色） |
| P3 | 人才库 | /talents | 人事专员、人事经理；部门领导限本部门 | 五库 Tab、库间移动记录（Tabs + Table） |
| P4 | 简历详情 | /talents/:id | 同 P3 | 结构化简历、原始附件、历史流程链接（Sheet + Badge） |
| P5 | 招聘管理 | /recruit | 人事专员、人事经理；部门领导限本部门 | 流程实例列表：当前阶段列、筛选（Table + Select） |
| P6 | 用人需求管理 | /recruit/demands | 人事专员、部门领导 | 需求列表；新建/详情抽屉（Sheet + Form）；审批记录 |
| P7 | 简历匹配 | /recruit/matching | 人事专员 | 需求选择、上传按钮、三档+百分比+命中明细（Table + Badge + Dialog） |
| P8 | 面试管理 | /recruit/interviews | 人事专员；面试官深链直达 | 预约列表、反馈表单（录取/不通过/再次面试/待定）、文字记录上传（Dialog） |
| P9 | 背调与拟薪 | /recruit/screening | 人事专员；拟薪数字仅人事经理 | 材料上传、拟薪表单与审批状态（Dialog + AlertDialog） |
| P10 | Offer 管理 | /recruit/offers | offer 专员（操作）、人事专员/经理（看） | 状态标记：已发/接受/拒绝（Button + AlertDialog） |
| P11 | 到岗核验 | /recruit/onboard | 人事专员 | 核验三选一：已到岗/提前说明不来/无故未到（RadioGroup + AlertDialog） |
| P12 | 系统设置 | /settings | 人事专员、人事经理 | 入口聚合 |
| P13 | 岗位管理 | /settings/jobs | 人事专员（管）、部门领导（本部门 R） | 岗位 CRUD、硬性要求可配置项、待定规则、负责人（Sheet + Form） |
| P14 | 配置 | /settings/config | 人事专员、人事经理 | 超时阈值（默认 3 工作日）、邮件模板启停（Switch + Input） |
| P0 | 登录 | /login | 平台托管 | 非自建页面 |

## 3. 弹窗/抽屉（非路由）

导入简历 Dialog；新建/编辑岗位 Sheet；拟薪 Dialog；改期 Dialog；上传材料 Dialog；邮件草稿确认 AlertDialog；查重提示 Toast；各审批确认 AlertDialog。

## 4. 企微与邮件（无页面）

- **企微**：招聘助手对话入口（S1/S6 问答、S3 反馈回传）；通知卡片（推荐、提醒、审批）深链到 P5–P11 对应页（含登录回跳）。
- **邮件**：面试邀约正式通知（模板渲染 → 人事专员确认 → 发送）；改期重发同流程。模板内容 = Q14 外部待交付材料。

## 5. 禁止项

1. 禁止占位页、mock 数据、假进度条——每个可见控件必须连真实数据或禁用。
2. 禁止脱离流程实例的独立"面试管理"数据写入（P8 仍按 pipeline 归组）。
3. 禁止在前端实现权限过滤代替 access-rule。
4. 禁止自建登录页 / token 存储。
5. 禁止直发候选人邮件（必须经人事专员确认）。
