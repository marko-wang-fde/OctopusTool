# 06 技术与 AI 执行约定 · 韦达招聘

> 技术栈与执行契约已按官方 Skill `workbench-app-development`（10.06）校验修正。开发阶段以该 Skill 为唯一执行规范。

## 1. 技术栈（锁定，无可选项）

```text
React + Vite + TypeScript 5.9 + Tailwind CSS 3.4 + shadcn/ui(new-york) + @syngy/workbench-auth
```

- 禁止：ECharts 及国内组件库、Pinia、自建登录/token 存储、占位页、mock 数据。
- 图表用 shadcn 生态控件；路由用模板自带方式（深链用 URL 参数）。

## 2. 脚手架与数据层

```bash
# 1) 脚手架（features 禁止省略；等号+逗号分隔）
npm create @syngy/workbench-app-react@latest weida-recruit -- --features=octopus,arcubase

# 2) CLI 上下文核对（每次 team 级发现与外部写入前）
octopus-cli auth whoami --json    # profile/host/account/team 四值匹配，不匹配即停

# 3) 建 App 与表（先读 --help，--body-json 照抄；先呈现 05 表字典并经开发者确认）
octopus-cli arcubase-admin app create --help
octopus-cli arcubase-admin table create --help
octopus-cli arcubase-admin table update-schema --help
octopus-cli arcubase-admin access-rule create --help   # 按 03 矩阵逐表配置

# 4) 生成 typed client（二选一）
octopus-cli arcubase-admin dev sdk-gen --app-id <appId> --out src/arcubase
npm run arcubase:codegen -- --app-id <appId> --team-id <teamId> --out src/arcubase   # 禁传 --web-url
```

## 3. 硬性技术规则

1. **datetime**：写入一律 epoch 秒（toEpochSeconds helper）；禁 ISO 字符串/毫秒直写；首个记录写后读回比对。
2. **数据边界**：业务数据只用 arcubase typed ingress client；禁用 octopus.api 的 Arcubase 代理写业务数据。
3. **权限**：access-rule 后端强制（03 矩阵）；前端隐藏≠隔离；角色单一权威源=平台，禁止多处维护角色名单；Host 身份↔Arcubase 用户绑定经人工 session 验证。
4. **本地开发**：`WORKBENCH_REQUIRED_TEAM_ID=<teamId> npm run dev`；JCode 登录回跳；验证用真实后端数据（空库显示真实空态）。
5. **真实数据保护**：验证默认只读；写测试数据须用明确测试记录策略。

## 4. 发布门禁（顺序执行，不得跳过）

1. 本地验证：真团队登录 + 每个页面真实数据证据（或真实空态）。
2. **开发者显式批准发布**（原话要求不豁免此关）。
3. 只跑 package.json 已声明的相关 test/build 脚本；`test -f dist/index.html` 必须通过。
4. `octopus-cli coding projects create`（**至多 1 个**；不确定先 `projects list/show`，禁建本地 ID 映射文件）。
5. `coding projects publish <projectId> --path dist --json`（输出须含 `deployment.taskId`，否则重跑 publish）。
6. `coding projects watch <taskId> --json`：5 秒轮询 ≤10 分钟；queued/processing 继续；failed 立即停并报 errorMessage；**active + workbenchUrl = 成功**。
7. 成功交付报告只含：projectId、taskId、status=active、workbenchUrl、已验证 profile/host/team；禁用 appId 替代。

## 5. AI 执行约定

- 开发/续写代码一律加载 Skill `workbench-app-development`（本仓库 .trae/skills/ 内）。
- 知识库：随包官方 guide（.trae/skills/octopus-req-interview/references/official-octopusdoc）+ 本 design/ 目录。
- 数字员工"招聘助手"：1 实例，home=按数字员工；S1–S6 见 01 设计卡；待试点能力（企微/邮件/问答）失败转人工。
- 长上下文提示：技术栈边界与 05 分流表易被稀释，长会话需人工复述强调。

## 6. 执行顺序（已确认）

```text
whoami 核对 → 建 App/15 表 + access-rule(人工配置) → codegen →
前端页面(P1–P14) → 数字员工企微接入 → 本地真机验证 → 批准 → 发布 → 验收(07)
```

开发前置待办：①Q5 筛选维度与待定规则材料；②Q14 邮件模板文本；③渠道枚举终表；④审批人/岗位负责人/组织架构的平台侧配置（人工）。
