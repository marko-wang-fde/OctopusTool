# 维达招聘管理系统 — 项目移交文档

> 本文档供接手维护的开发人员使用，涵盖平台连接、项目架构、开发流程、业务规则和踩坑记录。

---

## 目录

1. [项目概述](#1-项目概述)
2. [小章鱼平台连接方式](#2-小章鱼平台连接方式)
3. [开发环境准备](#3-开发环境准备)
4. [开发方式](#4-开发方式)
5. [项目架构](#5-项目架构)
6. [业务数据表结构](#6-业务数据表结构)
7. [核心代码模块说明](#7-核心代码模块说明)
8. [业务流程与红线规则](#8-业务流程与红线规则)
9. [工程约定](#9-工程约定)
10. [踩坑记录](#10-踩坑记录)
11. [常用运维 CLI 命令](#11-常用运维-cli-命令)

---

## 1. 项目概述

| 项 | 值 |
|---|---|
| 项目名称 | 维达招聘管理系统（weida-recruit） |
| 技术栈 | React 19 + TypeScript 5.9 + Vite 7 + TailwindCSS 3 |
| 运行平台 | 小章鱼（Octopus）Workbench |
| 数据层 | Arcubase（平台低代码数据库） |
| 文件存储 | 平台 fileGateway + 知识库（KB） |
| 工作目录 | `/Users/marko/Desktop/tracCideTest/JiaWuTai/weida-recruit/app` |
| 线上地址 | https://wb-rxbdg2tl3l.workbench.autostaff.cn |
| 项目 ID | `vcp_c6daf31e-77e6-49c7-9df5-4ded587a144b` |
| 团队 ID | `team_75033186-9ec1-494c-8024-9b45bbe3dbdb` |
| Arcubase App ID | `2191603448` |

---

## 2. 小章鱼平台连接方式

### 2.1 octopus-cli 安装与登录

```bash
# 安装 CLI（全局）
npm install -g @syngy/octopus-cli

# 浏览器登录
octopus-cli auth login

# 验证当前身份
octopus-cli auth whoami

# 查看可用 profile
octopus-cli auth profiles
```

### 2.2 Workbench 认证机制

项目通过 `@syngy/workbench-auth` SDK 实现认证：

- **初始化**：`ensureWorkbenchRuntime({ standaloneAuth: 'never' })` 自动从 cookie/localStorage 恢复会话
- **获取当前用户**：`readWorkbenchViewer()` 先从 runtime 缓存读取，fallback 调用 `GET /api/v1/me`
- **viewer.id** 是平台 hostUserId（不是 arcabaseUserId），member 字段存储时需转换
- **退出登录**：`signOutWorkbench()` 调用 `clearWorkbenchSession()` 清除 cookie + localStorage 后刷新

关键文件：`src/lib/syngy.ts`

### 2.3 Host API（平台 API）

通过 `createWorkbenchFetch()` 构造认证请求，调用平台 Host API：

```typescript
// 读取（GET）
const data = await readHostJson<T>('/api/v1/teams/{teamId}/...')

// 写入（POST）
const result = await writeHostJson<T>('/api/v1/teams/{teamId}/...', body)
```

常用 Host API 端点：

| 端点 | 用途 |
|------|------|
| `GET /api/v1/me` | 获取当前用户信息 |
| `GET /api/v1/teams/{teamId}/arcubase/departments/tree` | 部门树 |
| `GET /api/v1/teams/{teamId}/arcubase/organization/roles` | 角色列表 |
| `GET /api/v1/teams/{teamId}/members/{hostUserId}/arcubase/organization/roles` | 成员角色绑定 |
| `POST /api/v1/teams/{teamId}/organization/members:search` | 按部门搜成员 |
| `POST /api/v1/teams/{teamId}/files/presign-put` | 申请文件上传地址 |
| `POST /api/v1/teams/{teamId}/files/upload-finalize` | 确认文件上传完成 |
| `POST /api/v1/teams/{teamId}/files/presign-get` | 获取文件下载地址 |

### 2.4 Arcubase 连接

Arcubase runtime 从 Workbench runtime 的 `endpoints.arcubase` 构造：

```typescript
// 创建 Arcubase runtime
const runtime = createWorkbenchArcubaseRuntime()
// runtime 内部使用 authFetch 携带 token 请求 /arcubase/api/...

// 通过 table() 获取 ingress
const demands = table('demands')
await demands.create({ ... })
await demands.update(rowId, { ... })
await demands.query({ limit, offset })
```

关键文件：
- `src/lib/syngy.ts` — `createWorkbenchArcubaseRuntime()`
- `src/arcubase/runtime.ts` — 底层请求层
- `src/arcubase/client.ts` — client 工厂 + ingress 注册

### 2.5 环境变量

```env
# .env
WORKBENCH_REQUIRED_TEAM_ID=team_75033186-9ec1-494c-8024-9b45bbe3dbdb
```

---

## 3. 开发环境准备

### 3.1 前置条件

| 工具 | 版本要求 |
|------|---------|
| Node.js | >= 18（推荐 20+） |
| npm/pnpm | 任意包管理器 |
| octopus-cli | 最新版（`npm i -g @syngy/octopus-cli`） |

### 3.2 初始化

```bash
cd weida-recruit/app

# 安装依赖
npm install

# 登录小章鱼平台
octopus-cli auth login

# 验证登录
octopus-cli auth whoami
```

### 3.3 目录结构

```
weida-recruit/
└── app/                        # 前端项目根目录
    ├── .env                    # 环境变量（WORKBENCH_REQUIRED_TEAM_ID）
    ├── package.json            # 依赖与脚本
    ├── vite.config.ts          # Vite 配置（含 workbenchDevtools 插件）
    ├── tsconfig.json            # TypeScript 配置
    ├── index.html              # HTML 模板
    ├── dist/                   # 构建产物（发布时用）
    └── src/
        ├── main.tsx            # 应用入口
        ├── App.tsx             # 主应用（导航、路由、初始化）
        ├── pages/              # 业务页面组件（15 个）
        ├── components/ui/      # UI 组件库（shadcn/ui 风格）
        ├── lib/                # 核心库
        │   ├── syngy.ts        # 平台连接层（Workbench/Auth/Host API）
        │   ├── tables.ts       # 业务表映射 + 工具函数
        │   ├── files.ts        # 文件上传/下载/简历解析
        │   ├── memberNames.ts  # 成员姓名注册表
        │   ├── labels.ts       # 业务枚举常量
        │   ├── roles.ts        # 角色定义与推断
        │   └── conversation.ts # 数字员工对话（AI 简历解析）
        └── arcubase/           # Arcubase codegen 产物
            ├── index.ts        # 对外导出
            ├── client.ts       # client 工厂
            ├── runtime.ts      # runtime 请求层
            ├── schema.ts       # 表/字段 schema 定义
            └── ingresses/      # codegen 生成的 ingress（勿手改）
```

---

## 4. 开发方式

### 4.1 本地开发

```bash
# 启动 dev server（含 workbench devtools 热更新）
npm run dev

# 或直接用 vite
node node_modules/.bin/vite
```

### 4.2 构建

```bash
# 类型检查 + 构建
npm run build
# 或分步
node node_modules/.bin/tsc -b && node node_modules/.bin/vite build
```

构建产物输出到 `dist/` 目录。

### 4.3 发布到线上工作台

```bash
# 发布（将 dist/ 推送到平台）
octopus-cli coding projects publish vcp_c6daf31e-77e6-49c7-9df5-4ded587a144b --path dist --json
```

发布后平台会异步部署，约 10-30 秒生效。刷新工作台页面即可看到更新。

### 4.4 Arcubase Codegen（表结构变更后）

当 Arcubase 平台表结构变更后，需重新生成 ingress 代码：

```bash
npm run arcubase:codegen
# 或
node node_modules/.bin/workbench-arcubase-codegen
```

生成结果在 `src/arcubase/ingresses/` 目录下。**不要手动修改 codegen 产物**。

### 4.5 调试

- **DevTools**：`@syngy/workbench-devtools` Vite 插件提供开发态登录页和 runtime 调试
- **Console**：在浏览器控制台直接调用 `window.__workbenchRuntime` 查看运行时
- **CLI 验证**：用 `octopus-cli arcubase row query` 直接查表验证数据

---

## 5. 项目架构

### 5.1 整体架构

```
┌──────────────────────────────────────────────┐
│              Workbench 平台                    │
│  ┌─────────────┐  ┌───────────────────────┐  │
│  │  Auth/Cookie  │  │  Host API (/api/v1/)  │  │
│  └──────┬───────┘  └───────────┬───────────┘  │
│         │                        │              │
│  ┌──────┴───────────────────────┴───────────┐  │
│  │        Arcubase (/arcubase/api/)           │  │
│  │    App ID: 2191603448                       │  │
│  │    Tables: T1-T16 (16 张业务表)             │  │
│  └────────────────────────────────────────────┘  │
│  ┌───────────────────────────────────────────┐    │
│  │  File Gateway + KB (知识库)               │    │
│  └───────────────────────────────────────────┘    │
└──────────────────────────────────────────────────┘
                    │
                    ▼
┌──────────────────────────────────────────────────┐
│              前端 App (Vite SPA)                  │
│  ┌─────────────────────────────────────────────┐ │
│  │  App.tsx — 导航/路由/初始化                    │ │
│  ├─────────────────────────────────────────────┤ │
│  │  Pages (15个业务页面)                         │ │
│  ├─────────────────────────────────────────────┤ │
│  │  lib/syngy.ts — 平台连接层                    │ │
│  │  lib/tables.ts — 表映射 + 工具函数             │ │
│  │  lib/files.ts — 文件上传/下载/简历解析         │ │
│  │  lib/memberNames.ts — 成员姓名注册表          │ │
│  │  lib/roles.ts — 角色定义                      │ │
│  │  lib/labels.ts — 业务枚举常量                 │ │
│  ├─────────────────────────────────────────────┤ │
│  │  arcubase/ — codegen 产物（client/runtime/    │ │
│  │             ingress/schema）                 │ │
│  └─────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────┘
```

### 5.2 页面清单

| 模块 | 页面文件 | 路由 | 说明 |
|------|---------|------|------|
| M1 招聘驾驶舱 | DashboardPage.tsx | /dashboard | 招聘数据看板 |
| M2 今日待办 | TodayPage.tsx | /today | 待办任务列表 |
| M3 人才库 | TalentsPage.tsx | /talents | 简历库管理 |
| M3 人才详情 | TalentDetailPage.tsx | /talents/:id | 简历详情（教育/经历/技能） |
| M4 流程列表 | RecruitPage.tsx | /recruit | 招聘流程实例列表 |
| M4.1 用人需求 | DemandsPage.tsx | /recruit/demands | 需求单 CRUD + 审批 |
| M4.2 简历匹配 | MatchingPage.tsx | /recruit/matching | 自动/手动匹配 |
| M4.3 人才推荐 | RecommendationsPage.tsx | /recruit/recommendations | 推荐管理（抽屉详情） |
| M4.4 面试管理 | InterviewsPage.tsx | /recruit/interviews | 面试预约/记录/反馈 |
| M4.5 背调与拟薪 | ScreeningPage.tsx | /recruit/screening | 背调材料+拟薪审批 |
| M4.6 Offer 管理 | OffersPage.tsx | /recruit/offers | Offer 发放/接受/拒绝 |
| M4.7 到岗核验 | OnboardPage.tsx | /recruit/onboard | 到岗核验 |
| M5.1 岗位管理 | JobsPage.tsx | /settings/jobs | 岗位 CRUD（subform 技能） |
| M5.2 配置 | ConfigPage.tsx | /settings/config | 系统配置 |
| 设置 | SettingsPage.tsx | /settings | 设置入口 |

### 5.3 角色体系

| 角色 | 权限范围 |
|------|---------|
| 人事专员 | 全部模块（不含审批） |
| 人事经理 | 全部模块（含审批、拟薪可见） |
| 部门领导 | 本部门需求/推荐/面试 |
| offer专员 | Offer 管理模块 |
| 未知 | 默认只读 |

角色单一权威源为平台，通过 `listMemberRoles(hostUserId)` 获取。前端 `roles.ts` 仅做显示层推断。

---

## 6. 业务数据表结构

### 6.1 表清单

Arcubase App ID: `2191603448`

| 表 Key | Ingress Key | Table ID | 中文名 |
|--------|-------------|----------|--------|
| demands | devOperatorFullAccess2 | 2191603449 | T1 用人需求单 |
| jobs | devOperatorFullAccess3 | 2191603450 | T2 岗位 |
| resumes | devOperatorFullAccess4 | 2191603451 | T3 简历 |
| pipelines | devOperatorFullAccess5 | 2191603452 | T4 招聘流程实例 |
| matches | devOperatorFullAccess6 | 2191603453 | T5 匹配结果 |
| recommendations | devOperatorFullAccess7 | 2191603454 | T6 推荐记录 |
| interviews | devOperatorFullAccess8 | 2191603455 | T7 面试预约 |
| feedbacks | devOperatorFullAccess9 | 2191603456 | T8 面试反馈 |
| interviewRecords | devOperatorFullAccess10 | 2191603457 | T9 面试文字记录 |
| bgMaterials | devOperatorFullAccess11 | 2191603458 | T10 背调材料 |
| salaries | devOperatorFullAccess12 | 2191603459 | T11 拟薪 |
| offers | devOperatorFullAccess13 | 2191603460 | T12 Offer 记录 |
| onboardChecks | devOperatorFullAccess14 | 2191603461 | T13 到岗核验 |
| reminders | devOperatorFullAccess15 | 2191603462 | T14 提醒任务 |
| configs | devOperatorFullAccess | 2191603463 | T15 系统配置 |
| resumeMaterials | devOperatorFullAccess16 | 2191605785 | T16 简历材料 |

映射定义在 `src/lib/tables.ts` 的 `TABLE_INGRESS` 常量中。

### 6.2 关键字段速查

**T1 用人需求单 (demands)**

| 业务字段名 | fieldId | 类型 | 说明 |
|-----------|---------|------|------|
| proposer | 1001 | member | 提出人（存 arcabaseUserId） |
| proposerRole | — | select | 部门领导/人事专员 |
| department | — | text | 需求部门 |
| jobTitle | — | text | 岗位名称 |
| headcount | — | number | 招聘人数 |
| expectedMonth | — | text | 期望到岗月 |
| isKeyPosition | — | boolean | 是否关键岗位 |
| departmentOwner | — | member | 部门对接人 |
| status | — | select | 草稿/待审批/通过/驳回 |
| approver | 1009 | member | 审批人 |
| approvedAt | 1010 | datetime | 审批时间（epoch 秒） |
| approvalComment | — | text | 审批意见 |
| remark | — | text | 备注 |

**T2 岗位 (jobs)**

| 业务字段名 | 类型 | 说明 |
|-----------|------|------|
| name | text | 岗位名称 |
| department | text | 所属部门 |
| level | select | 初级/中级/高级/专家/资深专家 |
| headcount | number | 招聘人数 |
| ageRequirement | text | 年龄要求（如"25-35"） |
| educationRequirement | select | 不限/中专/大专/本科/硕士/博士 |
| skillItems | subform | 技能要求（fieldId=1021, 仅 skillName 字段） |
| experienceRequirement | text | 经验要求 |
| salaryRange | text | 薪资范围（如"8k-12k"） |
| description | textarea | 岗位描述 |
| remark | textarea | 备注 |
| status | select | 启用/停用 |

### 6.3 KB 知识库目录

| 路径 | 用途 |
|------|------|
| `/kb/weida-recruitment-resumes` | 简历文件 + 面试附件 + 背调材料 |
| `/kb/default` | 默认目录（未使用） |
| `/kb/resume` | 旧简历目录（未使用） |

文件上传流程（KB 三段式链路）：
1. `POST /api/v1/teams/{teamId}/files/presign-put` → 获取上传 URL + finalizeToken
2. `PUT {presign.url}` → 浏览器直传 fileGateway
3. `POST /api/v1/teams/{teamId}/files/upload-finalize` → 确认完成，返回 logicalPath

关键文件：`src/lib/files.ts` — `uploadKbFile()`, `getKbFileDownloadUrl()`

---

## 7. 核心代码模块说明

### 7.1 lib/syngy.ts — 平台连接层

| 导出 | 类型 | 说明 |
|------|------|------|
| `initializeWorkbench()` | async | 初始化 Workbench runtime |
| `readWorkbenchViewer()` | async | 获取当前登录用户 |
| `signOutWorkbench()` | sync | 退出登录（清 cookie + localStorage） |
| `listDepartments()` | async | 部门树（扁平化列表） |
| `listOrganizationRoles()` | async | 平台角色列表 |
| `listMemberRoles(hostUserId)` | async | 成员角色绑定（返回 arcabaseUserId） |
| `listAllTeamMembers()` | async | 全量团队成员（遍历部门） |
| `listTeamMembersByDepartment(ids)` | async | 按部门拉成员 |
| `memberDepartmentNames(member, depts)` | function | 成员 → 部门名列表 |
| `createWorkbenchArcubaseRuntime()` | function | 创建 Arcubase runtime |
| `readHostJson(path)` | async | GET Host API |
| `writeHostJson(path, body)` | async | POST Host API |
| `getTeamId()` | function | 获取当前 team ID |

### 7.2 lib/tables.ts — 表映射 + 工具函数

| 导出 | 说明 |
|------|------|
| `TABLE_INGRESS` | 业务表名 → ingress key 映射 |
| `table(key)` | 获取指定表的 ingress 实例 |
| `queryAll(ingress, search?)` | 分页拉取全部行（每页 200） |
| `toEpochSeconds(value)` | 任意输入 → epoch 秒 |
| `dt(epochSeconds)` | epoch 秒 → Arcubase datetime 字符串 |
| `readEpoch(value)` | 读取 datetime（兼容秒/毫秒/ISO） |
| `fmtDate(value)` | 格式化日期（YYYY-MM-DD） |
| `fmtDateTime(value)` | 格式化日期时间 |
| `memberLabel(value)` | member 字段 → 显示名（null/0/'' → '—'） |
| `selectLabel(value)` | select 字段 → 显示文本 |

### 7.3 lib/files.ts — 文件处理

| 导出 | 说明 |
|------|------|
| `uploadKbFile(file, subDir?)` | 上传到知识库（三段式链路） |
| `getKbFileDownloadUrl(logicalPath)` | 获取 KB 文件下载地址 |
| `uploadArcubaseFile(file)` | 旧链路 OSS 直传（背调用） |
| `fetchArcubaseFile(fileValue)` | 旧链路文件下载 |
| `parseResumeFile(file)` | PDF/DOCX 文本提取 + 正则字段提取 |
| `toKbAttachmentValue(result)` | KB 上传结果 → 附件值格式 |
| `attachmentLogicalPath(fileValue)` | 从附件值提取 KB logicalPath |

### 7.4 lib/memberNames.ts — 成员姓名注册表

| 导出 | 说明 |
|------|------|
| `registerMemberName(id, name)` | 注册单个成员 |
| `registerMemberNames(entries)` | 批量注册（同时注册 arcabaseUserId 和 userId） |
| `captureAdditionalUsers(payload)` | 从 Arcubase 响应的 additional.users 自动捕获 |
| `lookupMemberName(id)` | 查找成员显示名 |

### 7.5 lib/roles.ts — 角色定义

| 导出 | 说明 |
|------|------|
| `BusinessRole` | 类型：人事专员/人事经理/部门领导/offer专员/未知 |
| `inferBusinessRole(viewer)` | 从 viewer 信息推断角色 |
| `canSeeSalaryAmount(roles)` | 拟薪金额可见性（仅人事经理） |

### 7.6 lib/labels.ts — 业务枚举

包含所有业务状态常量（DEMAND_STATUS, STAGES, INTERVIEW_STATUS 等）和颜色映射 `statusTone()`。

### 7.7 lib/conversation.ts — 数字员工对话

用于 AI 简历解析，通过创建对话、上传文件、发送 prompt、监听 SSE 流获取解析结果。

### 7.8 arcubase/ — Codegen 产物

| 文件 | 说明 |
|------|------|
| `index.ts` | 对外导出统一入口 |
| `client.ts` | client 工厂 + `ArcubaseIngressMap` |
| `runtime.ts` | 底层请求层 + 字段映射工具 |
| `schema.ts` | 表/字段 schema 定义 |
| `ingresses/*.ts` | 各表的 ingress 实现（codegen 生成，勿手改） |

---

## 8. 业务流程与红线规则

### 8.1 招聘流程

```
用人需求 → 简历匹配 → 人才推荐 → 面试 → 背调 → 拟薪 → Offer → 到岗核验
```

流程阶段顺序（`STAGE_ORDER`）：匹配 → 待推荐 → 面试 → 背调 → 拟薪 → offer → 核验

### 8.2 红线规则（不可违反）

1. **面试邀约邮件发送前必须经人事专员确认**，不可系统直发
2. **面试改期后系统需自动重排提醒任务**并生成新邮件草稿经人事专员手动重发
3. **S4 场景仅存储面试文字记录**，不上传录音文件
4. **流程巡检提醒每 3 天一次**，无上限
5. **计算月 offer 接受率时**，需在候选人流程状态中添加"已发 offer"和"offer 接受/拒绝"标记动作
6. **拟薪数字仅人事经理可见**
7. **招聘流程不可跳步**：未背调不能填拟薪、未审批薪资不能发 offer、offer 未接受禁核验
8. **简历同一时刻只属于一个库**，库间移动 = 流程状态变化的结果
9. **文字记录只挂面试预约**，不存在独立"记录库"
10. **候选人的所有流程动作只能从"招聘流程实例"内进入**，不存在脱离实例的独立面试管理页
11. **所有日期时间写入必须转 epoch 秒**，禁止 ISO 字符串/毫秒直写
12. **业务数据只准走 arcubase typed client**，禁用 octopus.api 里的 Arcubase 代理写业务数据
13. **权限必须 access-rule 后端强制**，角色单一权威源为平台，禁止在表/脚本/前端重复维护角色名单
14. **简历文件存储采用 KB 三段式链路**，文件本体存储于平台 fileGateway，行内记录 logicalPath 指针
15. **Arcubase 的 file 类型字段仅支持存储平台 OSS upload 流程的产物**，禁止存储自定义知识库指针（会被平台自动清洗）

---

## 9. 工程约定

### 9.1 面试预约

- 面试官选择范围为对应需求部门下的所有成员（含子部门成员），采用下拉框选择
- 面试官默认设置为当前登录人（若在该部门内），否则默认选中部门第一个成员
- 部门对接人默认发部门领导本人（即面试官），推荐时可手动修改

### 9.2 流程与提醒

- 流程巡检阈值默认 3 个工作日，系统可设置
- 招聘周期计算从推荐日到入职日
- 月招聘完成率 = 当月实际到岗人数 ÷ 当月计划到岗人数
- 用人需求提出人 = 部门领导或人事专员，均需人事经理审批后生效
- 待定转"人才库"时默认进储备人才库
- 流程暂停期间该实例的超时提醒一并暂停，恢复后重新计时

### 9.3 用户卡片显示

- 无部门：仅显示角色
- 单部门：显示"部门 | 角色"
- 多部门：显示"部门 等N个部门 | 角色"，鼠标悬停显示所有部门和角色
- 角色读取：`listMemberRoles(hostUserId)` 返回 `{arcabaseUserId, actorIds, actors[{id,name}]}`
- 部门读取：`listAllTeamMembers` 以"被搜到的部门 id"为权威

### 9.4 部门领导权限

- 新建需求时岗位下拉仅显示自己所在部门的岗位
- 人才推荐列表仅显示需求提出人/需求负责人为自己、或需求部门（含子部门）在自己管辖范围内的记录

### 9.5 人才推荐列表

- 统一显示"详情"按钮，点击打开抽屉展示完整推荐和候选人信息
- 同意/拒绝操作统一放在详情抽屉内执行，不在列表行直接显示操作按钮

### 9.6 退出/切换账号

- 右上角用户卡片有"切换账号/退出登录"按钮
- 点击后调用 `clearWorkbenchSession()` 清除本地 cookie、localStorage 中的会话信息
- 然后刷新页面跳转至平台登录页

### 9.7 面试文字记录附件

- 面试文字记录附件上传后存储于知识库
- 关联至简历材料表（T16），使用 `batchId = interview-{面试id}` 关联并标记为「面试附件」
- 不写入 T10 记录表的 attachment 字段

### 9.8 岗位管理技能字段

- 技能要求字段仅保留技能名，去掉等级字段
- 采用 subform 结构化存储，前端支持动态增删条目
- subform 读写必须使用 fieldId 作为 key（fieldId=1021），不可使用字段名
- 岗位编辑时需调用行级 get 接口获取完整行数据（列表接口仅返回 subform 摘要）

### 9.9 简历详情页

- 教育背景、工作经历、技能三个模块显示时行距设置为 150%
- 人才库列表页面不显示技能列

### 9.10 member 字段存储

- Arcubase member 字段需存 `arcabaseUserId`（数字），不是 `hostUserId`
- `viewer.id` 是平台 hostUserId，需通过 `listMemberRoles(viewer.id)` 转换
- `registerMemberNames` 同时注册 arcabaseUserId 和 userId，`memberLabel` 能解析两者

---

## 10. 踩坑记录

### 10.1 Arcubase access-rule 白名单模型

access-rule 采用白名单模型（无匹配规则 = 默认拒绝），多个 scope 项为 OR 关系。平台会自动为 admin/owner 配置直接绑定用户本人的 type=user 规则，即使解绑所有 actor，该规则依然生效。

### 10.2 数字员工简历解析 SSE 流

SSE 流读取存在事件格式不兼容问题，会导致正确的解析结果无法被前端正确接收，需通过控制台日志调试确认事件结构。

### 10.3 简历姓名提取正则回退

正则回退逻辑存在字段标签误匹配问题，会将"户籍"等非姓名字段误识别为姓名。**数字员工简历解析应直接保存返回的 JSON 结果，禁止使用正则回退逻辑**，避免产生脏数据。

### 10.4 简历解析前端超时

前端超时时间应设置为 5 分钟，避免因 PDF 处理耗时较长导致提前终止解析流程。

### 10.5 工作台用户信息显示错误

A 账号登录显示 B 账号姓名的根因为浏览器残留的旧账号 workbench 登录会话。**仅刷新 cookie 无法切换账号**，必须清除完整会话后重新登录。解决方案：调用 `clearWorkbenchSession()` 清除 cookie + localStorage。

### 10.6 面试文字记录附件存储

面试文字记录附件若直接写入 Arcubase 的 file 类型字段会被平台自动清洗，导致文件指针丢失无法下载。正确做法：存储至知识库，关联到简历材料表（T16）。

### 10.7 Arcubase subform 字段读写

`toArcubaseFields`/`fromArcubaseFields` 工具仅转换顶层字段的 fieldId 映射，**不会递归处理 subform 子行**。subform 子行必须手动使用 fieldId 进行读写，否则会出现数据无法存储、编辑无法回填的问题。

### 10.8 member 字段存无效 id 被清洗为 0

Arcubase member 字段存入无效 id（如 hostUserId）会被平台自动清洗为 0，导致姓名显示为"—"。必须存有效的 arcabaseUserId。

---

## 11. 常用运维 CLI 命令

### 11.1 Arcubase 行操作

```bash
# 查询表数据
octopus-cli arcubase row query \
  --app-id 2191603448 \
  --table-id 2191603449 \
  --body-json '{"limit":200,"offset":0}'

# 获取单行
octopus-cli arcubase row get \
  --app-id 2191603448 \
  --table-id 2191603449 \
  --body-json '{"id":2191757049}'

# 删除行
octopus-cli arcubase row delete \
  --app-id 2191603448 \
  --table-id 2191603449 \
  --body-json '{"selection":{"type":"ids","ids":[2191757049],"length":1}}'

# 批量删除
octopus-cli arcubase row delete \
  --app-id 2191603448 \
  --table-id 2191603451 \
  --body-json '{"selection":{"type":"ids","ids":[id1,id2,id3],"length":3}}'
```

### 11.2 KB 知识库管理

```bash
# 列出 KB 目录
octopus-cli configure kb directories list

# 创建 KB 目录
octopus-cli configure kb directories add \
  --body-json '{"path":"/kb/weida-recruitment-resumes","name":"weida-recruitment-resumes","parentPath":"/kb","markitdownEnabled":true,"autoBacklinkIndexEnabled":false,"autoRagVectorIndexEnabled":false}'

# 删除 KB 目录
octopus-cli configure kb directories remove <directory-id>

# 列出 KB 文件
octopus-cli configure file entries list \
  --query-json '{"rootKind":"kb","prefix":"weida-recruitment-resumes/"}' --json

# 删除 KB 文件
octopus-cli configure file remove \
  --body-json '{"rootKind":"kb","key":"weida-recruitment-resumes/batch-xxx/file.pdf"}' --json
```

### 11.3 项目发布

```bash
# 构建
cd weida-recruit/app
node node_modules/.bin/tsc -b && node node_modules/.bin/vite build

# 发布
octopus-cli coding projects publish vcp_c6daf31e-77e6-49c7-9df5-4ded587a144b --path dist --json

# Dryrun（查看发布计划不执行）
octopus-cli --dryrun coding projects publish vcp_c6daf31e-77e6-49c7-9df5-4ded587a144b --path dist --json
```

### 11.4 Codegen

```bash
# 表结构变更后重新生成 ingress 代码
cd weida-recruit/app
node node_modules/.bin/workbench-arcubase-codegen
```

### 11.5 平台管理

```bash
# 查看 Arcubase app 列表
octopus-cli arcubase-admin app list

# 查看表列表
octopus-cli arcubase-admin table list --app-id 2191603448

# 查看表 schema
octopus-cli arcubase-admin table get --app-id 2191603448 --table-id 2191603449

# 查看 access-rule
octopus-cli arcubase-admin access-rule list --app-id 2191603448 --table-id 2191603449
```

---

## 附录：关键 ID 速查

| 资源 | ID |
|------|-----|
| 项目 (Vibe Coding Project) | `vcp_c6daf31e-77e6-49c7-9df5-4ded587a144b` |
| 团队 (Team) | `team_75033186-9ec1-494c-8024-9b45bbe3dbdb` |
| Arcubase App | `2191603448` |
| KB 目录 weida-recruitment-resumes | 重建后 ID 变化，用 `configure kb directories list` 查询 |
| 工作台 URL | https://wb-rxbdg2tl3l.workbench.autostaff.cn |
| Host API Base | https://api.autostaff.cn |

---

*文档生成时间：2026-10-12*
*维护者交接：请先阅读本文档，再熟悉 `src/lib/syngy.ts` 和 `src/lib/tables.ts`，然后浏览各 Page 组件。*
