#!/usr/bin/env python3
"""韦达招聘演示数据造数脚本：按业务链路一致性写入 T1-T14。
红线：datetime 一律 epoch 秒；member 一律数字 arcubaseUserId；select 写文本。
"""
import json
import subprocess
import sys
from datetime import datetime, timedelta, timezone

APP = "2191603448"
TABLES = {
    "demands": "2191603449",
    "jobs": "2191603450",
    "resumes": "2191603451",
    "pipelines": "2191603452",
    "matches": "2191603453",
    "recommendations": "2191603454",
    "interviews": "2191603455",
    "feedbacks": "2191603456",
    "interviewRecords": "2191603457",
    "bgMaterials": "2191603458",
    "salaries": "2191603459",
    "offers": "2191603460",
    "onboardChecks": "2191603461",
    "reminders": "2191603462",
}

# 成员 arcubaseUserId
CESHI = 2190319126      # 测试平台（人事专员操作）
WANGHUI = 2190319128    # 王辉（人事经理）
QIUZHE = 2190324884     # 邱哲（部门领导）

TZ = timezone(timedelta(hours=8))
def ts(month, day, hour=9, minute=0):
    return int(datetime(2026, month, day, hour, minute, tzinfo=TZ).timestamp())

def create(table_key, fields):
    body = json.dumps({"fields": fields}, ensure_ascii=False)
    r = subprocess.run(
        ["octopus-cli", "arcubase", "row", "create", "--app-id", APP,
         "--table-id", TABLES[table_key], "--body-json", body],
        capture_output=True, text=True)
    try:
        out = json.loads(r.stdout)
        rid = out["data"]["data"]
        print(f"[{table_key}] +{rid}")
        return rid
    except Exception:
        print(f"[{table_key}] FAILED: {r.stdout[:300]} {r.stderr[:300]}", file=sys.stderr)
        return None

ids = {"jobs": {}, "demands": {}, "resumes": {}, "pipelines": {}, "interviews": {},
       "matches": {}, "recommendations": {}, "salaries": {}, "offers": {}}

# ---------- T2 岗位（新增5；前端已建 高级前端工程师=2191605272，存量 冲压工=2191605105） ----------
jobs = [
    ("采购专员", "采购部", "负责物资采购、供应商管理与比价", "1.大专及以上\n2.1-3年采购经验\n3.熟悉ERP系统", 0),
    ("CNC操作工", "一车间", "操作CNC加工中心，按图纸加工零部件", "1.20-40岁\n2.中专及以上\n3.会数控编程优先", 0),
    ("质检员", "一车间", "负责来料/过程/出厂检验", "1.大专及以上\n2.熟悉ISO9001\n3.会使用计量器具", 0),
    ("仓库管理员", "物流部", "负责仓储收发存与WMS系统维护", "1.高中及以上\n2.2年以上仓储经验\n3.会开叉车优先", 0),
    ("招聘专员", "人事部", "负责招聘全流程执行与渠道维护", "1.本科及以上\n2.1年以上招聘经验\n3.沟通能力强", 0),
]
for name, dept, jd, req, key in jobs:
    rid = create("jobs", {"1001": name, "1002": dept, "1003": jd, "1004": req, "1006": 0, "1007": "启用"})
    ids["jobs"][name] = rid
ids["jobs"]["高级前端工程师"] = 2191605272
ids["jobs"]["冲压工"] = 2191605105

# ---------- T1 用人需求单（新增6；存量4：前端=通过, 冲压工x2+采购=待审批） ----------
demands = [
    ("CNC操作工", "一车间", 3, "2026-11", 0, "通过", QIUZHE, "部门领导", QIUZHE, WANGHUI, ts(10, 8, 10), ""),
    ("质检员", "一车间", 2, "2026-10", 0, "通过", CESHI, "人事专员", QIUZHE, WANGHUI, ts(10, 8, 11), ""),
    ("采购专员", "采购部", 1, "2026-11", 0, "通过", QIUZHE, "部门领导", QIUZHE, WANGHUI, ts(10, 9, 9), ""),
    ("招聘专员", "人事部", 1, "2026-12", 0, "通过", CESHI, "人事专员", 0, WANGHUI, ts(10, 9, 10), ""),
    ("仓库管理员", "物流部", 1, "2026-11", 0, "驳回", QIUZHE, "部门领导", 0, WANGHUI, ts(10, 8, 15), "物流部编制冻结，暂缓招聘"),
    ("设备工程师", "技术部", 1, "2026-12", 1, "草稿", CESHI, "人事专员", 0, 0, 0, ""),
]
for name, dept, hc, month, key, status, proposer, prole, owner, approver, ats, comment in demands:
    f = {"1001": proposer, "1002": prole, "1003": dept, "1004": name, "1005": hc,
         "1006": month, "1007": key, "1008": status}
    if owner:
        f["1013"] = owner
    if approver:
        f["1009"] = approver
        f["1010"] = ats
    if comment:
        f["1011"] = comment
    rid = create("demands", f)
    ids["demands"][name] = rid
ids["demands"]["高级前端工程师"] = 2191604451

# ---------- T3 简历（13条） ----------
resumes = [
    # name, phone, gender, age, edu, school, years, skills, salary, avail, channel, library, pstatus
    ("张伟", "13800000001", "男", 28, "本科", "苏州大学", 5, "React,TypeScript,Node.js", "18K-22K", "2026-11-01", "boss直聘", "应聘简历库", "面试"),
    ("周婷", "13800000002", "女", 27, "硕士", "东南大学", 5, "React,Vue,前端架构", "22K-26K", "2026-11-15", "猎头推荐", "关键岗位人才库", "背调"),
    ("王强", "13800000003", "男", 30, "大专", "南通职业大学", 8, "CNC,数控编程,法兰克系统", "10K-12K", "2026-10-20", "前程无忧", "应聘简历库", "拟薪"),
    ("李娜", "13800000004", "女", 26, "硕士", "南京大学", 3, "数控工艺,CAM", "13K-15K", "2026-11-01", "猎聘", "应聘简历库", "拟薪"),
    ("吴磊", "13800000005", "男", 29, "本科", "南京工业大学", 7, "机械设计,CAD,CNC", "12K-14K", "2026-11-10", "官网投递", "应聘简历库", "面试"),
    ("罗军", "13800000006", "男", 32, "大专", "常州工学院", 10, "CNC,五轴加工", "11K-13K", "2026-10-15", "前程无忧", "应聘简历库", "核验"),
    ("陈静", "13800000007", "女", 27, "本科", "江苏大学", 4, "质量管理,ISO9001,计量", "9K-11K", "2026-11-01", "智联招聘", "应聘简历库", "offer"),
    ("郑爽", "13800000008", "女", 25, "大专", "无锡职业技术学院", 3, "质检,计量器具", "7K-9K", "2026-10-25", "前程无忧", "风险受控", "结束"),
    ("刘洋", "13800000009", "男", 28, "本科", "扬州大学", 6, "采购,供应链,ERP", "10K-12K", "2026-10-12", "boss直聘", "应聘简历库", "核验"),
    ("赵敏", "13800000010", "女", 24, "本科", "苏州科技大学", 2, "招聘,人力资源,校招", "7K-9K", "2026-11-20", "内推", "应聘简历库", "待推荐"),
    ("何静", "13800000011", "女", 26, "本科", "江南大学", 4, "招聘,员工关系", "8K-10K", "2026-10-18", "智联招聘", "应聘简历库", "核验"),
    ("孙杰", "13800000012", "男", 31, "大专", "常州工学院", 9, "仓储管理,WMS,采购", "9K-11K", "2026-11-05", "拉勾", "应聘简历库", "offer"),
    ("徐亮", "13800000013", "男", 27, "本科", "南通大学", 4, "React,小程序", "13K-16K", "2026-12-01", "boss直聘", "储备人才库", "暂停"),
]
for name, phone, gender, age, edu, school, years, skills, salary, avail, channel, lib, pstatus in resumes:
    rid = create("resumes", {
        "1001": name, "1002": phone, "1004": gender, "1005": age, "1006": edu,
        "1007": school, "1008": years, "1009": skills, "1010": salary, "1011": avail,
        "1013": channel, "1014": lib, "1015": pstatus, "1016": "已解析", "1017": "上传",
    })
    ids["resumes"][name] = rid

# ---------- T4 流程实例（13条） ----------
# (resume, demand, stage, stage_ts, started_ts)
pipes = [
    ("张伟", "高级前端工程师", "面试", ts(10, 8, 14), ts(10, 3, 10)),
    ("周婷", "高级前端工程师", "背调", ts(10, 8, 16), ts(10, 2, 9)),
    ("王强", "CNC操作工", "拟薪", ts(10, 9, 9), ts(10, 4, 11)),
    ("李娜", "CNC操作工", "拟薪", ts(10, 9, 10), ts(10, 4, 14)),
    ("吴磊", "CNC操作工", "面试", ts(10, 8, 9), ts(10, 6, 10)),
    ("罗军", "CNC操作工", "核验", ts(10, 7, 9), ts(10, 1, 9)),
    ("陈静", "质检员", "offer", ts(10, 8, 17), ts(10, 3, 15)),
    ("郑爽", "质检员", "结束", ts(10, 6, 18), ts(10, 2, 10)),
    ("刘洋", "采购专员", "核验", ts(10, 7, 14), ts(10, 2, 16)),
    ("赵敏", "招聘专员", "待推荐", ts(10, 9, 8), ts(10, 8, 20)),
    ("何静", "招聘专员", "核验", ts(10, 8, 9), ts(10, 1, 14)),
    ("孙杰", "采购专员", "offer", ts(10, 9, 11), ts(10, 5, 9)),
    ("徐亮", "高级前端工程师", "暂停", ts(10, 7, 12), ts(10, 4, 9)),
]
for resume, demand, stage, sts, started in pipes:
    rid = create("pipelines", {
        "1001": str(ids["resumes"][resume]), "1002": str(ids["demands"][demand]),
        "1003": stage, "1004": sts, "1005": started,
    })
    ids["pipelines"][resume] = rid

# ---------- T5 匹配结果（7条） ----------
matches = [
    ("张伟", "合适", 86, "命中：React、TypeScript、5年经验", "自动", ts(10, 3, 10)),
    ("周婷", "合适", 91, "命中：前端架构、硕士学历", "自动", ts(10, 2, 9)),
    ("王强", "合适", 78, "命中：CNC、8年经验", "自动", ts(10, 4, 11)),
    ("李娜", "待定", 55, "部分命中：数控工艺，经验略浅", "自动", ts(10, 4, 14)),
    ("吴磊", "待定", 45, "部分命中：机械设计，CNC经验待确认", "手动", ts(10, 6, 10)),
    ("罗军", "合适", 82, "命中：五轴加工、10年经验", "自动", ts(10, 1, 9)),
    ("郑爽", "不合适", 22, "经验与学历不匹配", "自动", ts(10, 2, 10)),
]
for resume, tier, score, details, source, ats in matches:
    create("matches", {
        "1001": str(ids["pipelines"][resume]), "1002": tier, "1003": score,
        "1004": details, "1005": source, "1006": ats,
    })

# ---------- T6 推荐记录（5条） ----------
recs = [
    ("张伟", "同意面试", "企微", ts(10, 3, 18)),
    ("周婷", "同意面试", "工作台", ts(10, 3, 9)),
    ("王强", "同意面试", "企微", ts(10, 5, 10)),
    ("赵敏", "未反馈", "企微", 0),
    ("郑爽", "不面试", "企微", ts(10, 3, 11)),
]
for resume, fb, ch, ats in recs:
    f = {"1001": str(ids["pipelines"][resume]), "1002": CESHI, "1003": QIUZHE,
         "1004": f"{resume}：技能与岗位匹配度较高，建议安排面试。",
         "1005": fb, "1006": ch}
    if ats:
        f["1007"] = ats
    rid = create("recommendations", f)
    ids["recommendations"][resume] = rid

# ---------- T7 面试预约（6条） ----------
interviews = [
    ("张伟", 1, "线下", ts(10, 6, 14), "", "完成"),
    ("张伟", 2, "线上", ts(10, 11, 10), "882-4412-5566", "已约"),
    ("王强", 1, "线下", ts(10, 5, 9, 30), "", "完成"),
    ("陈静", 1, "线上", ts(10, 4, 15), "771-2201-8834", "完成"),
    ("刘洋", 1, "线下", ts(10, 3, 10), "", "完成"),
    ("吴磊", 1, "线上", ts(10, 12, 14), "660-1187-3302", "改期"),
]
for resume, rnd, mode, ats, mno, status in interviews:
    f = {"1001": str(ids["pipelines"][resume]), "1002": rnd, "1003": mode,
         "1004": ats, "1005": QIUZHE, "1007": status}
    if mno:
        f["1006"] = mno
    rid = create("interviews", f)
    ids["interviews"][f"{resume}-{rnd}"] = rid

# ---------- T8 面试反馈（4条） ----------
feedbacks = [
    ("张伟-1", "录取", "基础扎实，项目经验丰富，建议二面。", ts(10, 6, 17)),
    ("王强-1", "录取", "实操能力强，可独立编程操机。", ts(10, 5, 12)),
    ("陈静-1", "再次面试", "质量工具掌握一般，建议加一轮专业面。", ts(10, 4, 17)),
    ("刘洋-1", "录取", "采购流程熟悉，沟通顺畅。", ts(10, 3, 12)),
]
for ikey, result, comment, ats in feedbacks:
    create("feedbacks", {"1001": str(ids["interviews"][ikey]), "1002": result,
                         "1003": comment, "1004": QIUZHE, "1005": ats})

# ---------- T9 面试文字记录（3条） ----------
records = [
    ("张伟-1", "Q：介绍最近的项目？A：主导了MES系统前端重构，使用React18+TS，落地了虚拟滚动优化大数据量表格。Q：对微前端了解？A：有qiankun实践经验。"),
    ("王强-1", "现场实操：给定图纸完成编程与装夹，耗时38分钟，精度达标。沟通中体现出较强的质量意识。"),
    ("陈静-1", "Q：熟悉哪些质量工具？A：SPC、FMEA有接触但不深入。Q：如何处理批量不良？A：先隔离再追溯，回答思路清晰。"),
]
for ikey, content in records:
    create("interviewRecords", {"1001": str(ids["interviews"][ikey]), "1002": content,
                                "1004": CESHI, "1005": ts(10, 7, 10)})

# ---------- T10 背调材料（4条，附件留空） ----------
bgs = [("周婷", "学历证明"), ("王强", "薪资流水"), ("李娜", "学历证明"), ("李娜", "离职证明")]
for resume, mtype in bgs:
    create("bgMaterials", {"1001": str(ids["pipelines"][resume]), "1002": mtype,
                           "1004": CESHI, "1005": ts(10, 8, 15)})

# ---------- T11 拟薪（5条） ----------
salaries = [
    ("王强", 12000, "期望10K-12K，按上限申请", "待审批", 0, 0, 0, ""),
    ("李娜", 15000, "期望13K-15K", "修改后通过", 13500, WANGHUI, ts(10, 9, 14), "按职级带宽调整为13.5K"),
    ("陈静", 10000, "期望9K-11K，按中位申请", "通过", 10000, WANGHUI, ts(10, 8, 16), ""),
    ("刘洋", 11000, "期望10K-12K", "通过", 11000, WANGHUI, ts(10, 7, 11), ""),
    ("孙杰", 13500, "期望9K-11K，候选人要价偏高", "驳回", 0, WANGHUI, ts(10, 9, 15), "超预算15%，请重新谈薪"),
]
for resume, amount, note, status, final, approver, ats, comment in salaries:
    f = {"1001": str(ids["pipelines"][resume]), "1002": amount, "1003": note, "1004": status}
    if final:
        f["1005"] = final
    if approver:
        f["1006"] = approver
        f["1007"] = ats
    if comment:
        f["1008"] = comment
    rid = create("salaries", f)
    ids["salaries"][resume] = rid

# ---------- T12 Offer（5条） ----------
offers = [
    ("陈静", "已发", ts(10, 8, 18)),
    ("刘洋", "接受", ts(10, 7, 15)),
    ("郑爽", "拒绝", ts(10, 6, 9)),
    ("罗军", "接受", ts(10, 5, 16)),
    ("何静", "接受", ts(10, 8, 10)),
]
for resume, status, ats in offers:
    create("offers", {"1001": str(ids["pipelines"][resume]), "1002": status,
                      "1003": CESHI, "1004": ats})

# ---------- T13 到岗核验（3条） ----------
checks = [
    ("刘洋", "已到岗", ts(10, 9, 9), ""),
    ("罗军", "已到岗", ts(10, 8, 9), ""),
    ("何静", "提前说明不来", ts(10, 9, 10), "候选人家庭原因放弃入职"),
]
for resume, result, ats, remark in checks:
    f = {"1001": str(ids["pipelines"][resume]), "1002": result, "1003": CESHI, "1004": ats}
    if remark:
        f["1005"] = remark
    create("onboardChecks", f)

# ---------- T14 提醒任务（6条） ----------
reminders = [
    ("审批超时", "需求", "2191605108", WANGHUI, "企微+系统", ts(10, 12, 9), "待发", 0),
    ("审批超时", "拟薪", str(ids["salaries"]["王强"]), WANGHUI, "企微", ts(10, 9, 9), "已发", 1),
    ("反馈超时", "推荐", str(ids["recommendations"]["赵敏"]), QIUZHE, "企微", ts(10, 8, 18), "已发", 2),
    ("面试前", "面试", str(ids["interviews"]["张伟-2"]), QIUZHE, "企微+系统", ts(10, 11, 9, 30), "待发", 0),
    ("上传记录", "面试", str(ids["interviews"]["王强-1"]), QIUZHE, "系统", ts(10, 6, 9), "停止", 3),
    ("核验提醒", "流程", str(ids["pipelines"]["何静"]), CESHI, "企微", ts(10, 13, 9), "待发", 0),
]
for rtype, reftype, refid, target, ch, ats, status, cnt in reminders:
    create("reminders", {"1001": rtype, "1002": reftype, "1003": refid, "1004": target,
                         "1005": ch, "1006": ats, "1007": status, "1008": cnt})

print("\n=== 造数完成 ===")
print(json.dumps({k: {kk: vv for kk, vv in v.items()} for k, v in ids.items()}, ensure_ascii=False, indent=1))
