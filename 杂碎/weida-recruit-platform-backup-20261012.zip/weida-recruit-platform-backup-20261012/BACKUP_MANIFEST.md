# 韦达招聘平台备份清单

备份日期：2026-10-12（Asia/Shanghai）

本目录是在任何修复发生前生成的只读快照。

## 平台上下文

- Octopus CLI：`0.1.13`
- Profile：`xiaozhangyu-test`
- Host：`https://api.autostaff.cn`
- 团队：嘉午台
- Team ID：`team_75033186-9ec1-494c-8024-9b45bbe3dbdb`
- Workbench 项目 ID：`vcp_c6daf31e-77e6-49c7-9df5-4ded587a144b`
- Arcubase App ID：`2191603448`
- 数字员工 ID：`de_75dd727a-e56a-47b8-b4dc-1c9c75b176e1`

## 目录内容

- `source/weida-recruit/`：当前项目源码、设计、运维文件、本地附件和已发布构建产物；不含 `node_modules`。
- `source/weida-recruit-handover.zip`：原始项目移交包。
- `platform/workbench/`：线上 Workbench 项目元数据。
- `platform/team/`：嘉午台团队元数据。
- `platform/digital-employee/`：数字员工列表、详情、运行配置、Arcubase 绑定、团队技能、Station、知识库访问、汇报关系等。
- `platform/arcubase/`：App 元数据、16 张表的实时结构、访问规则和行数据导出。

## Arcubase 数据快照

| 表 ID | 表名 | 导出行数 |
| --- | --- | ---: |
| 2191603449 | 用人需求单 | 1 |
| 2191603450 | 岗位 | 3 |
| 2191603451 | 简历 | 0 |
| 2191603452 | 招聘流程实例 | 0 |
| 2191603453 | 匹配结果 | 0 |
| 2191603454 | 推荐记录 | 0 |
| 2191603455 | 面试预约 | 0 |
| 2191603456 | 面试反馈 | 0 |
| 2191603457 | 面试文字记录 | 0 |
| 2191603458 | 背调材料 | 0 |
| 2191603459 | 拟薪 | 0 |
| 2191603460 | Offer 记录 | 0 |
| 2191603461 | 到岗核验 | 0 |
| 2191603462 | 提醒任务 | 0 |
| 2191603463 | 系统配置 | 8 |
| 2191605785 | 简历材料 | 未获授权 |

## 已知导出限制

1. 当前账号对表 `2191605785` 没有可读 ingress，CLI 返回 `POLICY_ID_RESOLUTION_FAILED`；原始错误保存在该表目录的 `export-error.txt`。
2. 数字员工 `workspace-access list` 接口返回非标准 JSON，原始错误保存在数字员工目录的 `workspace-access-error.txt`。
3. Workbench CLI 当前只提供项目元数据查询，没有远端源码下载命令；备份中的源码取自当前维护目录。该目录的业务源码与移交包一致，并包含本地发布构建产物。
4. CLI 登录凭据、令牌、`node_modules` 和本机缓存未打包。

