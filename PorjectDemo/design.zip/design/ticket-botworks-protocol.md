# Ticket BotWorks Protocol

## Direction 1: BotWorks -> Ticket

BotWorks calls ticket redemption APIs:

- `POST /api/biz/v1/redemptions/reserve`
- `POST /api/biz/v1/redemptions/{redemptionId}/confirm`
- `POST /api/biz/v1/redemptions/{redemptionId}/cancel`

Auth:

```http
X-Ticket-Access-Key: tbk_x
X-Ticket-Timestamp: 1781195916
X-Ticket-Nonce: nonce_x
X-Ticket-Signature: v1=<signature>
Idempotency-Key: <stable key>
```

Ticket validates the signature against a project-level `ProjectServiceCredential`.
No bearer token, global internal key, or alternate inbound auth header is accepted for this protocol.

Signature canonical string:

```text
METHOD
PATH
RAW_QUERY
SHA256_HEX(BODY)
TIMESTAMP
NONCE
```

Signature value:

```text
v1=hex(hmac_sha256(secretKey, canonical_string))
```

Provisioning flow:

1. Ticket platform admin creates a Ticket tenant and grants tenant admin phone numbers.
2. Ticket tenant admin logs in to the tenant console.
3. Ticket tenant admin opens a Ticket Project.
4. Ticket tenant admin creates products. Each product stores one fixed fulfillment JSON object; template variables are not supported.
5. Ticket tenant admin creates a `ProjectServiceCredential` on that project.
6. Ticket returns `accessKeyID + secretKey` once.
7. The external business system stores the project credential in its own configuration.
8. BotWorks, as one external client, stores it through `PUT /tenant-admin/v1/ticket-platform/configs`.
9. BotWorks signs `/api/biz/v1/redemptions/*` requests with that project credential.
10. Ticket derives `ticketTenantID` and `ticketProjectID` from `ProjectServiceCredential`; request body `tenantId` or `projectId` is never the authorization source.

Platform admin APIs do not expose Ticket Project or `ProjectServiceCredential` management. Project credentials are tenant-scope operational assets and must be created from the tenant console.

Reserve request:

```json
{
  "code": "CODE-1",
  "subject": {
    "subjectType": "team",
    "subjectId": "team_1"
  }
}
```

Confirm request:

```json
{
  "resultRef": "assignment_1"
}
```

Cancel request:

```json
{
  "reason": "botworks_apply_failed"
}
```

Redemption response:

```json
{
  "id": "rdm_1",
  "tenantId": "ticket_tenant_1",
  "status": "reserved",
  "fulfillmentPayload": {
    "package_id": "ep_ae7dd91e-6b80-48bd-9d75-1313ba22ab30",
    "points": 5000,
    "usage_allowances": [
      "uad_example"
    ]
  },
  "subject": {
    "subjectType": "team",
    "subjectId": "team_1"
  },
  "reservedAt": "2026-06-12T00:00:00Z",
  "confirmedAt": "",
  "canceledAt": ""
}
```

## Direction 2: Ticket -> BotWorks

Ticket delivers redemption lifecycle webhooks to BotWorks:

```http
POST /internal/v1/ticket/webhooks/redemptions
X-Ticket-Event-ID: who_x
X-Ticket-Timestamp: 1781195916
X-Ticket-Signature: v1=<signature>
Content-Type: application/json
```

Payload:

```json
{
  "event_type": "redemption.confirmed",
  "redemption_id": "rdm_1",
  "redemption": {
    "redemption_id": "rdm_1",
    "status": "confirmed",
    "confirmed_at": "2026-06-12T00:00:00Z",
    "fulfillment_payload": {
      "package_id": "ep_ae7dd91e-6b80-48bd-9d75-1313ba22ab30",
      "points": 5000,
      "usage_allowances": [
        "uad_example"
      ]
    }
  }
}
```

Signature:

```text
v1=hex(hmac_sha256(secret, eventID + "." + timestamp + "." + body))
```

Config mapping:

```text
Ticket WEBHOOK_DELIVERY_URL -> downstream redemption webhook endpoint
Ticket WEBHOOK_DELIVERY_SECRET == downstream shared webhook verification secret
```

## Idempotency

- BotWorks -> ticket uses `Idempotency-Key`.
- Ticket -> BotWorks uses `X-Ticket-Event-ID`.
- Ticket retries must reuse the same event ID.
- BotWorks ignores duplicate webhook event IDs.

## Product payload contract

- Ticket stores product fulfillment as a fixed JSON object.
- Ticket does not interpret BotWorks fields such as `package_id`, `points`, or `usage_allowances`.
- Ticket does not support template variables or runtime substitution.
- BotWorks owns the meaning and validation of the JSON after redemption.
