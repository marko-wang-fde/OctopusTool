# Ticket Web 统一前端部署设计

## 背景

Ticket 当前线上只部署了 `ticket-host` 后端 API。`admin`、`tenant`、`portal`、`pay` 是独立 Vite 前端项目，但没有生产构建镜像、k8s 部署模型和 Ingress 入口。

如果每个前端项目各自构建一个镜像，会产生过多镜像、Deployment、Service、Ingress 和 CI workflow。Ticket 前端本质上是静态资源，不应该因为应用数量增加而扩散运行时模型。

## 目标

Ticket 前端统一收敛为一个镜像：

```text
ticket-web
├── admin/dist
├── tenant/dist
├── portal/dist
└── pay/dist
```

运行时由 nginx 根据 Host 分发到不同静态目录：

```text
ticket-admin.autostaff.cn   -> admin
ticket-tenant.autostaff.cn  -> tenant
ticket-portal.autostaff.cn  -> portal
ticket-pay.autostaff.cn     -> pay
```

Ticket API 保持独立：

```text
ticket.autostaff.cn -> ticket-host
```

## 名词

- `ticket-host`：Ticket 后端 API 服务镜像。
- `ticket-web`：Ticket 所有前端静态资源的统一服务镜像。
- `frontend app`：`admin`、`tenant`、`portal`、`pay` 中的任意一个 Vite 应用。
- `frontend host`：访问某个 frontend app 的独立域名。生产域名必须位于 `*.autostaff.cn` 这一层级，以复用现有 `tls-autostaff-cn` 证书。
- `API base URL`：前端编译时注入的后端 API 地址，生产环境固定为 `https://ticket.autostaff.cn`。

## 架构决策

采用单一 `ticket-web` 镜像，不把前端嵌入 `ticket-host`。

理由：

1. 前端是静态资源，使用 nginx 单独服务更直接。
2. `ticket-host` 保持 API 职责，不混入 SPA fallback 和静态文件路由。
3. 多个前端共用一个镜像，避免镜像数量膨胀。
4. 当前 frontend app 都使用根路径路由，按子域名部署可以避免修改 router base 和 Vite base。
5. 前端变更只发布 `ticket-web`，后端变更只发布 `ticket-host`。

## 构建模型

`ticket-web` 的 Docker build 分为两个阶段：

1. `node` builder 阶段：
   - 分别进入 `admin`、`tenant`、`portal`、`pay`
   - 使用 `npm ci`
   - 使用 `npm run build`
   - 编译时注入 `VITE_API_BASE_URL=https://ticket.autostaff.cn`

2. nginx runtime 阶段：
   - 拷贝四个 `dist`
   - 根据 `server_name` 指向不同目录
   - 每个 frontend host 都使用 SPA fallback：`try_files $uri $uri/ /index.html`

## k8s 模型

新增：

- `Deployment/ticket-web`
- `Service/ticket-web`
- `Ingress/ticket-web`

`ticket-web` 只负责前端域名：

```text
ticket-admin.autostaff.cn
ticket-tenant.autostaff.cn
ticket-portal.autostaff.cn
ticket-pay.autostaff.cn
```

`ticket-host` 继续负责：

```text
ticket.autostaff.cn
```

`tls-autostaff-cn` 当前覆盖 `*.autostaff.cn`，不覆盖 `*.ticket.autostaff.cn`，因此前端域名使用 `ticket-admin.autostaff.cn` 这类一级通配符域名，而不是 `admin.ticket.autostaff.cn`。

## CI 模型

新增 `build-ticket-web` workflow：

- push 到 `main` 且影响前端、web Dockerfile、nginx 配置或 workflow 时触发
- 支持 `workflow_dispatch`
- 使用 npm，不使用 pnpm
- 构建并推送：

```text
syngy-registry.cn-shanghai.cr.aliyuncs.com/syngy/ticket-web:<app_version>
syngy-registry.cn-shanghai.cr.aliyuncs.com/syngy/ticket-web:latest
```

workflow 只构建镜像，不自动修改 k8s manifest，不自动 apply。

## 不采用的方案

### 每个前端一个镜像

不采用。镜像、Deployment、Service、Ingress、workflow 数量都会扩散。

### 嵌入 ticket-host

不采用。会让 API 服务承担静态资源和 SPA fallback，前端变更也会强制重建后端镜像。

### 同域名路径挂载

不采用。当前前端使用根路径 history 路由，路径挂载需要修改 Vite base、router base 和 nginx rewrite，复杂度高于子域名。

## 验收标准

1. 仓库存在唯一前端镜像构建入口 `web/Dockerfile`。
2. `ticket-web` 同时包含 `admin`、`tenant`、`portal`、`pay` 四个 dist。
3. nginx 按 Host 分发到对应 frontend app。
4. k8s manifest 中前端只新增一个 Deployment 和一个 Service。
5. CI 只新增一个前端镜像 workflow。
6. 所有构建命令使用 npm。
7. 不改变 `ticket-host` 的 API 路由职责。
