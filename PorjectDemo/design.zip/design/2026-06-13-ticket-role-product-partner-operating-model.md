# Ticket 角色、产品与 Partner 经营模型结论

本文档记录 2026-06-13 已确认的 Ticket 业务结论，作为后续设计、实现、review 的权威输入。若旧文档、旧代码、旧页面与本文档冲突，以本文档为准并清理旧内容。

## 1. 架构原则

- `single success path`：同一能力只能保留一条正确路径。文档、代码、API、前端入口必须指向同一套模型和接口。
- `no fallback`：不允许旧路径兼容、mock、占位 API、`unsupportedApi`、静默降级。
- `fastfail`：权限、上下文、资源归属、参数错误必须立即失败，并返回可执行错误信息。
- API 契约唯一来源是 Go controller/VO 的 swag 注解；前端只能通过 swagger 生成的 TS SDK 调用 API。
- 不能把“当前未开发完”解释成“业务不需要”。未完成能力应被明确列为目标能力，再按闭环阶段实现。

## 2. 角色边界

### 平台管理员

平台管理员只负责 Ticket 平台级租户治理：

- 管理 Ticket 租户。
- 管理租户管理员手机号授权。

平台管理员不负责：

- 项目管理。
- 项目密钥管理。
- 产品管理。
- Partner 管理。
- 卡券、配额、购买链接、订单、划拨、分享、导出。

### 租户管理员

租户管理员负责租户内项目运营：

- 管理项目。
- 分配项目密钥。
- 邀请和管理 Partner。
- 管理项目中的产品。
- 管理产品对应的卡券列表、配额、购买链接、订单、划拨、分享、导出，并在产品详情页查看资产聚合。

租户管理员视角是项目全量运营视角。

### Partner

Partner 是项目下的合作伙伴/渠道/分销或分享参与方。

Partner 可以在自己被授权和可见范围内进行：

- 卡券列表。
- 配额。
- 购买链接。
- 订单。
- 划拨。
- 分享。
- 导出。

Partner 视角不是平台全量视角，也不是租户全量视角；Partner 只看自己及可见下游范围。

## 3. 产品名词

已确认：产品就是当前代码中的 `Template/SKU`。

- 后端模型可以继续使用 `Template`。
- 前端和业务文案统一显示为“产品”。
- `SKU` 是产品在售卖/履约语境下的说法。
- 不新增独立 `Product` 模型，避免 `Product`、`Template`、`SKU` 三套实体并存。

产品是卡券库存、配额、购买链接、订单、划拨和履约 JSON 的核心归属对象。资产不是独立资源，而是产品详情页里的聚合视图。

产品详情只保留页面 `/projects/:projectId/products/:productId`。产品列表不提供快速查看 Sheet；Sheet 只能用于轻量表单或确认，不承载产品主详情。

资产(Asset Summary)不是独立页面或独立资源模型。资产只作为产品详情页中的聚合视图存在，展示该产品维度下的项目库存、Partner 库存、Partner 配额和最近划拨。

Quota lifecycle:
1. Tenant Admin grants product quota to Partner.
2. Partner consumes available quota to generate owned Codes.
3. Partner allocates available quota to another Partner.
4. All quota consume/allocate writes are transactional and row-locked.

## 4. 产品履约 JSON

产品包含履约时通知 BotWorks 等业务系统的 JSON。

已确认：不支持模板变量。

含义：

- 产品上保存的是确定的 JSON 配置。
- 履约时不会使用字符串模板变量替换。
- 不允许前端临时拼接履约 JSON。
- 不允许 fallback 到默认 payload。
- 不允许根据未声明字段猜测 payload。

履约通知链路：

```text
Ticket Product(Template/SKU)
→ Code / Order / Redemption 上下文
→ 读取产品定义中的 fulfillment JSON
→ Ticket webhook 通知 BotWorks 等业务系统
→ BotWorks 根据 JSON 执行套餐/权益发放
```

如果后续需要在履约 payload 中携带订单、券码、Partner 等动态字段，必须另行定义结构化字段和确定性组装规则；不能以模板变量形式实现。

## 5. 租户端信息架构

租户端应围绕项目展开：

```text
/projects
/projects/:projectId/overview
/projects/:projectId/service-credentials
/projects/:projectId/products
/projects/:projectId/products/:productId
/projects/:projectId/partners
/projects/:projectId/partners/:partnerId
/projects/:projectId/codes
/projects/:projectId/quotas
/projects/:projectId/purchase-links
/projects/:projectId/orders
/projects/:projectId/allocations
/projects/:projectId/shares
/projects/:projectId/exports
/members
/profile
```

说明：

- `products` 对应当前 `templates` 能力，但 UI 文案应使用“产品”。
- 租户端可以看到项目全量。
- 项目密钥只能在租户端项目上下文中创建、查看、轮换、禁用。
- Partner 邀请使用手机号；不要求先存在账号。

## 6. Partner 端信息架构

Partner 端使用手机号登录，不使用伙伴编号/密码登录。

Partner 端应围绕当前 Partner 身份展开：

```text
/login
/partners/:partnerId/overview
/partners/:partnerId/products
/partners/:partnerId/codes
/partners/:partnerId/quotas
/partners/:partnerId/purchase-links
/partners/:partnerId/orders
/partners/:partnerId/allocations
/partners/:partnerId/shares
/partners/:partnerId/exports
/partners/:partnerId/profile
```

说明：

- Partner 能力不是“未实现就删除”的能力，而是必须设计和实现的目标能力。
- Partner 只能访问自己及可见下游范围内的数据。
- Partner 不能定义租户全局产品；Partner 使用租户管理员定义的产品。
- Partner 可以基于产品创建购买链接、查看订单、管理自己范围内配额/券码/划拨/分享/导出，并在产品上下文查看资产聚合。

## 7. Mobbin 交互参考结论

已参考的交互模式：

- Linear 类后台列表/详情：适合项目、产品、订单、券码列表与详情 Sheet。
- Lemon Squeezy / Gumroad / Whop 类商户后台：适合产品、订单、销售与 Partner 经营视角。
- Dub 类链接后台：适合购买链接、分享、归因。
- Shopify Discounts / Podia Coupon 创建流程：适合产品/券码/优惠配置的创建流程。

Ticket 的交互应采用：

- 左侧稳定导航。
- 项目或 Partner 作为当前上下文。
- 列表页负责筛选、扫描、批量动作。
- 产品主详情使用页面；Sheet 只用于轻量表单、短上下文编辑或确认。
- 创建复杂资源使用分步表单或独立页面。
- 不暴露无后端契约的假入口。

## 8. 后续修正方向

必须修正此前错误收窄造成的影响：

- 恢复文档中租户端和 Partner 端的完整经营能力边界。
- 将 UI 中的 Template 文案收敛为“产品”。
- Partner 端补齐产品、卡券、配额、购买链接、订单、划拨、分享、导出目标路径；资产聚合挂在产品上下文。
- 后端按 controller 注解补齐对应 API，再生成 TS SDK，再改前端。
- 所有旧的错误边界文档和错误页面逻辑必须清理，不允许并存。
