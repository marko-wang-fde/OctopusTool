# 10 - 对齐验收证据

本文档记录当前 Ticket 角色边界与前后端可达性的验收命令。

## 当前唯一契约

- Platform Console：只管理 Ticket 租户与租户管理员手机号。
- Tenant Console：管理项目、项目密钥、产品、券码、合作伙伴、配额、购买链接、订单、划拨、分享、导出；资产聚合在产品详情页查看。
- Partner Portal：手机号登录、身份选择/激活、管理自己可访问的产品、券码、配额、购买链接、订单、划拨、分享、导出；资产聚合在产品上下文查看。
- Biz API：项目级 HMAC 密钥调用核销 TCC API，并接收产品固定履约 JSON。

## 验收命令

```bash
cd host
test -z "$(gofmt -l .)"
go test ./src/...
make -f Makefile.swagger swagger-check
cd ..
npm --prefix admin run build
npm --prefix tenant run build
npm --prefix portal run build
```

## 边界检查命令

```bash
rg -n "Partner[ ]ID|请输入合作伙伴 ID|unsupportedApi|platformV1TenantsProjects|listTenantProjects" admin/src tenant/src portal/src host/src packages/api-contracts/src/generated/api.ts
rg -n "/api/tenant/v1/projects/\\{projectId\\}/template[s]|tenantV1ProjectsTemplate[s]" packages/api-contracts/openapi.json packages/api-contracts/src/generated/api.ts host/src/controller
```

期望：无命中。

## 线上验收

- `https://ticket-admin.autostaff.cn` 可登录平台端，租户详情只管理租户管理员手机号。
- `https://ticket-tenant.autostaff.cn/projects` 可登录租户端并访问项目列表。
- `https://ticket-tenant.autostaff.cn/projects/:projectId/service-credentials` 可管理多个项目密钥并复制 Project ID / Access Key / Secret Key。
- `https://ticket-tenant.autostaff.cn/projects/:projectId/products` 可管理产品和固定履约 JSON。
- `https://ticket-tenant.autostaff.cn/projects/:projectId/partners` 可通过手机号邀请合作伙伴。
- `https://ticket-tenant.autostaff.cn/projects/:projectId/products/:productId` 可查看产品详情和产品维度资产聚合。
- `https://ticket-tenant.autostaff.cn/projects/:projectId/quotas|purchase-links|orders|allocations|shares|exports` 均可达并调用真实 API。
- `https://ticket-portal.autostaff.cn/login` 使用手机号验证码登录，不出现伙伴编号/密码登录。
- `https://ticket-portal.autostaff.cn/partners/:partnerId/products|codes|quotas|purchase-links|orders|allocations|shares|exports` 均可达并调用真实 API；产品上下文可查看资产聚合。
