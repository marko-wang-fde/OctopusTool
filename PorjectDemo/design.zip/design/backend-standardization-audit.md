# Ticket Backend Standardization Audit

本文档记录 ticket 后端与 BotWorks 后端工程标准之间的差距。标准来源为：

- `/Users/wanglei/Projects/cybersailor/botworks/docs/principles/backend.md`
- `/Users/wanglei/Projects/cybersailor/botworks/docs/principles/validation.md`

## Required Target

Ticket host 必须收敛到以下单一路径：

- `host/src/main.go`
- `host/src/config`
- `host/src/controller/base`
- `host/src/controller/middleware`
- `host/src/myerrors`
- `host/src/vo`
- `host/src/models`
- `host/src/services`
- `host/src/tasks`
- `host/src/tests`
- `host/Makefile.swagger`

最终后端入口与调用链应为：

```text
src/main.go -> config -> models -> services -> controller -> pin.Response
```

不保留 `internal/app`、`internal/transport/httpapi`、`internal/pkg/response` 作为并行成功路径。

## Final Structure Snapshot

当前 host 已收敛到 `src` 单一路径，主要标准文件：

```text
host/README.md
host/go.mod
host/go.sum
host/Makefile.swagger
host/src/main.go
host/src/command
host/src/config
host/src/controller
host/src/infra
host/src/models
host/src/myerrors
host/src/services
host/src/tasks
host/src/tests
host/src/vo
```

当前 GitHub workflow：

```text
.github/workflows/contract-gate.yml
```

## Gap Table

| Area | Current | Target | Priority |
| --- | --- | --- | --- |
| Entry | `host/cmd/api/main.go` shim | `host/src/main.go` + standard bootstrap | Done |
| HTTP | Gin router | Gin + middleware + pin | Done |
| Response | `pin.Response` | `pin.Response` | Done |
| Business errors | `host/src/myerrors` | `host/src/myerrors` | Done |
| Config | `host/src/config` + envconf | `host/src/config` + envconf + `AppConfig` | Done |
| DB | GORM models + AutoMigrate | GORM models + AutoMigrate | Done |
| Lifecycle | `github.com/appleboy/graceful` | graceful lifecycle wrapper | Done |
| Infra | `host/src/infra` Redis client init/cleanup | Redis/external dependency init + cleanup | Done |
| Service layer | `host/src/services` over GORM tx/db | `host/src/services` over GORM tx/db | Done |
| VO layer | `host/src/vo` | `host/src/vo` | Done |
| Tests | `host/src/tests` + guardrails | `host/src/tests` + response/data-state assertions | Done |
| Codegen | `Makefile.swagger` + drift gate | `Makefile.swagger` + generated SDK drift gate | Done |
| CI | contract gate + go-lint workflow | go test/vet/lint/swagger/codegen guardrails | Done |

## Backend.md Checklist Snapshot

- [x] `src/main.go` is the only server entry.
- [x] `src/config` exposes `AppConfig` and envconf loading.
- [x] Gin is the only HTTP router path.
- [x] Controller functions return `pin.Response`.
- [x] `pin.SetErrorHandler` centralizes system error mapping.
- [x] Business routes use auth middleware and stable `myerrors` errors.
- [x] Business errors are defined in `src/myerrors`.
- [x] Infra initialization and cleanup live in `src/infra`.
- [x] GORM models live in `src/models`.
- [x] Database initialization and AutoMigrate are part of bootstrap.
- [x] Service code lives in `src/services`.
- [x] Request/response DTOs live in `src/vo`.
- [x] Background jobs live in `src/tasks` and webhook outbox worker is started by config.
- [x] Swagger/codegen is represented by `Makefile.swagger`.
- [x] Old `internal/app`, `internal/transport/httpapi`, and `internal/pkg/response` are removed.

## Validation.md Gate Snapshot

- [x] `go test ./...`
- [x] `go vet ./...`
- [x] `gofmt` / `go fmt` clean.
- [x] `golangci-lint` config exists.
- [x] CI contains Go lint/test gate.
- [x] OpenAPI generation is reproducible.
- [x] Generated frontend SDK drift is detected.
- [x] API tests verify both response envelope and persisted data state.

## Current Commands / Evidence

The read-only audit commands were:

```bash
find host -maxdepth 4 -type f | sort
find .github -maxdepth 3 -type f | sort
```

Final verification commands:

```bash
cd host
test -z "$(gofmt -l .)"
go test ./...
go vet ./...
make -f Makefile.swagger swagger-check
```

Guardrail tests now fail if legacy runtime paths reappear.
