# 11 - UI About Face 当前核对清单

核对依据：`docs/principles/ui-aboutface.md`。

## 人物模型

- [x] Platform Admin 只处理平台租户和租户管理员授权。
- [x] Tenant Admin 处理项目、项目密钥、产品、券码、合作伙伴、配额和运营记录；资产聚合在产品详情页呈现。
- [x] Partner User 使用手机号登录并选择/激活自己的 partner 身份。
- [x] Partner User 可以处理自己可访问的产品、券码、配额、购买链接、订单、划拨、分享、导出；资产聚合在产品上下文呈现。
- [x] 机器调用方只使用 ProjectServiceCredential HMAC，不进入人类登录体系。

## Platform Admin

- [x] 租户详情页不暴露项目和项目密钥，避免把租户运营任务混入平台任务。
- [x] 租户管理员授权只输入手机号，不要求 `slauth user id`。
- [x] 登录页文案只描述平台租户与租户管理员授权。

## Tenant Admin

- [x] 进入项目后，用户停留在稳定项目上下文中，左侧显示项目工作台导航。
- [x] 项目切换器位于项目工作台左侧面板，使用 shadcn/ui `Combobox` 模式。
- [x] 项目总览只保留少量常用操作，不再承担完整入口面板职责。
- [x] 产品页面使用“产品”名词，不把内部存储模型暴露给用户。
- [x] 产品固定履约 JSON 可直接编辑和复制。
- [x] 合作伙伴邀请只要求手机号和名称。
- [x] 邀请后生成 pending activation partner，不要求租户管理员理解账号预绑定。
- [x] 项目密钥创建/轮换由 tenant console 完成，不经过 platform console。
- [x] 项目密钥一次性 Secret 使用 shadcn/ui `Sheet` 展示，关闭前必须确认已保存。
- [x] 轮换、禁用、成员禁用、Partner 禁用使用 shadcn/ui `AlertDialog`，普通搜索、复制、查看不弹确认。
- [x] 配额、购买链接、订单、划拨、分享、导出均有真实列表与创建入口；资产没有独立页面，只在产品详情中聚合展示。

## Partner Portal

- [x] 登录页只要求手机号验证码。
- [x] 待激活 partner 是正常状态，有明确激活动作，不作为错误弹窗处理。
- [x] 产品、券码、配额、购买链接、订单、划拨、分享、导出均可从导航进入；资产聚合从产品详情进入。
- [x] 路由守卫防止用户进入非当前 active partner 的路径。
- [x] 页面不暴露 tenantId/projectId。

## 连接与错误

- [x] 三端 API client 注入 `X-Request-Id`。
- [x] admin/tenant/portal 使用对应 slauth session 注入 Authorization。
- [x] tenant 端额外注入 `X-Ticket-Tenant-ID`。
- [x] 后端 CORS 允许 `X-Ticket-Tenant-ID` 和 Ticket HMAC headers。
- [x] 错误 fastfail 展示，不做旧 API fallback。
- [x] 用户可见选择器使用 shadcn/ui `Select` 或 `Combobox`，不保留原生 `<select>` 分支。
- [x] 全局主题切换在四个前端可见，浅色和深色模式都保持可扫描性。

## 验收

- [x] admin build 通过。
- [x] tenant build 通过。
- [x] portal build 通过。
- [x] backend tests 通过。
- [x] swagger drift check 通过。
