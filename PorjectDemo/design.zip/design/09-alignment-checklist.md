# 09 - 当前实现对齐清单

本文档定义当前 Ticket 已实现并允许用户访问的单一成功路径。

## Platform Admin

- [x] `/login` 使用 platform slauth 手机号登录。
- [x] `/dashboard` 展示平台汇总数据。
- [x] `/tenants` 支持租户列表。
- [x] `/tenants/new` 支持创建租户。
- [x] `/tenants/:tenantId/overview` 只展示租户信息和租户管理员手机号。
- [x] platform 端不展示项目、项目密钥、产品、券码、合作伙伴入口。
- [x] platform API 不暴露项目管理路径。

## Tenant Admin

- [x] `/login` 使用 tenant slauth 手机号登录。
- [x] 登录后通过 `/api/tenant/v1/me` 获取可管理租户。
- [x] 多租户手机号必须选择 active tenant。
- [x] tenant API 统一携带 `X-Ticket-Tenant-ID`。
- [x] `/members` 支持手机号邀请/禁用租户成员。
- [x] `/projects` 支持项目列表和创建项目。
- [x] `/projects/:projectId/overview` 展示全部真实可达入口。
- [x] `/projects/:projectId/service-credentials` 支持项目密钥列表、创建、轮换、禁用。
- [x] `/projects/:projectId/products` 支持产品列表。
- [x] `/projects/:projectId/products/new` 支持创建产品。
- [x] `/projects/:projectId/products/:productId` 是唯一产品详情页，支持产品详情、更新和产品维度资产聚合。
- [x] `/projects/:projectId/inventory` 支持按产品生成、查看券码、批量追加标签、详情页整体替换标签，并按产品或标签筛选券码。
- [x] `/projects/:projectId/partners` 支持手机号邀请合作伙伴和列表。
- [x] `/projects/:projectId/partners/:partnerId` 支持合作伙伴详情与禁用。
- [x] tenant 端不存在独立资产页；资产聚合只能在产品详情页中查看。
- [x] `/projects/:projectId/quotas` 支持配额列表与发放，配额可生成 Code 或再次划拨。
- [x] `/projects/:projectId/purchase-links` 支持购买链接列表与创建。
- [x] `/projects/:projectId/orders` 支持订单列表与创建。
- [x] `/projects/:projectId/allocations` 支持划拨列表与创建。
- [x] `/projects/:projectId/shares` 支持分享列表与创建。
- [x] `/projects/:projectId/exports` 支持导出批次列表与创建。

## Partner Portal

- [x] `/login` 使用 partner slauth 手机号登录。
- [x] 登录后通过 `/api/partner/v1/me` 获取手机号可访问的 partner。
- [x] 已激活 partner 可进入 `/partners/:partnerId/overview`。
- [x] 待激活 partner 可在登录后执行 activate。
- [x] router guard 要求当前 active partner 与 URL partnerId 一致。
- [x] `/partners/:partnerId/products` 支持产品列表。
- [x] `/partners/:partnerId/codes` 支持券码列表，并只读展示租户后台标签。
- [x] partner 端不存在独立资产页；资产聚合只能在产品上下文中查看。
- [x] `/partners/:partnerId/quotas` 支持配额列表、基于配额生成 Code 和配额划拨。
- [x] `/partners/:partnerId/purchase-links` 支持购买链接列表与创建。
- [x] `/partners/:partnerId/orders` 支持订单列表与创建。
- [x] `/partners/:partnerId/allocations` 支持划拨列表与创建。
- [x] `/partners/:partnerId/shares` 支持分享列表与创建。
- [x] `/partners/:partnerId/exports` 支持导出批次列表与创建。
- [x] `/partners/:partnerId/profile` 展示个人中心。

## API 与 SDK

- [x] Go controller 注解是 OpenAPI 唯一来源。
- [x] `make -f Makefile.swagger swagger-all` 生成 `packages/api-contracts/openapi.json` 和 TS SDK。
- [x] 前端业务 API 只通过生成 SDK 调用。
- [x] 不保留 `unsupportedApi` fallback。
- [x] 产品固定履约 JSON 原样进入核销响应与 webhook。
- [x] 业务 API 可以创建券码、整体替换券码 meta，并在核销响应与 webhook 中透传 meta 快照。
- [x] 业务 API 可以创建券码时设置 tags，并整体替换单个券码 tags。
- [x] 业务 API 预留核销支持传入 remark，并在响应、webhook 和券码生命周期中保留备注。
- [x] 券码标签是项目级运营能力，Tenant API 可追加和筛选，Biz API 可创建时设置和整体替换。
- [x] 三端前端构建通过。
