# Ticket 人类用户登录与前端鉴权设计

> 当前管理员/成员授权契约已被 `docs/design/ticket-botworks-protocol.md` 和 BotWorks `docs/design/2026-06-13-ticket-project-credential-and-phone-admin-checklist.md` 更新：租户管理员/成员是手机号邀请模型，不绑定已有账号，不以 `user_id` 作为外部授权契约；业务调用密钥是 Ticket Project 级 `ProjectServiceCredential`。本文仅保留登录分组与前端 SDK 原则，旧的 `ticket_tenant_users` / `user_id` 绑定描述已废弃。

## 背景

Ticket 已经具备业务系统调用链路：`/api/biz/v1/*` 只接受项目级 `ProjectServiceCredential` HMAC 签名。该链路面向机器调用，不解决平台管理员、租户管理员、合作伙伴用户等人类用户登录问题。

变更前 Ticket 前端存在 `admin`、`tenant`、`portal`、`pay` 等应用，但 `admin` 与 `tenant` 的登录页仍是本地假跳转；后端 `/api/platform/v1/*` 使用旧静态平台管理员 key；前端也存在绕过 generated SDK 的手写业务请求。这与 Ticket 文档中“人类认证收敛到 slauth、前端 API 只走生成 SDK”的原则不一致。

## 目标

本设计补齐 Ticket 人类用户登录体系、slauth 集成、前端鉴权闭环，以及各端使用 generated SDK 管理 Ticket 自身资源的 UI。

完成后系统只保留以下成功路径：

- 平台管理员：手机号登录 slauth，后端校验 token，并用配置中的平台管理员手机号白名单授权。
- 租户管理员：手机号登录 slauth，后端校验 token，并用 Ticket DB 中的手机号邀请授权记录授权。
- 合作伙伴用户：手机号登录 slauth，后端校验 token，并用 Ticket DB 中的手机号 Partner 授权记录授权。
- 业务系统调用：继续使用 `ProjectServiceCredential` HMAC，不走 slauth。
- 前端 API：只通过 `packages/api-contracts/src/generated` 生成 SDK 发起请求，不在页面或业务 API 层手写 `fetch`。

## 非目标

- 不把 `/api/biz/v1/*` 改成 slauth。
- 不保留旧静态平台管理员 key 作为平台 API fallback。
- 不实现 DB bootstrap 平台管理员 grant；平台管理员手机号来自配置文件。
- 不在 Ticket 内重复实现认证中心；Ticket 只集成 slauth。
- 不在本轮实现 pay 端完整登录体系。

## 名词

- `PlatformUser`：Ticket 平台管理员。通过 `/platform-auth/v1/*` 登录，手机号必须在配置白名单中。
- `TenantUser`：Ticket 租户管理员。通过 `/tenant-auth/v1/*` 登录，必须在 `ticket_tenant_members` 中有 active 手机号授权。
- `PartnerUser`：Ticket 合作伙伴用户。通过 `/partner-auth/v1/*` 登录，必须在 `partner_members` 中有 invited 或 active 手机号授权。
- `Product`：Ticket 对外产品定义。内部可以由 `TicketTemplate` 持久化，但前端/API/文档对外统一称为产品。
- `TicketTenantMemberInvitation`：Ticket DB 中以手机号为外部契约的 Ticket tenant 授权记录。
- `PartnerInvitation`：Ticket DB 中以手机号为外部契约的合作伙伴授权记录，租户管理员邀请时自动创建 pending activation partner。
- `ActiveTicketTenant`：租户管理端当前操作的 Ticket tenant，由前端在用户可管理列表中选择，并在 API header 中传递。
- `ProjectServiceCredential`：业务系统调用 Ticket 的项目级机器凭证，只用于 `/api/biz/v1/*`。

## 后端认证分组

Ticket host 使用三个 slauth auth domain：

- `/platform-auth/v1/*`
  - 平台管理员手机号登录。
  - 参考 BotWorks account 的 `admin-auth/v1`。
  - 暴露 slauth 标准路由、`/signin`、`/sms-login`、JWKS。
- `/tenant-auth/v1/*`
  - 租户管理员手机号登录。
  - 参考 BotWorks account 的 `tenant-admin-auth/v1`。
  - 暴露 slauth 标准路由、`/signin`、`/sms-login`、JWKS。
- `/partner-auth/v1/*`
  - 合作伙伴用户手机号登录。
  - 暴露 slauth 标准路由、`/signin`、`/sms-login`、JWKS。

API 鉴权：

- `/api/platform/v1/*`
  - 使用 `PlatformAuthMiddleware`。
  - 先用 platform slauth `RequestValidator()` 校验 JWT。
  - 再从用户身份中读取手机号，检查是否在 `SECURITY_PLATFORM_ADMIN_PHONES`。
  - 不接受静态 bearer key。
- `/api/tenant/v1/*`
  - 使用 `TenantAuthMiddleware`。
  - 先用 tenant slauth `RequestValidator()` 校验 JWT。
  - 再读取 `X-Ticket-Tenant-ID`，检查当前 token 手机号在 `ticket_tenant_members` 中是否有 active 授权。
  - 将 `TicketTenantPrincipal` 注入上下文，controller/service 查询必须使用该 tenant。
- `/api/partner/v1/*`
  - 使用 `PartnerAuthMiddleware`。
  - 先用 partner slauth `RequestValidator()` 校验 JWT。
  - 再读取 token 手机号，检查当前手机号在 `partner_members` 中是否有 invited/active 授权。
  - 带 `partnerId` 的 API 必须校验手机号与 partner 的授权关系。
- `/api/biz/v1/*`
  - 保持 `ProjectServiceCredential` HMAC。

## 配置

新增配置遵循 envconf 风格，命名以 Ticket 自身语义为准：

```text
SECURITY_PLATFORM_ADMIN_PHONES=+8613XXXXXXXX,+8615XXXXXXXX

PLATFORM_AUTH_INSTANCE_ID=ticket-platform-admin
PLATFORM_AUTH_SITE_URL=https://admin-ticket.autostaff.cn

TENANT_AUTH_INSTANCE_ID=ticket-tenant-admin
TENANT_AUTH_SITE_URL=https://tenant-ticket.autostaff.cn

PARTNER_AUTH_INSTANCE_ID=ticket-partner
PARTNER_AUTH_SITE_URL=https://ticket-portal.autostaff.cn
```

具体字段以 account 现有 slauth 初始化需要为准。实施时必须先读取 account 的配置结构，复用同样的 AuthService 初始化方式，不另造一套不兼容配置。

启动期必须 fastfail：

- 缺 `SECURITY_PLATFORM_ADMIN_PHONES` 时，platform API 不应启动为可用状态。
- 缺 platform/tenant/partner slauth 必需配置时，服务启动失败。
- `/api/biz/v1/*` 所需的 ProjectServiceCredential 配置仍按已有 fastfail 校验。

## 数据模型

使用 `TicketTenantMemberInvitation` 和 `PartnerInvitation`：

```text
ticket_tenant_members
- id
- ticket_tenant_id
- phone
- role
- status
- created_at
- updated_at
- disabled_at
```

约束：

- `(ticket_tenant_id, phone, status=active)` 必须唯一。
- `role` 初始支持 `admin`。
- `phone` 是外部授权真相源；用户可在账号存在前被邀请。

平台管理员不需要 DB 表；平台管理员授权唯一来源是配置手机号白名单。

合作伙伴授权模型：

```text
partners
- id
- ticket_tenant_id
- ticket_project_id
- name
- status
- created_at
- updated_at
- activated_at
- disabled_at

partner_members
- id
- ticket_tenant_id
- ticket_project_id
- partner_id
- phone
- role
- status
- created_at
- updated_at
- activated_at
- disabled_at

partner_invites
- id
- ticket_tenant_id
- ticket_project_id
- partner_id
- phone
- status
- created_at
- updated_at
- accepted_at
- canceled_at
- expired_at
```

约束：

- 租户管理员邀请手机号时，同一事务创建 pending activation partner、invited partner member、pending partner invite。
- 同一项目下，同一手机号只能有一个 invited/active partner member。
- 合作伙伴用户手机号登录后可查看自己可访问的 partners，并激活 pending activation partner。

## Tenant 用户上下文

租户管理员登录后调用：

```text
GET /api/tenant/v1/me
```

返回：

```json
{
  "user": {
    "phone": "+8613800000000"
  },
  "tenants": [
    {
      "id": "ttn_x",
      "name": "租户 A",
      "role": "admin"
    }
  ]
}
```

前端规则：

- 如果只有一个 tenant，自动设为 `ActiveTicketTenant`。
- 如果多个 tenant，用户必须选择。
- 后续 `/api/tenant/v1/*` 请求统一带 `X-Ticket-Tenant-ID`。
- 未选择 active tenant 的页面进入 tenant selector，不直接请求业务 API。

## 前端鉴权闭环

`admin`、`tenant` 与 `portal` 都使用 `@cybersailor/slauth-ts`，参考 BotWorks `frontend/account-ui-cn/src/lib/auth.ts`。

统一能力：

- `auth.ts` 创建 slauth client。
- `smsLogin.ts` 做手机号 OTP 登录。
- `sessionManager` 持久化 session 并自动 refresh。
- `api/client.ts` 创建 `Api` 实例，并通过 `securityWorker` 注入 Authorization 与 `X-Request-Id`。
- 路由 guard：
  - 未登录访问管理页跳转 `/login`。
  - 已登录访问 `/login` 跳转默认页。
  - 401 清 session 并跳转 `/login`。

`admin` header：

```text
Authorization: Bearer <platform access token>
X-Request-Id: <generated id>
```

`tenant` header：

```text
Authorization: Bearer <tenant access token>
X-Ticket-Tenant-ID: <active ticket tenant id>
X-Request-Id: <generated id>
```

`portal` header：

```text
Authorization: Bearer <partner access token>
X-Request-Id: <generated id>
```

## 前端 SDK 单通道

所有前端 API 调用必须通过 `packages/api-contracts/src/generated`：

- `admin` 使用 `packages/api-contracts/src/generated/api.ts` 中的 `Api` 客户端。
- `tenant` 使用 `packages/api-contracts/src/generated/api.ts` 中的 `Api` 客户端。
- `portal` 使用 `packages/api-contracts/src/generated/api.ts` 中的 `Api` 客户端。
- 禁止页面、composable、`api/sdk.ts` 中手写 `fetch`。
- 如果 generated SDK 缺接口，先改 Go controller/VO 注解，再 `make swagger-all`，最后基于生成类型改前端。

保留唯一例外：

- `@cybersailor/slauth-ts` 内部的认证请求由 slauth client 自己发起，不属于业务 API 绕过。

## ProjectServiceCredential 管理 UI

在 `tenant` 项目页面新增项目密钥管理区。

能力：

- 列出 ProjectServiceCredentials。
- 创建 ProjectServiceCredential。
- 轮换 ProjectServiceCredential。
- 禁用 ProjectServiceCredential。
- 创建/轮换成功后使用 sheet/modal 展示一次性 `secretKey`。
- 列表永不展示 secret。

交互原则：

- 以“API 凭证”作为用户可理解名称，不把用户暴露到内部 HMAC 细节。
- 创建/轮换后的 secret 明确标记“只显示一次”。
- 禁用使用明确危险按钮，并展示影响范围。
- 不用多层弹窗；详情和一次性 secret 展示使用 sheet。

## OpenAPI 与 SDK

OpenAPI 需要覆盖：

- platform auth protected APIs 的 security scheme。
- tenant auth protected APIs 的 security scheme。
- `/api/tenant/v1/me`。
- `TicketTenantMember` 管理接口。
- ProjectServiceCredential 管理接口保持在 generated `Api` 的 tenant/project 分组。
- Partner 管理接口保持在 generated `Api` 的 tenant/project 分组。
- Product、Code、Asset、Quota、PurchaseLink、Order、Allocation、Share、Export 接口保持在 generated `Api` 的 tenant/project 分组。
- Partner 登录后的 `/api/partner/v1/me`、activate、Product、Code、Asset、Quota、PurchaseLink、Order、Allocation、Share、Export 接口保持在 generated `Api` 的 partner 分组。

生成物：

```bash
cd packages/api-contracts
npm run generate
```

漂移检查：

```bash
cd host
./scripts/check-swagger-drift.sh
```

## 错误处理

新增或复用稳定错误码：

- `AUTH_REQUIRED`
- `PLATFORM_ADMIN_NOT_ALLOWED`
- `TICKET_TENANT_REQUIRED`
- `TICKET_TENANT_ACCESS_DENIED`
- `TICKET_TENANT_MEMBER_NOT_FOUND`
- `PARTNER_NOT_FOUND`
- `PARTNER_INVITE_DUPLICATED`
- `PARTNER_ACCESS_DENIED`
- `PARTNER_INVALID_STATE`

业务错误必须定义在 `host/src/myerrors`。

## About Face 交互 review

本设计按 `docs/principles/ui-aboutface.md` 做约束：

- 登录页只呈现手机号登录主任务，不把实现概念暴露给用户。
- 管理页是长期使用的 sovereign 应用，视觉风格应克制，重点是扫描、列表、详情、操作。
- 凭证 secret 的一次性展示是任务分支，适合 sheet/modal；列表保持稳定、可扫描。
- 计算机自动处理 token refresh、headers、tenant selection 恢复；用户只关心“我能管理哪些租户”和“创建/轮换凭证”。

## 验收

- `admin`、`tenant` 与 `portal` 不再有假登录。
- 平台 API 不再接受旧静态平台管理员 key。
- 平台 API 只允许配置手机号白名单中的 platform user。
- 租户 API 必须带 active tenant，并校验 DB binding。
- 合作伙伴 API 必须校验 partner 手机号授权。
- `/api/biz/v1/*` 仍只接受 HMAC。
- 前端业务 API 调用无手写 `fetch`。
- ServiceCredential UI 使用 generated SDK。
- Product 和 Partner operating UI 使用 generated SDK。
- OpenAPI 与 generated SDK 无漂移。
